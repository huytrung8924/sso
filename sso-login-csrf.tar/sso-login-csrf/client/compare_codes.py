#!/usr/bin/env python3
import sys

print("=== Công cụ đối chiếu mã Code ===")
c0 = input("Nhập mã C0 từ Bước 1 (Attacker nhận được): ").strip()
c1 = input("Nhập mã Code từ Bước 2 (Nạn nhân gửi đi): ").strip()
c2 = input("Nhập mã Code từ Bước 4 (Backend Employee dùng để đổi token): ").strip()

if c0 and c1 and c2 and c0 == c1 == c2:
    print("\n[+] ĐỐI CHIẾU THÀNH CÔNG: Cả 3 vị trí đều dùng chung một mã Code!")
    print("[+] Kết luận: Nạn nhân đã bị ép sử dụng mã Code do kẻ tấn công cung cấp (Login CSRF).")
else:
    print("\n[-] THẤT BẠI: Các mã Code không khớp nhau hoặc bị bỏ trống.")
    if c0 != c1: print("    -> Code nạn nhân gửi đi khác với Code attacker nhận được.")
    if c1 != c2: print("    -> Code backend Employee sử dụng khác với Code nạn nhân gửi.")
