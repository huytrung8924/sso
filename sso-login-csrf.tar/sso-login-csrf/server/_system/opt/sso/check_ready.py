"""Kiểm tra các dịch vụ từ mạng Docker."""

import json
import time
from urllib.request import (
    ProxyHandler,
    build_opener,
)


CHECKS = {
    "Keycloak": (
        "http://idp.lab:8080/realms/"
        "sso-lab/.well-known/"
        "openid-configuration"
    ),

    "Employee": (
        "http://employee.lab:5001/health"
    ),

    "Documents": (
        "http://documents.lab:5002/health"
    ),

    "API": (
        "http://api.lab:8000/health"
    ),
}

EXPECTED_ISSUER = (
    "http://idp.lab:8080/realms/sso-lab"
)

opener = build_opener(
    ProxyHandler({})
)

deadline = time.monotonic() + 180

try:
    while True:
        failures = []

        for name, url in CHECKS.items():
            try:
                with opener.open(
                    url,
                    timeout=3,
                ) as response:
                    data = json.load(response)

                if name == "Keycloak":
                    if (
                        data.get("issuer")
                        != EXPECTED_ISSUER
                    ):
                        raise ValueError(
                            "Issuer không đúng"
                        )

                elif data.get("status") != "ok":
                    raise ValueError(
                        "Health response không đúng"
                    )

            except Exception as error:
                failures.append(
                    f"{name}: {error}"
                )

        if not failures:
            print(
                "READY: Keycloak, Employee, "
                "Documents, API"
            )
            break

        print(
            "Đang chờ: "
            + "; ".join(failures),
            flush=True,
        )

        if time.monotonic() >= deadline:
            raise SystemExit(
                "Hết thời gian chờ. "
                "Kiểm tra Docker logs."
            )

        time.sleep(3)

except KeyboardInterrupt:
    raise SystemExit(
        "Đã dừng kiểm tra."
    )
