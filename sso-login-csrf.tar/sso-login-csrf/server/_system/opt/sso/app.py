"""Hai OIDC portal và một Resource API dùng chung."""

import base64
import hashlib
import json
import logging
import os
import secrets
import time
from datetime import timedelta
from pathlib import Path

import jwt
import requests
from flask import (
    Flask,
    abort,
    jsonify,
    redirect,
    render_template,
    request,
    session,
)
from flask_session import Session


SERVICE = os.environ["SERVICE"]

if SERVICE not in {
    "employee",
    "documents",
    "api",
}:
    raise RuntimeError("Invalid SERVICE")

PORT = int(os.environ["PORT"])
IS_PORTAL = SERVICE != "api"

ISSUER = os.environ.get(
    "OIDC_ISSUER",
    "http://idp.lab:8080/realms/sso-lab",
).rstrip("/")

API_URL = os.environ.get(
    "API_URL",
    "http://api.lab:8000/api/protected",
)

CLIENT_ID = os.environ.get(
    "CLIENT_ID",
    "",
)

CLIENT_SECRET = os.environ.get(
    "CLIENT_SECRET",
    "",
)

BASE_URL = os.environ.get(
    "BASE_URL",
    "",
).rstrip("/")

OTHER_URL = os.environ.get(
    "OTHER_URL",
    "",
)

OIDC_SECURITY_MODE = os.environ.get(
    "OIDC_SECURITY_MODE",
    "secure",
)

if (
    IS_PORTAL
    and OIDC_SECURITY_MODE
    not in {
        "secure",
        "login-csrf-vulnerable",
    }
):
    raise RuntimeError(
        "Invalid OIDC_SECURITY_MODE"
    )

LOGIN_CSRF_VULNERABLE = (
    IS_PORTAL
    and OIDC_SECURITY_MODE
    == "login-csrf-vulnerable"
)

DATA_DIR = (
    Path(
        os.environ.get(
            "SSO_DATA_ROOT",
            "/data",
        )
    )
    / SERVICE
)

TITLES = {
    "employee": "Cổng nhân viên",
    "documents": "Cổng tài liệu",
    "api": "Resource API",
}

app = Flask(__name__)

logging.getLogger(
    "werkzeug"
).setLevel(logging.ERROR)

# Các container gọi trực tiếp nhau,
# không sử dụng proxy của máy host.
http = requests.Session()
http.trust_env = False

# Lấy khóa công khai của Keycloak qua JWKS.
jwks = jwt.PyJWKClient(
    ISSUER
    + "/protocol/openid-connect/certs",
    timeout=10,
)


def event(name, **fields):
    """Ghi log JSON nhưng không ghi token, cookie hoặc secret."""

    record = {
        "timestamp": time.time(),
        "component": SERVICE,
        "event": name,
        "source_ip": request.remote_addr,
        "path": request.path,
        "user_agent": request.headers.get(
            "User-Agent",
            "",
        ),
    }

    record.update(fields)

    print(
        json.dumps(
            record,
            ensure_ascii=False,
        ),
        flush=True,
    )


def b64url(data):
    """Mã hóa Base64 URL-safe không chứa dấu bằng."""

    return (
        base64.urlsafe_b64encode(data)
        .rstrip(b"=")
        .decode("ascii")
    )


def verify_token(token, audience):
    """Xác minh JWT bằng khóa công khai của Keycloak."""

    signing_key = (
        jwks.get_signing_key_from_jwt(
            token
        ).key
    )

    return jwt.decode(
        token,
        signing_key,
        algorithms=["RS256"],
        issuer=ISSUER,
        audience=audience,
        leeway=5,
        options={
            "require": [
                "exp",
                "iat",
                "iss",
                "aud",
                "sub",
            ]
        },
    )


class LoginRequired(Exception):
    """Phiên cần thực hiện đăng nhập lại."""


if IS_PORTAL:
    if not all(
        (
            CLIENT_ID,
            CLIENT_SECRET,
            BASE_URL,
            OTHER_URL,
        )
    ):
        raise RuntimeError(
            "Missing portal configuration"
        )

    DATA_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    key_file = (
        DATA_DIR
        / "session.key"
    )

    if not key_file.exists():
        file_descriptor = os.open(
            str(key_file),
            (
                os.O_WRONLY
                | os.O_CREAT
                | os.O_EXCL
            ),
            0o600,
        )

        with os.fdopen(
            file_descriptor,
            "w",
        ) as output:
            output.write(
                secrets.token_hex(32)
            )

    app.config.update(
        SECRET_KEY=(
            key_file
            .read_text()
            .strip()
        ),

        SESSION_TYPE="filesystem",

        SESSION_FILE_DIR=str(
            DATA_DIR
            / "sessions"
        ),

        SESSION_USE_SIGNER=True,

        SESSION_COOKIE_NAME=(
            SERVICE
            + "_session"
        ),

        SESSION_COOKIE_HTTPONLY=True,

        # Môi trường Labtainers sử dụng HTTP.
        # Khi triển khai HTTPS phải đặt True.
        SESSION_COOKIE_SECURE=False,

        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_PERMANENT=True,

        PERMANENT_SESSION_LIFETIME=(
            timedelta(minutes=30)
        ),
    )

    Session(app)


@app.after_request
def response_headers(response):
    response.headers[
        "Cache-Control"
    ] = "no-store"

    response.headers[
        "Referrer-Policy"
    ] = "no-referrer"

    response.headers[
        "X-Content-Type-Options"
    ] = "nosniff"

    response.headers[
        "X-Frame-Options"
    ] = "DENY"

    response.headers[
        "Content-Security-Policy"
    ] = (
        "default-src 'self'; "
        "style-src 'self'; "
        "img-src 'self' data:; "
        "form-action 'self'; "
        "frame-ancestors 'none'; "
        "base-uri 'none'"
    )

    return response


@app.get("/health")
def health():
    return jsonify(
        status="ok",
        service=SERVICE,
    )


if IS_PORTAL:

    def page(
        error=None,
        status=200,
    ):
        return (
            render_template(
                "index.html",
                title=TITLES[SERVICE],
                kind=SERVICE,
                user=session.get(
                    "user"
                ),
                other_url=OTHER_URL,
                csrf=session.get(
                    "form_csrf",
                    "",
                ),
                error=error,
            ),
            status,
        )


    def token_endpoint_request(data):
        """Gửi yêu cầu đến Token Endpoint."""

        return http.post(
            ISSUER
            + "/protocol/openid-connect/token",

            # Xác thực confidential client.
            auth=(
                CLIENT_ID,
                CLIENT_SECRET,
            ),

            data=data,
            timeout=10,
        )


    def exchange_authorization_code(
        code,
        code_verifier=None,
    ):
        """Đổi Authorization Code lấy token."""

        data = {
            "grant_type": (
                "authorization_code"
            ),
            "code": code,
            "redirect_uri": (
                BASE_URL
                + "/callback"
            ),
        }

        if code_verifier:
            data[
                "code_verifier"
            ] = code_verifier

        response = (
            token_endpoint_request(
                data
            )
        )

        response.raise_for_status()

        tokens = response.json()

        if not isinstance(
            tokens,
            dict,
        ):
            raise ValueError(
                "Invalid token response"
            )

        return tokens


    def validate_token_response(
        tokens,
        expected_nonce=None,
        require_nonce=True,
    ):
        """
        Xác minh token do Keycloak trả về.

        Chế độ vulnerable chỉ bỏ kiểm tra nonce.
        Chữ ký, issuer, audience, exp, azp và
        at_hash vẫn được xác minh.
        """

        if (
            str(
                tokens.get(
                    "token_type",
                    "",
                )
            ).lower()
            != "bearer"
        ):
            raise ValueError(
                "Invalid token type"
            )

        access_token = tokens[
            "access_token"
        ]

        id_token = tokens[
            "id_token"
        ]

        claims = verify_token(
            id_token,
            CLIENT_ID,
        )

        if require_nonce:
            returned_nonce = (
                claims.get(
                    "nonce"
                )
            )

            if (
                not isinstance(
                    expected_nonce,
                    str,
                )
                or not expected_nonce
                or not isinstance(
                    returned_nonce,
                    str,
                )
                or not secrets.compare_digest(
                    returned_nonce,
                    expected_nonce,
                )
            ):
                raise ValueError(
                    "Invalid nonce"
                )

        authorized_party = (
            claims.get("azp")
        )

        audience = claims.get(
            "aud"
        )

        if (
            authorized_party
            is not None
            and authorized_party
            != CLIENT_ID
        ):
            raise ValueError(
                "Invalid azp"
            )

        if (
            isinstance(
                audience,
                list,
            )
            and len(audience) > 1
            and authorized_party
            != CLIENT_ID
        ):
            raise ValueError(
                "Missing azp"
            )

        if "at_hash" in claims:
            digest = hashlib.sha256(
                access_token.encode(
                    "ascii"
                )
            ).digest()

            expected_at_hash = b64url(
                digest[
                    : len(digest) // 2
                ]
            )

            returned_at_hash = (
                claims["at_hash"]
            )

            if (
                not isinstance(
                    returned_at_hash,
                    str,
                )
                or not secrets.compare_digest(
                    expected_at_hash,
                    returned_at_hash,
                )
            ):
                raise ValueError(
                    "Invalid at_hash"
                )

        return claims


    def store_login_session(
        claims,
        tokens,
        transaction_bound,
    ):
        """Tạo phiên ứng dụng sau khi đăng nhập."""

        user = {
            "sub": claims["sub"],

            "username": claims.get(
                "preferred_username",
                claims["sub"],
            ),

            "name": claims.get(
                "name",
                claims.get(
                    "preferred_username",
                    "Người dùng",
                ),
            ),
        }

        tokens["expires_at"] = (
            time.time()
            + int(
                tokens.get(
                    "expires_in",
                    0,
                )
            )
        )

        session.clear()
        session.permanent = True

        session["user"] = user
        session["tokens"] = tokens

        session["form_csrf"] = (
            secrets.token_urlsafe(32)
        )

        # Đổi định danh session sau đăng nhập.
        app.session_interface.regenerate(
            session
        )

        event(
            "login_success",
            username=user["username"],
            subject=user["sub"],
            sso_sid=claims.get("sid"),
            auth_time=claims.get(
                "auth_time"
            ),
            client_id=CLIENT_ID,
            security_mode=(
                OIDC_SECURITY_MODE
            ),
            transaction_bound=(
                transaction_bound
            ),
        )


    def current_access_token():
        """Lấy Access Token hoặc tự refresh khi sắp hết hạn."""

        tokens = session.get(
            "tokens"
        )

        if not isinstance(
            tokens,
            dict,
        ):
            raise LoginRequired()

        access_token = tokens.get(
            "access_token"
        )

        if not access_token:
            raise LoginRequired()

        expires_at = float(
            tokens.get(
                "expires_at",
                0,
            )
        )

        # Token còn hơn 20 giây thì tiếp tục sử dụng.
        if (
            expires_at
            > time.time() + 20
        ):
            return access_token

        refresh_token = tokens.get(
            "refresh_token"
        )

        if not refresh_token:
            raise LoginRequired()

        response = (
            token_endpoint_request(
                {
                    "grant_type": (
                        "refresh_token"
                    ),
                    "refresh_token": (
                        refresh_token
                    ),
                }
            )
        )

        if response.status_code == 400:
            try:
                error_code = (
                    response
                    .json()
                    .get("error")
                )

            except ValueError:
                error_code = None

            if (
                error_code
                == "invalid_grant"
            ):
                raise LoginRequired()

        response.raise_for_status()

        renewed = response.json()

        if not renewed.get(
            "access_token"
        ):
            raise ValueError(
                "Missing refreshed access token"
            )

        # Giữ trường cũ nếu Keycloak không cấp lại.
        # Nếu có Refresh Token mới, giá trị cũ
        # sẽ được thay thế.
        tokens.update(renewed)

        tokens["expires_at"] = (
            time.time()
            + int(
                renewed.get(
                    "expires_in",
                    0,
                )
            )
        )

        session["tokens"] = tokens

        event(
            "token_refreshed",
            subject=session.get(
                "user",
                {},
            ).get("sub"),
            client_id=CLIENT_ID,
        )

        return tokens[
            "access_token"
        ]


    @app.get("/")
    def index():
        if not session.get(
            "user"
        ):
            return page()

        if not session.get(
            "form_csrf"
        ):
            session[
                "form_csrf"
            ] = (
                secrets
                .token_urlsafe(32)
            )

        try:
            access_token = (
                current_access_token()
            )

        except LoginRequired:
            event(
                "session_expired",
                subject=session.get(
                    "user",
                    {},
                ).get("sub"),
                client_id=CLIENT_ID,
            )

            session.clear()

            return page(
                error=(
                    "Phiên đăng nhập đã hết hiệu lực. "
                    "Vui lòng đăng nhập lại."
                )
            )

        except (
            requests.RequestException,
            ValueError,
        ) as error:
            event(
                "token_refresh_failed",
                reason=type(
                    error
                ).__name__,
                subject=session.get(
                    "user",
                    {},
                ).get("sub"),
                client_id=CLIENT_ID,
            )

            return page(
                error=(
                    "Không thể kết nối dịch vụ "
                    "đăng nhập. Vui lòng thử lại."
                )
            )

        try:
            api_response = http.get(
                API_URL,

                headers={
                    "Authorization": (
                        "Bearer "
                        + access_token
                    ),

                    "User-Agent": (
                        "SSO-Portal/"
                        + SERVICE
                    ),
                },

                timeout=10,
            )

            event(
                "api_call",
                status=(
                    api_response
                    .status_code
                ),
                subject=(
                    session[
                        "user"
                    ][
                        "sub"
                    ]
                ),
                client_id=CLIENT_ID,
            )

            # API thành công nhưng không hiển thị
            # thông báo kỹ thuật trên giao diện.
            if (
                api_response
                .status_code
                == 200
            ):
                return page()

            if (
                api_response
                .status_code
                == 401
            ):
                error_message = (
                    "Không thể xác thực quyền truy cập. "
                    "Vui lòng đăng nhập lại."
                )

            elif (
                api_response
                .status_code
                == 403
            ):
                error_message = (
                    "Tài khoản chưa được cấp quyền "
                    "truy cập dịch vụ."
                )

            else:
                error_message = (
                    "Dịch vụ tài nguyên đang "
                    "tạm thời gián đoạn."
                )

            return page(
                error=error_message
            )

        except (
            requests.RequestException
        ) as error:
            event(
                "api_unavailable",
                reason=type(
                    error
                ).__name__,
                subject=(
                    session[
                        "user"
                    ][
                        "sub"
                    ]
                ),
                client_id=CLIENT_ID,
            )

            return page(
                error=(
                    "Không kết nối được "
                    "Resource API."
                )
            )


    @app.get("/login")
    def login():
        if LOGIN_CSRF_VULNERABLE:
            # Xóa giao dịch cũ nếu có.
            # Luồng cố ý có lỗ hổng không tạo:
            # state, nonce hoặc PKCE.
            session.pop(
                "transaction",
                None,
            )

            parameters = {
                "client_id": CLIENT_ID,

                "redirect_uri": (
                    BASE_URL
                    + "/callback"
                ),

                "response_type": (
                    "code"
                ),

                "scope": (
                    "openid "
                    "profile "
                    "email"
                ),
            }

            authorization_url = (
                requests.Request(
                    "GET",

                    ISSUER
                    + "/protocol/"
                    "openid-connect/auth",

                    params=parameters,
                )
                .prepare()
                .url
            )

            event(
                "login_started",
                client_id=CLIENT_ID,
                security_mode=(
                    OIDC_SECURITY_MODE
                ),
                transaction_bound=False,
                state_enabled=False,
                nonce_enabled=False,
                pkce_enabled=False,
            )

            return redirect(
                authorization_url
            )

        # Luồng an toàn của Document Portal.
        state = (
            secrets.token_urlsafe(32)
        )

        nonce = (
            secrets.token_urlsafe(32)
        )

        verifier = (
            secrets.token_urlsafe(48)
        )

        session["transaction"] = {
            "state": state,
            "nonce": nonce,
            "verifier": verifier,
            "started": time.time(),
        }

        challenge = b64url(
            hashlib.sha256(
                verifier.encode(
                    "ascii"
                )
            ).digest()
        )

        parameters = {
            "client_id": CLIENT_ID,

            "redirect_uri": (
                BASE_URL
                + "/callback"
            ),

            "response_type": "code",

            "scope": (
                "openid "
                "profile "
                "email"
            ),

            "state": state,
            "nonce": nonce,

            "code_challenge": (
                challenge
            ),

            "code_challenge_method": (
                "S256"
            ),
        }

        authorization_url = (
            requests.Request(
                "GET",

                ISSUER
                + "/protocol/"
                "openid-connect/auth",

                params=parameters,
            )
            .prepare()
            .url
        )

        event(
            "login_started",
            client_id=CLIENT_ID,
            security_mode=(
                OIDC_SECURITY_MODE
            ),
            transaction_bound=True,
            state_enabled=True,
            nonce_enabled=True,
            pkce_enabled=True,
        )

        return redirect(
            authorization_url
        )


    @app.get("/callback")
    def callback():
        states = request.args.getlist(
            "state"
        )

        codes = request.args.getlist(
            "code"
        )

        pending_transaction = (
            session.get(
                "transaction"
            )
        )

        event(
            "callback_received",
            client_id=CLIENT_ID,
            security_mode=(
                OIDC_SECURITY_MODE
            ),
            has_pending_transaction=(
                isinstance(
                    pending_transaction,
                    dict,
                )
            ),
            state_count=len(states),
            code_count=len(codes),
            error_present=(
                "error"
                in request.args
            ),
        )

        if LOGIN_CSRF_VULNERABLE:
            # Cố ý không yêu cầu giao dịch đăng nhập
            # trong session và không kiểm tra state.
            session.pop(
                "transaction",
                None,
            )

            valid_callback = (
                len(codes) == 1
                and bool(codes[0])
                and "error"
                not in request.args
            )

            if not valid_callback:
                event(
                    "login_rejected",
                    reason=(
                        "invalid_callback"
                    ),
                    client_id=CLIENT_ID,
                    security_mode=(
                        OIDC_SECURITY_MODE
                    ),
                )

                return page(
                    error=(
                        "Không hoàn tất được "
                        "đăng nhập. Hãy thử lại."
                    ),
                    status=400,
                )

            try:
                # Không gửi code_verifier.
                tokens = (
                    exchange_authorization_code(
                        code=codes[0],
                        code_verifier=None,
                    )
                )

                # Vẫn xác minh chữ ký, issuer,
                # audience, exp, azp và at_hash.
                # Chỉ cố ý không kiểm tra nonce.
                claims = (
                    validate_token_response(
                        tokens,
                        expected_nonce=None,
                        require_nonce=False,
                    )
                )

            except (
                requests.RequestException,
                jwt.PyJWTError,
                KeyError,
                ValueError,
                TypeError,
            ) as error:
                event(
                    "login_rejected",
                    reason=type(
                        error
                    ).__name__,
                    client_id=CLIENT_ID,
                    security_mode=(
                        OIDC_SECURITY_MODE
                    ),
                )

                session.clear()

                return page(
                    error=(
                        "Không hoàn tất được "
                        "đăng nhập. Hãy thử lại."
                    ),
                    status=400,
                )

            store_login_session(
                claims=claims,
                tokens=tokens,
                transaction_bound=False,
            )

            return redirect("/")

        # Document Portal: lấy và hủy giao dịch
        # ngay khi callback được tiếp nhận.
        transaction = session.pop(
            "transaction",
            None,
        )

        valid_transaction = (
            isinstance(
                transaction,
                dict,
            )
            and len(states) == 1
            and len(codes) == 1
            and bool(codes[0])
            and "error"
            not in request.args
        )

        if valid_transaction:
            expected_state = (
                transaction.get(
                    "state",
                    "",
                )
            )

            try:
                elapsed = (
                    time.time()
                    - float(
                        transaction.get(
                            "started",
                            0,
                        )
                    )
                )

            except (
                TypeError,
                ValueError,
            ):
                elapsed = -1

            valid_transaction = (
                0
                <= elapsed
                <= 300
                and isinstance(
                    expected_state,
                    str,
                )
                and bool(
                    expected_state
                )
                and secrets.compare_digest(
                    states[0],
                    expected_state,
                )
            )

        if not valid_transaction:
            event(
                "login_rejected",
                reason=(
                    "missing_or_invalid_state"
                ),
                client_id=CLIENT_ID,
                security_mode=(
                    OIDC_SECURITY_MODE
                ),
            )

            return page(
                error=(
                    "Yêu cầu đăng nhập không hợp lệ. "
                    "Hãy thử lại."
                ),
                status=400,
            )

        try:
            tokens = (
                exchange_authorization_code(
                    code=codes[0],

                    code_verifier=(
                        transaction[
                            "verifier"
                        ]
                    ),
                )
            )

            claims = (
                validate_token_response(
                    tokens,

                    expected_nonce=(
                        transaction[
                            "nonce"
                        ]
                    ),

                    require_nonce=True,
                )
            )

        except (
            requests.RequestException,
            jwt.PyJWTError,
            KeyError,
            ValueError,
            TypeError,
        ) as error:
            event(
                "login_rejected",
                reason=type(
                    error
                ).__name__,
                client_id=CLIENT_ID,
                security_mode=(
                    OIDC_SECURITY_MODE
                ),
            )

            session.clear()

            return page(
                error=(
                    "Không hoàn tất được đăng nhập. "
                    "Hãy thử lại."
                ),
                status=400,
            )

        store_login_session(
            claims=claims,
            tokens=tokens,
            transaction_bound=True,
        )

        return redirect("/")


    def valid_logout_csrf():
        expected = session.get(
            "form_csrf",
            "",
        )

        supplied = request.form.get(
            "csrf_token",
            "",
        )

        return (
            bool(expected)
            and bool(supplied)
            and secrets.compare_digest(
                expected,
                supplied,
            )
        )


    @app.post("/logout")
    def logout():
        """
        Xóa phiên website và thực hiện
        RP-Initiated Logout.
        """

        if not valid_logout_csrf():
            abort(400)

        tokens = session.get(
            "tokens",
            {},
        )

        id_token = tokens.get(
            "id_token"
        )

        event(
            "logout_started",
            subject=session.get(
                "user",
                {},
            ).get("sub"),
            client_id=CLIENT_ID,
        )

        # Xóa phiên và token tại website.
        session.clear()

        logout_parameters = {
            "client_id": CLIENT_ID,

            "post_logout_redirect_uri": (
                BASE_URL
                + "/"
            ),
        }

        if id_token:
            logout_parameters[
                "id_token_hint"
            ] = id_token

        logout_url = (
            requests.Request(
                "GET",

                ISSUER
                + "/protocol/"
                "openid-connect/logout",

                params=logout_parameters,
            )
            .prepare()
            .url
        )

        # Trình duyệt được chuyển đến Keycloak
        # để kết thúc phiên SSO.
        return redirect(
            logout_url
        )


else:

    def unauthorized(
        event_name,
        **details,
    ):
        event(
            event_name,
            status=401,
            **details,
        )

        response = jsonify(
            detail="Yêu cầu xác thực."
        )

        response.status_code = 401

        response.headers[
            "WWW-Authenticate"
        ] = (
            'Bearer error="invalid_token"'
        )

        return response


    @app.get("/api/protected")
    def protected():
        authorization = (
            request.headers.get(
                "Authorization",
                "",
            )
        )

        parts = authorization.split()

        if (
            len(parts) != 2
            or parts[0].lower()
            != "bearer"
        ):
            return unauthorized(
                "missing_token"
            )

        try:
            claims = verify_token(
                parts[1],
                "resource-api",
            )

        except (
            jwt.PyJWKClientConnectionError
        ):
            event(
                "key_service_unavailable",
                status=503,
            )

            return (
                jsonify(
                    detail=(
                        "Dịch vụ xác thực "
                        "chưa sẵn sàng."
                    )
                ),
                503,
            )

        except jwt.PyJWTError as error:
            return unauthorized(
                "invalid_token",
                reason=type(
                    error
                ).__name__,
                missing_claim=getattr(
                    error,
                    "claim",
                    None,
                ),
            )

        resource_access = (
            claims.get(
                "resource_access",
                {},
            )
        )

        api_roles = (
            resource_access
            .get(
                "resource-api",
                {},
            )
            .get(
                "roles",
                [],
            )
        )

        if "read" not in api_roles:
            event(
                "insufficient_permission",
                status=403,
                subject=claims.get(
                    "sub"
                ),
                client_id=claims.get(
                    "azp"
                ),
            )

            return (
                jsonify(
                    detail=(
                        "Không đủ quyền "
                        "truy cập."
                    )
                ),
                403,
            )

        event(
            "protected_resource_access",
            status=200,

            username=claims.get(
                "preferred_username",
                "",
            ),

            subject=claims["sub"],
            client_id=claims.get(
                "azp"
            ),
            token_jti=claims.get(
                "jti"
            ),
        )

        # API chỉ xác nhận truy cập, không trả
        # dữ liệu nghiệp vụ mẫu.
        return jsonify(
            status="ok",
        )


if __name__ == "__main__":
    app.run(
        host="0.0.0.0",
        port=PORT,
        debug=False,
        use_reloader=False,
    )
