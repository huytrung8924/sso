#!/bin/bash
set -e

sudo systemctl daemon-reload

sudo systemctl enable --now \
  keycloak.service \
  api.service \
  employee.service \
  documents.service
