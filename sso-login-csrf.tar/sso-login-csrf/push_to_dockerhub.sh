#!/bin/bash
set -e
for img in client server attacker; do
    echo "Processing $img..."
    cat <<EOT > dfile
FROM labtainers/sso-login-csrf.$img.student:latest
LABEL base=labtainers/labtainer.base2.739eee77f8d3
EOT
    docker build -f dfile -t trung8924/sso-login-csrf.$img.student:latest .
    docker tag trung8924/sso-login-csrf.$img.student:latest trung8924/sso-login-csrf.$img.student:base_image739eee77f8d3
    docker push trung8924/sso-login-csrf.$img.student:latest
    docker push trung8924/sso-login-csrf.$img.student:base_image739eee77f8d3
done
