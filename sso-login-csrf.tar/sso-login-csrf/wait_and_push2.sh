#!/bin/bash
while docker ps -a | grep -q "task-1273"; do sleep 10; done
# Actually I don't know the container name of task-1273. I'll just check if build is running
while pgrep -f rebuild.py > /dev/null; do
  echo "Waiting for rebuild to finish..."
  sleep 10
done
echo "Rebuild finished. Pushing..."
for c in attacker server client; do
  docker push trung8924/sso-login-csrf.$c.student:latest
  docker push trung8924/sso-login-csrf.$c.student:base_image739eee77f8d3
done
