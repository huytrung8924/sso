#!/bin/bash
while ! docker images | grep labtainers/sso-login-csrf.attacker.student; do
  echo "Waiting for attacker image..."
  sleep 10
done
echo "All images built. Pushing..."
./push_to_dockerhub.sh
