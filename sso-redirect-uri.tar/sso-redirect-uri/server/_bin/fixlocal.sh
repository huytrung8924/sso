#!/bin/bash
set -e

mkdir -p /home/ubuntu/.local/result
chmod 775 /home/ubuntu/.local/result
chown ubuntu:ubuntu /home/ubuntu/.local/result

# Clean any stale OSSEC pid files left from container build
sudo rm -f /var/ossec/var/run/*.pid /var/ossec/var/run/*.state

sudo systemctl daemon-reload

sudo systemctl enable --now \
  keycloak.service \
  api.service \
  employee.service \
  documents.service \
  wazuh-manager.service
