## PHẦN 1: PHÂN TÍCH ĐÁNH GIÁ — VÌ SAO CÁC NHẬN XÉT ĐÓ HOÀN TOÀN ĐÚNG?
1. Bắt rất đúng lỗi bản chất: Không được đánh đồng app_user != connector_user với tấn công COSF
Vì sao bản đánh giá đúng?
Trong mô hình OAuth-based Account Linking (Liên kết tài khoản), một người dùng hợp lệ hoàn toàn có thể dùng tài khoản công ty trên ứng dụng (lan.employee) để liên kết với tài khoản dịch vụ lưu trữ cá nhân của chính họ (lan.personal). Nếu Rule 100503 kết luận có tấn công COSF chỉ vì app_user != connector_user thì về mặt lý thuyết OAuth là sai bản chất và sinh cảnh báo giả trong thực tế.   

Định nghĩa chuẩn theo IETF Draft §2.3 & IEEE S&P 2026:
Lỗ hổng COSF được định nghĩa bởi sự đứt gãy ràng buộc phiên tại ứng dụng khách (Client): Danh tính người dùng ứng dụng khởi tạo luồng OAuth (state_user) 

= Danh tính người dùng ứng dụng hoàn tất luồng OAuth tại Redirection Endpoint (session_user).
Do đó, việc chuyển sang kiểm tra mối quan hệ giữa state_user và session_user (cùng thuộc không gian định danh của Employee Portal) rồi lưu trạng thái ràng buộc đó (binding_status) vào kết nối (connection) như bản đánh giá đề xuất là chuẩn xác 100%.   

2. Khắc phục triệt để điểm yếu của Regex PCRE2 trên chuỗi JSON thô
Vì sao bản đánh giá đúng?
Trong Wazuh, khi dùng <regex type="pcre2">"state_user":\s*"([^"]+)",\s*"session_user":\s*"(?!\1")([^"]+)"</regex>, biểu thức này quét trên chuỗi văn bản thô (raw log). Nếu trong tương lai lập trình viên thêm một trường khác chen vào giữa state_user và session_user, hoặc thư viện JSON đảo thứ tự key, rule sẽ lập tức bị trượt (False Negative).

Ưu điểm của hướng mới:
Khi ứng dụng ghi rõ kết quả đối chiếu ràng buộc phiên thành trường ngữ cảnh binding_status (matched | mismatched | unavailable), Wazuh chỉ cần dùng thẻ <field name="binding_status">^mismatched$</field>. Cách này tận dụng trực tiếp bộ giải mã JSON của Wazuh, không phụ thuộc vào thứ tự các trường trong JSON và dễ kiểm chứng hơn rất nhiều.

3. Phân cấp mức độ bằng chứng chặt chẽ (Từ "Nghi vấn tại Callback" đến "Đã lưu liên kết sai ràng buộc")
Bản đánh giá đã chia tách rất chuẩn xác các giai đoạn theo đúng vòng đời giao dịch OAuth:

Tại bước nhận Callback (connect_callback_received - Rule 100502 - Level 10):
Khi phát hiện binding_status = mismatched (state_user != session_user), đây mới là dấu hiệu nghi vấn COSF (vì nếu ứng dụng ở chế độ an toàn secure, ứng dụng sẽ chặn ngay tại đây và chưa có liên kết nào bị chiếm đoạt).   

Tại bước lưu liên kết vào Token Vault (connector_linked - Rule 100503 - Level 14):
Khi giao dịch đó có binding_status = mismatched, nhưng ứng dụng vẫn gắn kết nối cho người khởi tạo (owner_relation = initiator) và lưu thành công vào hệ thống (outcome = committed), đây là bằng chứng khẳng định 100% lỗ hổng COSF đã bị khai thác thành công.   

Trường hợp không có phiên trình duyệt tại Callback (binding_status = unavailable - Rule 100505 - Level 12):
Phản ánh đúng kịch bản Unauthenticated Space / Cross-UA trong tài liệu IETF và IEEE S&P (khi trình duyệt nhận callback không có cookie phiên đăng nhập vào ứng dụng nhưng ứng dụng vẫn lưu liên kết dựa trên state).   

4. Giải đáp câu hỏi: "Việc Backend ghi binding_status có bị coi là dàn dựng không?" (Lập luận bảo vệ đồ án)
Bạn hoàn toàn yên tâm đưa cơ chế này vào đồ án với lập luận kỹ thuật thực tế sau:

Trong kiến trúc phần mềm doanh nghiệp, Tầng ghi nhận nhật ký kiểm toán (Audit / Telemetry Layer) và Tầng quyết định nghiệp vụ (Policy Enforcement Layer) thường tách biệt nhau.

Hàm kiểm toán (Audit Logger) tự động ghi nhận ngữ cảnh phiên của mọi giao dịch OAuth: người khởi tạo (state_user), người giữ phiên hiện tại (session_user) và trạng thái đối chiếu giữa hai giá trị đó (binding_status: matched | mismatched | unavailable).

Tuy nhiên, ở chế độ chứa lỗ hổng (OIDC_SECURITY_MODE=cosf-vulnerable), logic nghiệp vụ của Employee Portal chỉ sử dụng state để lấy danh tính người khởi tạo (state_user) và lưu token (outcome="committed") mà không thực thi chính sách chặn (Enforcement) khi binding_status != "matched".   

Cách giải thích này vừa trung thực về mặt kỹ thuật trong báo cáo (như mục 4 của bản đánh giá đã lưu ý: "Đây là phát hiện dựa trên audit log có ngữ cảnh, không phải chữ ký mạng COSF"), vừa giúp bộ rule Wazuh chạy ổn định và chính xác tuyệt đối.

## PHẦN 2: THIẾT LẬP HỆ THỐNG VÀ CẤU HÌNH CHI TIẾT (sso-oauth-cosf) THEO HƯỚNG CHUẨN HÓA
Dưới đây là toàn bộ thiết lập kỹ thuật đã được chuẩn hóa theo đúng góp ý trong bản đánh giá.

1. Chuẩn hóa Logic ghi Audit Log và Lưu trữ Connection trong /opt/sso/app.py
Trong file /opt/sso/app.py của Employee Portal, luồng liên kết Connector (/connect 
→ /connect/callback) và luồng gọi API (/) được thiết kế ghi đúng các trường bằng chứng sau:

A. Tại bước khởi tạo GET /connect
Người dùng đang đăng nhập (session["user"]) nhấn nút "Kết nối kho tài liệu":

Tạo mã giao dịch oauth_state_id = "tx-" + secrets.token_hex(4).

Lưu vào /var/lib/sso/employee/pending_oauth.json theo khóa state:

```python
pending_tx = {
    "oauth_state_id": oauth_state_id,
    "state_user": session["user"]["username"],      # Ví dụ: "attacker"
    "state_user_sub": session["user"]["sub"],       # ID ổn định trong cùng không gian định danh
    "verifier": verifier,                           # PKCE code_verifier
    "nonce": nonce,
    "init_ip": request.remote_addr,
    "started": time.time(),
}
```
Ghi log sự kiện connect_started:

```json
{
  "timestamp": 1760000100.1,
  "component": "employee",
  "event": "connect_started",
  "source_ip": "172.28.50.30",
  "oauth_state_id": "tx-8f9a12b4",
  "state_user": "attacker",
  "session_user": "attacker",
  "outcome": "redirected"
}
```
B. Tại bước nhận Callback GET /connect/callback
Khi trình duyệt chuyển hướng về /connect/callback?code=...&state=...:

Tra cứu giao dịch tx từ pending_oauth.json theo state.

Xác định binding_status bằng cách đối chiếu danh tính ứng dụng khởi tạo và danh tính ứng dụng hiện tại trên trình duyệt (tuyệt đối không so sánh với tài khoản Connector):

```python
current_user = session.get("user")
if not current_user or not current_user.get("sub"):
    session_user = "unavailable"
    binding_status = "unavailable"
elif current_user["sub"] == tx["state_user_sub"]:
    session_user = current_user["username"]
    binding_status = "matched"
else:
    session_user = current_user["username"]
    binding_status = "mismatched"
```
Ghi log sự kiện connect_callback_received:

Nếu ứng dụng ở chế độ cosf-vulnerable, nó không chặn khi mismatched hay unavailable mà tiếp tục xử lý (outcome="continued"):

```json
{
  "timestamp": 1760000115.2,
  "component": "employee",
  "event": "connect_callback_received",
  "source_ip": "172.28.50.10",
  "oauth_state_id": "tx-8f9a12b4",
  "state_user": "attacker",
  "session_user": "student",
  "binding_status": "mismatched",
  "outcome": "continued"
}
```
(Nếu ứng dụng ở chế độ secure, khi binding_status != "matched", ứng dụng ghi outcome="rejected" và dừng luồng ngay lập tức — lúc này chỉ có Rule 100502 kêu, không có 100503).

C. Tại bước lưu liên kết vào Token Vault (connector_linked)
Sau khi đổi code và tx["verifier"] lấy token từ Keycloak thành công:

Tạo mã định danh kết nối connection_id = "conn-" + secrets.token_hex(4).

Lưu vào /var/lib/sso/employee/vault.json cho người khởi tạo (app_user = tx["state_user"]), trong đó giữ lại nguyên vẹn bằng chứng của giao dịch đã tạo ra connection này:

```python
vault[tx["state_user"]] = {
    "connection_id": connection_id,
    "oauth_state_id": tx["oauth_state_id"],
    "app_user": tx["state_user"],
    "session_user_at_callback": session_user,
    "connector_user": connector_username,
    "connector_email": connector_email,
    "binding_status": binding_status,       # Lấy trực tiếp từ bước callback của chính giao dịch này
    "owner_relation": "initiator",          # Liên kết được lưu cho người khởi tạo state
    "tokens": tokens,
}
```
Chỉ sau khi ghi file vault.json thành công mới ghi log sự kiện connector_linked với outcome="committed":

```json
{
  "timestamp": 1760000115.6,
  "component": "employee",
  "event": "connector_linked",
  "source_ip": "172.28.50.10",
  "oauth_state_id": "tx-8f9a12b4",
  "connection_id": "conn-3c4d5e6f",
  "app_user": "attacker",
  "session_user": "student",
  "connector_user": "student",
  "binding_status": "mismatched",
  "owner_relation": "initiator",
  "outcome": "committed"
}
```
D. Tại bước sử dụng Connection để gọi Resource API (connector_api_call)
Khi attacker tải lại trang chủ GET /, Employee Portal lấy connection conn-3c4d5e6f trong vault.json ra để gọi [http://api.lab:8000/api/protected](http://api.lab:8000/api/protected). Sau khi API trả về HTTP 200, ứng dụng ghi log connector_api_call (sử dụng lại đúng binding_status và owner_relation đã lưu trong connection đó):

```json
{
  "timestamp": 1760000125.0,
  "component": "employee",
  "event": "connector_api_call",
  "source_ip": "172.28.50.30",
  "oauth_state_id": "tx-8f9a12b4",
  "connection_id": "conn-3c4d5e6f",
  "app_user": "attacker",
  "connector_user": "student",
  "binding_status": "mismatched",
  "owner_relation": "initiator",
  "api_status": "200",
  "outcome": "success"
}
```
2. Bộ Rule Wazuh hoàn chỉnh (/var/ossec/etc/rules/local_rules.xml)
Bộ rule dưới đây sử dụng chính xác cấu trúc của bản đánh giá:

```xml
<group name="sso_lab,">

  <!-- Rule 100500: Nhận diện log JSON từ Employee Portal -->
  <rule id="100500" level="3">
    <decoded_as>json</decoded_as>
    <field name="component" type="pcre2">^employee$</field>
    <description>Employee: $(event)</description>
  </rule>

  <!-- Rule 100501: Ghi nhận các sự kiện của luồng liên kết Connector -->
  <rule id="100501" level="3">
    <if_sid>100500</if_sid>
    <field name="event" type="pcre2">^(connect_started|connect_callback_received|connector_linked)$</field>
    <description>OAuth Connector: $(event), transaction=$(oauth_state_id)</description>
  </rule>

  <!-- Rule 100502 (Level 10 - Nghi vấn COSF): Callback được hoàn tất bởi người dùng ứng dụng khác với người khởi tạo -->
  <rule id="100502" level="10">
    <if_sid>100501</if_sid>
    <field name="event" type="pcre2">^connect_callback_received$</field>
    <field name="binding_status" type="pcre2">^mismatched$</field>
    <group>oauth_cosf,</group>
    <description>[NGHI VAN COSF] Khoi tao=$(state_user), hoan tat=$(session_user), transaction=$(oauth_state_id), outcome=$(outcome)</description>
  </rule>

  <!-- Rule 100503 (Level 14 - Xác nhận liên kết sai ràng buộc): Vẫn lưu liên kết cho người khởi tạo dù callback khác người -->
  <rule id="100503" level="14">
    <if_sid>100501</if_sid>
    <field name="event" type="pcre2">^connector_linked$</field>
    <field name="binding_status" type="pcre2">^mismatched$</field>
    <field name="owner_relation" type="pcre2">^initiator$</field>
    <field name="outcome" type="pcre2">^committed$</field>
    <group>oauth_cosf,</group>
    <description>[COSF - LIEN KET SAI RANG BUOC] Da luu cho $(app_user), nguoi hoan tat=$(session_user), connection=$(connection_id), transaction=$(oauth_state_id)</description>
  </rule>

  <!-- Rule 100505 (Level 12 - Liên kết thiếu xác minh phiên): Không xác minh được phiên tại callback nhưng vẫn lưu liên kết -->
  <rule id="100505" level="12">
    <if_sid>100501</if_sid>
    <field name="event" type="pcre2">^connector_linked$</field>
    <field name="binding_status" type="pcre2">^unavailable$</field>
    <field name="outcome" type="pcre2">^committed$</field>
    <group>oauth_cosf,</group>
    <description>[OAUTH - LIEN KET CHUA XAC MINH] Da luu cho $(app_user), connection=$(connection_id), transaction=$(oauth_state_id)</description>
  </rule>

</group>
```
## PHẦN 3: BẢN HƯỚNG DẪN THỰC HÀNH (sso-oauth-cosf.md) ĐÃ CẬP NHẬT CHUẨN XÁC
Dưới đây là tài liệu hướng dẫn thực hành hoàn chỉnh đã được cập nhật đồng bộ với cơ chế kiểm tra ràng buộc phiên (binding_status, owner_relation, outcome) và bộ rule Wazuh mới:

Học viện Công nghệ Bưu chính Viễn thông - SecLab PTIT

Hướng dẫn thực hành

OAuth 2.0 / OpenID Connect – Cross-user OAuth Session Fixation

Mức độ: Trung bình – Khó

Web Security / Identity Security / Single Sign-On

1. Giới thiệu lab
| Thông tin | Chi tiết |
| --- | --- |
| Tên Lab | sso-oauth-cosf |
| Mức độ | Trung bình – Khó |
| Công cụ sử dụng | firefox, mitmweb, wazuh-logtest, jq, getent |
| Giao thức | OAuth 2.0, OpenID Connect, Authorization Code Flow + PKCE (S256) |
| Cơ chế bảo vệ & phát hiện | User Session Binding (IETF OAuth Security BCP §2.3.2), Wazuh SIEM |
Mục tiêu học tập

Hiểu rõ cơ chế hoạt động của mô hình OAuth-based Account Linking (Liên kết tài khoản / Tích hợp Connector) và sự tách biệt giữa danh tính người dùng tại ứng dụng (Application Account) với tài khoản dịch vụ tài nguyên (Connector Account).   

Nắm vững bản chất lỗ hổng Cross-user OAuth Session Fixation (COSF - CWE-384) theo tài liệu cập nhật bảo mật OAuth 2.0 của IETF (draft-ietf-oauth-security-topics-update-03 §2.3).   

Hiểu rõ vì sao cơ chế PKCE (S256) và tham số state có thể chống lại CSRF thông thường nhưng không thể ngăn chặn COSF khi ứng dụng không xác minh sự ràng buộc giữa phiên ủy quyền (state_user) với phiên đăng nhập của người dùng trên trình duyệt (session_user) tại Redirection Endpoint.   

Thực hành đầy đủ quy trình tấn công 1-Click Connector Account Takeover: khởi tạo luồng OAuth từ tài khoản attacker, dùng proxy chặn lấy Authorization Request URI chứa state cố định phiên, gửi sang nạn nhân để chiếm quyền truy cập dữ liệu của nạn nhân trên Resource API.   

Rèn luyện kỹ năng phát hiện tấn công bằng Wazuh SIEM dựa trên nhật ký kiểm toán ngữ cảnh ràng buộc phiên (binding_status, owner_relation, outcome): kiểm thử luật bằng wazuh-logtest và phân tích cảnh báo trong alerts.json.

Kỹ năng đạt được

Cấu hình HTTP Proxy trên Firefox và sử dụng mitmweb để chặn (intercept) Authorization Request URI (/protocol/openid-connect/auth).   

Khai thác lỗ hổng cố định phiên ủy quyền qua tham số state để gắn trái phép kết nối Connector của nạn nhân vào tài khoản ứng dụng của kẻ tấn công.   

Sử dụng wazuh-logtest để kiểm chứng bộ luật phát hiện của Wazuh Manager đối với các trạng thái ràng buộc phiên (matched, mismatched, unavailable).

Truy vấn và đối chiếu chuỗi cảnh báo từ /var/ossec/logs/alerts/alerts.json kết hợp log dịch vụ để chứng minh toàn bộ chuỗi tấn công từ lúc callback sai ràng buộc đến khi đọc dữ liệu API trái phép.

2. Kịch bản
Tình huống:

Công ty sử dụng Keycloak làm hệ thống xác thực tập trung SSO (Single Sign-On) cho hai ứng dụng nội bộ: Employee Portal và Document Portal. Để nhân viên có thể đồng bộ và tra cứu hồ sơ công việc lưu trữ trên Resource API, Employee Portal cung cấp chức năng "Kết nối kho tài liệu" sử dụng giao thức OAuth 2.0 (Authorization Code Flow kết hợp PKCE S256). Đội ngũ phát triển Employee Portal đã thiết kế cơ chế lưu trữ phiên ủy quyền OAuth trên server gắn với tham số state (Session in state) và sử dụng trực tiếp danh tính người khởi tạo trong state tại Redirection Endpoint để lưu kết nối mà không cưỡng chế chặn khi phiên trình duyệt tại callback bị lệch.   

Gần đây, hệ thống Wazuh SIEM ghi nhận các cảnh báo liên kết OAuth sai ràng buộc phiên (binding_status=mismatched) và phát hiện hồ sơ nội bộ trên Resource API của một số nhân viên bị truy xuất từ tài khoản của người khác. Sinh viên đóng vai trò chuyên gia kiểm thử xâm nhập để tái hiện toàn bộ kịch bản tấn công Cross-user OAuth Session Fixation, đồng thời đóng vai kỹ sư SOC vận hành Wazuh SIEM để kiểm chứng bộ luật phát hiện và phân tích bằng chứng.

Vai trò của sinh viên:

Đóng vai attacker, đăng nhập vào Employee Portal bằng tài khoản của mình, khởi tạo yêu cầu liên kết Connector và dùng proxy (mitmweb) chặn lấy Authorization Request URI (/protocol/openid-connect/auth) có chứa tham số state định danh phiên ủy quyền của attacker.   

Đóng vai victim, mở Authorization Request URI trên trình duyệt của nạn nhân (nơi đã có sẵn phiên SSO của student) để hoàn tất luồng OAuth, qua đó chứng minh tài khoản attacker chiếm được kết nối Connector và đọc được dữ liệu của student trên Resource API.   

Đóng vai chuyên gia Blue Team / kỹ sư SOC, sử dụng Wazuh SIEM (wazuh-logtest và alerts.json) để phân tích các cảnh báo theo mức độ bằng chứng: từ nghi vấn tại callback (Rule 100502) đến xác nhận lưu liên kết sai ràng buộc (Rule 100503).

Sơ đồ luồng tấn công

```text
Attacker (172.28.50.30)      Victim User (172.28.50.10)      Employee Portal (.20:5001)     Keycloak AS (.20:8080)     Resource API (.20:8000)
       |                                  |                               |                          |                         |
       | 1. Khởi tạo OAuth (GET /connect) |                               |                          |                         |
       |--------------------------------->|                               |                          |                         |
       | 2. Nhận Authz Req URI với        |                               |                          |                         |
       |    state=attacker_auth_session   |                               |                          |                         |
       |<---------------------------------|                               |                          |                         |
       | [Mitmweb chặn & Drop request]    |                               |                          |                         |
       |                                  |                               |                          |                         |
       | 3. Gửi Authz Req URI cho Victim  |                               |                          |                         |
       |--------------------------------->|                               |                          |                         |
       |                                  | 4. Mở Authz Req URI (bỏ qua consent nhờ phiên SSO sẵn có)|                         |
       |                                  |--------------------------------------------------------->|                         |
       |                                  | 5. Redirect kèm code_victim + state=attacker_auth_session|                         |
       |                                  |<---------------------------------------------------------|                         |
       |                                  | 6. GET /connect/callback?code=code_victim&state=...      |                         |
       |                                  |------------------------------>|                          |                         |
       |                                  |                               | 7. Đổi code_victim + PKCE|                         |
       |                                  |                               |<------------------------>|                         |
       |                                  |                               | 8. Lưu connection cho    |                         |
       |                                  |                               |    "attacker" (committed)|                         |
       | 9. Truy cập trang chủ (GET /)    |                               |                          |                         |
       |--------------------------------->|                               |                          |                         |
       |                                  |                               | 10. Gọi API bằng token   |                         |
       |                                  |                               |     của Victim           |                         |
       |                                  |                               |<-------------------------------------------------->|
       | 11. Đọc trái phép dữ liệu Victim |                               |                          |                         |
       |<---------------------------------|                               |                          |                         |
```
3. Kiến thức bổ trợ
Kiến trúc hệ thống SSO, Connector và Wazuh SIEM trong Lab

Lab gồm ba container:   

| Thành phần | Container | Địa chỉ IP | Vai trò |
| --- | --- | --- | --- |
| Firefox | client | 172.28.50.10 |  |
Máy nạn nhân (Victim) 

| Firefox + mitmproxy | attacker | 172.28.50.30 |  |
| --- | --- | --- | --- |
Máy tấn công (Attacker) 

| Keycloak + Portals + API + Wazuh | server | 172.28.50.20 | Identity Provider, các ứng dụng và Wazuh SIEM |
| --- | --- | --- | --- |
Các dịch vụ chạy trên container server:

| Dịch vụ | Địa chỉ / Đường dẫn | Mô tả |
| --- | --- | --- |
| Keycloak (IdP / AS) | http://idp.lab:8080 |  |
Máy chủ định danh SSO và cấp quyền OAuth Connector 

| Employee Portal (Client) | http://employee.lab:5001 | Ứng dụng tích hợp Connector chứa lỗ hổng COSF |
| --- | --- | --- |
| Document Portal | http://documents.lab:5002 |  |
Ứng dụng nội bộ dùng để kiểm chứng cơ chế đăng nhập một lần (SSO) 

| Resource API (RS) | http://api.lab:8000/api/protected | Dịch vụ tài nguyên cung cấp hồ sơ nội bộ theo Access Token của Connector |
| --- | --- | --- |
| Wazuh Manager (SIEM) | /var/ossec/logs/alerts/alerts.json | Hệ thống SIEM phân tích audit log và cảnh báo tấn công COSF |
Bản chất lỗ hổng Cross-user OAuth Session Fixation (COSF)

Theo tài liệu IETF draft-ietf-oauth-security-topics-update-03 (Mục 2.3) và công trình nghiên cứu tại IEEE S&P 2026, trong mô hình liên kết tài khoản OAuth (OAuth-based Account Linking), ứng dụng bắt buộc phải đảm bảo nguyên tắc toàn vẹn phiên:   

Người dùng ứng dụng khởi tạo luồng OAuth (state_user) == Người dùng ứng dụng hoàn tất luồng OAuth tại Redirection Endpoint (session_user).   

Lưu ý rằng trong thực tế, một người dùng có thể hợp lệ liên kết tài khoản ứng dụng của mình (lan.employee) với một tài khoản dịch vụ bên ngoài có tên khác (lan.personal). Do đó, bản chất của COSF không nằm ở việc so sánh tên tài khoản ứng dụng với tên tài khoản dịch vụ (app_user != connector_user), mà nằm ở việc phiên ủy quyền do người dùng A khởi tạo tại ứng dụng (state_user) lại được hoàn tất bởi người dùng B (session_user), nhưng kết nối tạo ra vẫn được ứng dụng lưu cho người khởi tạo A (owner_relation = initiator, outcome = committed).   

Cơ chế ghi nhận Audit Log và Phát hiện bằng Wazuh SIEM

Tại Redirection Endpoint (/connect/callback), hệ thống kiểm toán của Employee Portal đối chiếu danh tính người dùng ứng dụng khởi tạo giao dịch (state_user lưu trong giao dịch oauth_state_id) với danh tính người dùng ứng dụng hiện đang giữ phiên trên trình duyệt (session_user) để xác định trạng thái ràng buộc binding_status:

matched: Đã xác minh hai danh tính ứng dụng trùng khớp (state_user == session_user).

mismatched: Đã xác minh hai danh tính ứng dụng khác nhau (state_user != session_user) — người hoàn tất callback khác với người khởi tạo.

unavailable: Trình duyệt gọi callback không có phiên đăng nhập ứng dụng nên không thể xác minh danh tính người hoàn tất.   

Khi lưu kết nối (connection_id), ứng dụng giữ lại oauth_state_id và binding_status của giao dịch tạo ra kết nối đó, đồng thời ghi owner_relation="initiator" và outcome="committed". Hệ thống Wazuh Manager đọc trực tiếp /var/log/sso/sso.json và phân tích theo các mức độ bằng chứng:

Rule 100502 (Level 10 - Nghi vấn COSF): Kích hoạt tại sự kiện connect_callback_received khi binding_status=mismatched. Lúc này mới phát hiện callback khác người, chưa khẳng định liên kết đã được lưu.

Rule 100503 (Level 14 - Xác nhận liên kết sai ràng buộc): Kích hoạt tại sự kiện connector_linked khi binding_status=mismatched, owner_relation=initiator và outcome=committed. Đây là bằng chứng mạnh khẳng định ứng dụng đã lưu liên kết của người hoàn tất cho người khởi tạo.   

Rule 100505 (Level 12 - Liên kết khi chưa xác minh ràng buộc): Kích hoạt khi binding_status=unavailable nhưng ứng dụng vẫn lưu liên kết (outcome=committed).

Bảng tùy chọn và cú pháp công cụ sử dụng trong bài

| Công cụ | Tùy chọn / Cú pháp | Mô tả tác dụng |
| --- | --- | --- |
| mitmweb | mitmweb -p 8080 >/dev/null 2>&1 & |  |
Khởi chạy Proxy MITM ở cổng 8080 để quản lý và chặn gói tin 

| firefox | firefox >/dev/null 2>&1 & |  |
| --- | --- | --- |
Trình duyệt dùng để đăng nhập và thực hiện liên kết Connector 

| wazuh-logtest | sudo /var/ossec/bin/wazuh-logtest | Kiểm thử quá trình giải mã JSON và khớp luật phát hiện trên Wazuh Manager |
| --- | --- | --- |
| jq | sudo grep "oauth_cosf" /var/ossec/logs/alerts/alerts.json | jq ... | Truy vấn và trích xuất các cảnh báo COSF từ Wazuh SIEM |
| getent | getent hosts <hostname> |  |
Kiểm tra phân giải tên miền hệ thống 

4. Các nhiệm vụ của bài thực hành
Để khởi động bài thực hành, sinh viên dùng câu lệnh:

```bash
labtainer sso-oauth-cosf
(Chú ý: sinh viên sử dụng mã sinh viên của mình để nhập thông tin email người thực hiện bài lab khi có yêu cầu, để sử dụng khi chấm điểm)   
```

Sau khi khởi động xong, ba terminal ảo sẽ xuất hiện tương ứng với 3 máy: client, attacker và server.   

Tài khoản thực hành

Tài khoản Nạn nhân (Victim): student / Student-2026!   

Tài khoản Kẻ tấn công (Attacker): attacker / Attacker-2026!   

Nhiệm vụ 1 – sso_verified: Kiểm tra môi trường và tính năng SSO

Trước khi bắt đầu tấn công, cần đảm bảo các dịch vụ SSO cùng hệ thống Wazuh Manager đang hoạt động ổn định và xác nhận tính năng Single Sign-On trên máy nạn nhân (client).   

Bước 1: Tại cửa sổ terminal client và attacker, kiểm tra phân giải tên miền:   

```bash
getent hosts idp.lab employee.lab documents.lab api.lab
Kết quả đúng: tất cả các tên miền đều trỏ về IP 172.28.50.20.   
```

Bước 2: Tại cửa sổ terminal server, kiểm tra trạng thái các dịch vụ SSO và Wazuh Manager:

```bash
sudo systemctl --no-pager --full status keycloak api employee documents wazuh-manager
Tất cả các dịch vụ phải ở trạng thái active (running).   
```

Bước 3: Tại terminal client, mở trình duyệt Firefox:   

```bash
firefox >/dev/null 2>&1 &
Bước 4: Trên Firefox của client, truy cập [http://employee.lab:5001](http://employee.lab:5001), nhấn Đăng nhập với tài khoản nạn nhân:   
```

```text
student / Student-2026!
Xác nhận màn hình hiển thị Xin chào, Sinh viên SSO (student), đồng thời tại khu vực Kho tài liệu cá nhân đang hiển thị [Kết nối kho tài liệu] (không nhấn nút kết nối ở bước này).
```

Bước 5: Mở một tab mới trên Firefox của client, truy cập [http://documents.lab:5002](http://documents.lab:5002) và nhấn Đăng nhập.   

Trình duyệt sẽ vào thẳng trang tài liệu dưới tài khoản student mà không yêu cầu nhập lại mật khẩu nhờ phiên SSO tại Keycloak (idp.lab:8080). Đồng thời, Document Portal tự động gọi Resource API và hiển thị:
- **Tài liệu của tôi — student**
  - Ho_so_student.pdf
  - Chung_nhan_student.pdf
(Document Portal là dịch vụ kho tài liệu chính chủ, chỉ hiển thị danh sách tài liệu cá nhân, không có nút kết nối, tải lên hay chỉnh sửa). Thu nhỏ cửa sổ Firefox của client lại, không tắt trình duyệt.   

Điều kiện hoàn thành nhiệm vụ: Các tên miền phân giải đúng, tất cả dịch vụ và wazuh-manager đều Active, đăng nhập thành công vào Employee Portal và Document Portal tự động nhận phiên SSO.   

Câu hỏi 1:

Trong hệ thống của bài thực hành, hãy phân biệt vai trò của bước "Đăng nhập" ban đầu vào Employee Portal với bước "Kết nối kho tài liệu"? Vì sao phiên SSO đã thiết lập tại Keycloak trên trình duyệt của nạn nhân lại giúp kịch bản tấn công ở các bước sau diễn ra chỉ với một cú nhấp chuột (1-Click) mà không hiện bảng hỏi quyền (consent prompt)?

Trả lời: _______________________________________

Nhiệm vụ 2 – proxy_ready: Chuẩn bị hệ thống Proxy và phiên làm việc cho Attacker

Sinh viên đóng vai attacker trên máy attacker (172.28.50.30). Để thực hiện tấn công Cross-user OAuth Session Fixation, attacker cần đăng nhập vào tài khoản ứng dụng của mình trên Employee Portal trước, sau đó thiết lập proxy mitmweb để chặn giữ Authorization Request URI (/protocol/openid-connect/auth) khi khởi tạo liên kết Connector.   

Bước 1: Tại cửa sổ terminal attacker, khởi chạy Mitmweb ở cổng 8080:   

```bash
mitmweb -p 8080 >/dev/null 2>&1 &
Lệnh này khởi động proxy và tự động mở cửa sổ Firefox truy cập vào giao diện quản lý Mitmweb tại địa chỉ [http://127.0.0.1:8081](http://127.0.0.1:8081).   
```

Bước 2: Cấu hình Proxy cho Firefox của Attacker:   

Vào Settings → Network Settings → Settings...   

Chọn Manual proxy configuration.   

Ở ô HTTP Proxy, điền 127.0.0.1 và ô Port điền 8080, nhấn OK.   

Bước 3: Mở một tab mới trên Firefox của attacker, truy cập [http://employee.lab:5001](http://employee.lab:5001) và nhấn Đăng nhập bằng tài khoản của attacker:

```text
attacker / Attacker-2026!
Xác nhận màn hình hiển thị Xin chào, Attacker SSO (attacker) và có nút Kết nối kho tài liệu.
```

Bước 4: Thiết lập Intercept Filter trên Mitmweb:

Quay lại tab giao diện Mitmweb ([http://127.0.0.1:8081](http://127.0.0.1:8081)), tìm thanh tìm kiếm Intercept.   

Gõ vào thanh Intercept biểu thức: ~u /protocol/openid-connect/auth

Biểu thức này ra lệnh cho Mitmweb tự động chặn và giữ lại bất kỳ gói tin nào điều hướng tới đường dẫn cấp quyền /protocol/openid-connect/auth của Keycloak.

Điều kiện hoàn thành nhiệm vụ: Firefox của attacker đã cấu hình proxy thành công, attacker đã đăng nhập vào Employee Portal và luật Intercept ~u /protocol/openid-connect/auth đã được áp dụng.

Câu hỏi 2:

Vì sao trong kịch bản tấn công Cross-user OAuth Session Fixation, kẻ tấn công lại sử dụng Intercept để chặn Authorization Request URI (/protocol/openid-connect/auth) ngay khi bắt đầu luồng OAuth thay vì chặn Redirection URI (/connect/callback) như trong tấn công Login CSRF?

Trả lời: _______________________________________

Nhiệm vụ 3 – capture_auth_url: Khởi tạo luồng OAuth và trích xuất Authorization Request URI cố định phiên

Attacker khởi tạo yêu cầu liên kết Resource Connector từ tài khoản attacker của mình. Employee Portal sẽ sinh ra một phiên ủy quyền mới gắn với attacker được mã hóa qua tham số state (state_user = attacker). Nhờ luật Intercept đã thiết lập, request chuyển hướng tới Keycloak sẽ bị giữ lại để attacker thu thập Authorization Request URI này.   

Bước 1: Trên Firefox của attacker, tại tab Employee Portal ([http://employee.lab:5001](http://employee.lab:5001)), nhấn vào nút Kết nối kho tài liệu.

Bước 2: Trình duyệt sẽ bị treo (trạng thái loading) vì request chuyển hướng tới Keycloak đã bị Mitmweb giữ lại.

Bước 3: Chuyển sang tab Mitmweb ([http://127.0.0.1:8081](http://127.0.0.1:8081)). Bạn sẽ thấy một request đang tạm dừng với URL dạng:

```text
http://idp.lab:8080/realms/sso-lab/protocol/openid-connect/auth?client_id=employee-portal&redirect_uri=http%3A%2F%2Femployee.lab%3A5001%2Fconnect%2Fcallback&response_type=code&scope=openid+profile+email+resource-api-access&state=...&nonce=...&code_challenge=...&code_challenge_method=S256
Bước 4: Sao chép toàn bộ Authorization Request URI trên (bao gồm đầy đủ state, nonce, code_challenge, redirect_uri...), sau đó nhấn nút Drop (biểu tượng thùng rác) trên Mitmweb để hủy request gốc trên máy attacker.
```

Điều kiện hoàn thành nhiệm vụ: Đã khởi tạo luồng /connect từ tài khoản attacker, sao chép được Authorization Request URI chứa tham số state cố định phiên và hủy request trên proxy.

Câu hỏi 3:

Quan sát Authorization Request URI vừa thu thập được, bạn thấy có mặt đầy đủ cả tham số state và code_challenge (code_challenge_method=S256). Vì sao việc Attacker nhấn Drop để hủy request trên máy của mình và gửi URI này cho Nạn nhân mở lại giúp bảo toàn tính hợp lệ của cơ chế PKCE ở bước đổi token sau đó?

Trả lời: _______________________________________

Nhiệm vụ 4 – cosf_exploit_success: Khai thác Cross-user OAuth Session Fixation trên Nạn nhân

Attacker gửi Authorization Request URI vừa thu được sang máy Victim (client). Khi Victim truy cập URI này, trình duyệt của Victim sẽ hoàn tất cả bước xin cấp quyền tại Keycloak lẫn bước gửi code và state về Redirection Endpoint của Employee Portal, khiến kết nối Connector của Victim bị lưu cho tài khoản của Attacker.   

Bước 1: Chuyển sang máy client (Victim). Trên Firefox của client (nơi đang có phiên đăng nhập của student), mở một tab mới.   

Bước 2: Dán toàn bộ Authorization Request URI (/protocol/openid-connect/auth?...&state=...) vừa sao chép vào thanh địa chỉ và nhấn Enter.   

Bước 3: Quan sát hiện tượng trên trình duyệt của client (Victim):

Nhờ phiên SSO của student tại Keycloak, trình duyệt tự động nhận Authorization Code của student, chuyển hướng về [http://employee.lab:5001/connect/callback?state=...&code=](http://employee.lab:5001/connect/callback?state=...&code=)... rồi quay về trang chủ Employee Portal.   

Trên màn hình của client, giao diện vẫn hiển thị Xin chào, Sinh viên SSO (student) như bình thường. Phiên đăng nhập ứng dụng trên trình duyệt của nạn nhân không hề bị thay đổi.

Bước 4: Quay trở lại máy attacker (172.28.50.30). Trên Firefox của attacker, truy cập lại hoặc tải lại (Refresh) trang chủ Employee Portal:

```text
http://employee.lab:5001/
Bước 5: Quan sát kết quả khai thác trên màn hình của Attacker:
```

Tài khoản ứng dụng (Application Account): attacker   

Kho tài liệu cá nhân: Đã kết nối   

Tài khoản kho tài liệu: student   

Danh sách tài liệu lấy từ Resource API:
- Ho_so_student.pdf
- Chung_nhan_student.pdf
(Có nút [Ngắt kết nối] để hủy liên kết).

Kiểm chứng đối chiếu: Mở tab Document Portal trên máy attacker (http://documents.lab:5002), bạn sẽ thấy Document Portal của attacker vẫn chỉ hiển thị tài liệu của riêng attacker (Ho_so_attacker.pdf, Chung_nhan_attacker.pdf). Điều này chứng minh phiên đăng nhập của attacker không hề bị đổi; lỗ hổng chỉ nằm ở việc Employee Portal gán sai quyền truy cập kho tài liệu của student cho attacker!

Điều kiện hoàn thành nhiệm vụ: Danh tính attacker tại Employee Portal liên kết thành công với Connector của student và truy xuất được tài nguyên của student từ Resource API.

Câu hỏi 4:

So sánh hậu quả thực tế giữa tấn công Login CSRF và tấn công Cross-user OAuth Session Fixation (COSF): Sau khi nạn nhân mở đường dẫn độc hại, trạng thái hiển thị trên trình duyệt của nạn nhân ở hai cuộc tấn công này khác nhau như thế nào? Vì sao COSF lại nguy hiểm và khó bị nạn nhân phát hiện hơn?

Trả lời: _______________________________________

Nhiệm vụ 5 – cosf_detected: Phát hiện và phân tích tấn công COSF bằng Wazuh SIEM

Đóng vai chuyên gia Blue Team / kỹ sư SOC trên máy server (172.28.50.20). Hệ thống Wazuh Manager thu thập nhật ký kiểm toán JSON tại /var/log/sso/sso.json và đối chiếu với bộ luật phát hiện trong /var/ossec/etc/rules/local_rules.xml. Nhiệm vụ của bạn là kiểm tra cấu hình rule của Wazuh, sử dụng wazuh-logtest để kiểm chứng cơ chế phát hiện và dùng jq truy vấn chuỗi cảnh báo tấn công từ /var/ossec/logs/alerts/alerts.json.

Bước 1: Tại cửa sổ terminal server, kiểm tra nội dung bộ luật phát hiện COSF trong Wazuh:

```bash
sudo cat /var/ossec/etc/rules/local_rules.xml
```
Quan sát các điều kiện kiểm tra trường binding_status, owner_relation và outcome trên các rule 100502, 100503 và 100505.

Bước 2: Sử dụng công cụ wazuh-logtest để kiểm chứng cách Wazuh giải mã (decode) và kích hoạt cảnh báo đối với bản ghi sự kiện connector_linked thực tế vừa sinh ra trong /var/log/sso/sso.json:

```bash
grep '"event": "connector_linked"' /var/log/sso/sso.json | tail -n 1 | sudo /var/ossec/bin/wazuh-logtest
```
Quan sát kết quả ở **Phase 2: Completed decoding** (Wazuh bóc tách data.binding_status: 'mismatched', data.owner_relation: 'initiator', data.outcome: 'committed') và tại **Phase 3: Completed filtering (rules)** kích hoạt Rule 100503 (Level 14): "[COSF - LIEN KET SAI RANG BUOC] Da luu cho attacker...".

Bước 3: Truy vấn danh sách các cảnh báo COSF đã được Wazuh SIEM tự động ghi nhận trong /var/ossec/logs/alerts/alerts.json:

```bash
sudo grep "oauth_cosf" /var/ossec/logs/alerts/alerts.json | jq -r '"[\(.rule.id)] (Level \(.rule.level)) \(.rule.description)"'
```
Quan sát chuỗi cảnh báo tấn công COSF cùng thuộc một mã giao dịch transaction (oauth_state_id):

Rule 100502 (Level 10 - Nghi vấn COSF): Phát hiện tại bước connect_callback_received có binding_status=mismatched (người khởi tạo là attacker nhưng phiên trình duyệt hoàn tất callback là student).

Rule 100503 (Level 14 - Liên kết sai ràng buộc): Xác nhận tại bước connector_linked, hệ thống vẫn lưu liên kết (outcome=committed) cho người khởi tạo (owner_relation=initiator, app_user=attacker) dù binding_status=mismatched.

Điều kiện hoàn thành nhiệm vụ: Đã kiểm tra bộ luật Wazuh, chạy kiểm thử với wazuh-logtest và truy vấn thành công chuỗi cảnh báo tấn công COSF từ /var/ossec/logs/alerts/alerts.json.

Câu hỏi 5:

Vì sao khi thiết kế cơ chế phát hiện COSF, chúng ta phải xác định binding_status dựa trên việc so sánh người dùng ứng dụng khởi tạo (state_user) với người dùng ứng dụng tại bước callback (session_user), chứ không được kết luận tấn công chỉ dựa vào việc tên tài khoản ứng dụng khác với tên tài khoản dịch vụ (app_user != connector_user)? Hãy phân biệt ý nghĩa bằng chứng giữa cảnh báo Rule 100502, Rule 100503 và Rule 100505?

Trả lời: _______________________________________

Câu hỏi 6:

Theo mục 2.3.2 (Countermeasures) của tài liệu IETF draft-ietf-oauth-security-topics-update-03, để phòng chống triệt để lỗ hổng Cross-user OAuth Session Fixation, Client phải thực hiện kiểm tra gì tại Redirection Endpoint trước khi gửi yêu cầu đổi mã lấy Access Token? Nếu ứng dụng chặn ngay từ khi phát hiện binding_status != matched tại bước callback, những cảnh báo nào trong Wazuh sẽ xuất hiện và cảnh báo nào sẽ không bao giờ xảy ra?

Trả lời: _______________________________________

---
*Học viện Công nghệ Bưu chính Viễn thông - SecLab PTIT*
