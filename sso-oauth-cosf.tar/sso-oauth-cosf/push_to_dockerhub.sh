#!/bin/bash
set -e
for lab in sso-oauth-cosf; do
    for img in client server attacker; do
        echo "Pushing $lab.$img.student..."
        docker push trung8924/$lab.$img.student:latest || true
        docker push trung8924/$lab.$img.student:base_image739eee77f8d3 || true
    done
done
