"""
SSO Portals (Employee, Documents) và Resource API cho bài lab sso-oauth-cosf.
Triển khai mô hình OAuth-based Account Linking và tái hiện lỗ hổng
Cross-user OAuth Session Fixation (COSF) theo IETF draft-ietf-oauth-security-topics-update-03.
"""

import base64
import hashlib
import json
import logging
import os
import secrets
import time
from datetime import timedelta
from pathlib import Path

import jwt
import requests
from flask import (
    Flask,
    abort,
    jsonify,
    redirect,
    render_template,
    request,
    session,
    url_for,
)
from flask_session import Session

SERVICE = os.environ["SERVICE"]

if SERVICE not in {
    "employee",
    "documents",
    "api",
}:
    raise RuntimeError("Invalid SERVICE")

PORT = int(os.environ["PORT"])
IS_PORTAL = SERVICE != "api"

ISSUER = os.environ.get(
    "OIDC_ISSUER",
    "http://idp.lab:8080/realms/sso-lab",
).rstrip("/")

API_URL = os.environ.get(
    "API_URL",
    "http://api.lab:8000/api/protected",
)

CLIENT_ID = os.environ.get(
    "CLIENT_ID",
    "",
)

CLIENT_SECRET = os.environ.get(
    "CLIENT_SECRET",
    "",
)

BASE_URL = os.environ.get(
    "BASE_URL",
    "",
).rstrip("/")

OTHER_URL = os.environ.get(
    "OTHER_URL",
    "",
)

OIDC_SECURITY_MODE = os.environ.get(
    "OIDC_SECURITY_MODE",
    "secure",
)

if IS_PORTAL and OIDC_SECURITY_MODE not in {
    "secure",
    "cosf-vulnerable",
    "login-csrf-vulnerable",
}:
    raise RuntimeError("Invalid OIDC_SECURITY_MODE")

COSF_VULNERABLE = (
    IS_PORTAL
    and OIDC_SECURITY_MODE == "cosf-vulnerable"
)

DATA_DIR = (
    Path(
        os.environ.get(
            "SSO_DATA_ROOT",
            "/var/lib/sso",
        )
    )
    / SERVICE
)

PENDING_FILE = DATA_DIR / "pending_oauth.json"
VAULT_FILE = DATA_DIR / "vault.json"
LOG_FILE = Path("/var/log/sso/sso.json")

TITLES = {
    "employee": "Cổng nhân viên",
    "documents": "Cổng tài liệu",
    "api": "Resource API",
}

app = Flask(__name__)

logging.getLogger("werkzeug").setLevel(logging.ERROR)

http = requests.Session()
http.trust_env = False

# Lấy khóa công khai của Keycloak qua JWKS
jwks = jwt.PyJWKClient(
    ISSUER + "/protocol/openid-connect/certs",
    timeout=10,
)


def event(name, **fields):
    """
    Ghi log JSON kiểm toán nguyên bản (Raw Audit Log).
    Đồng thời ghi ra stdout và file /var/log/sso/sso.json cho Wazuh SIEM thu thập.
    Thứ tự các trường được bảo toàn để biểu thức chính quy PCRE2 và Labtainer grader đối chiếu chính xác.
    """
    record = {
        "timestamp": time.time(),
        "component": SERVICE,
        "event": name,
    }
    record.update(fields)

    try:
        record.setdefault("source_ip", request.remote_addr)
        record.setdefault("path", request.path)
        record.setdefault("user_agent", request.headers.get("User-Agent", ""))
    except Exception:
        pass

    line = json.dumps(record, ensure_ascii=False)
    print(line, flush=True)

    try:
        LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass


def b64url(data):
    """Mã hóa Base64 URL-safe không chứa dấu bằng."""
    return (
        base64.urlsafe_b64encode(data)
        .rstrip(b"=")
        .decode("ascii")
    )


def verify_token(token, audience):
    """Xác minh JWT bằng khóa công khai của Keycloak."""
    signing_key = jwks.get_signing_key_from_jwt(token).key
    return jwt.decode(
        token,
        signing_key,
        algorithms=["RS256"],
        issuer=ISSUER,
        audience=audience,
        leeway=5,
        options={
            "require": [
                "exp",
                "iat",
                "iss",
                "aud",
                "sub",
            ]
        },
    )


def load_json_file(path):
    """Đọc dữ liệu từ file JSON."""
    try:
        if path.exists():
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception:
        pass
    return {}


def save_json_file(path, data):
    """Ghi dữ liệu an toàn vào file JSON."""
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        temp_path = path.with_suffix(".tmp")
        with open(temp_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        os.replace(temp_path, path)
    except Exception as e:
        app.logger.error("Error saving %s: %s", path, e)


class LoginRequired(Exception):
    """Phiên cần thực hiện đăng nhập lại."""


if IS_PORTAL:
    if not all((CLIENT_ID, CLIENT_SECRET, BASE_URL, OTHER_URL)):
        raise RuntimeError("Missing portal configuration")

    DATA_DIR.mkdir(parents=True, exist_ok=True)

    key_file = DATA_DIR / "session.key"
    if not key_file.exists():
        fd = os.open(
            str(key_file),
            os.O_WRONLY | os.O_CREAT | os.O_EXCL,
            0o600,
        )
        with os.fdopen(fd, "w") as output:
            output.write(secrets.token_hex(32))

    app.config.update(
        SECRET_KEY=key_file.read_text().strip(),
        SESSION_TYPE="filesystem",
        SESSION_FILE_DIR=str(DATA_DIR / "sessions"),
        SESSION_USE_SIGNER=True,
        SESSION_COOKIE_NAME=SERVICE + "_session",
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SECURE=False,
        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_PERMANENT=True,
        PERMANENT_SESSION_LIFETIME=timedelta(minutes=60),
    )

    Session(app)


@app.after_request
def response_headers(response):
    response.headers["Cache-Control"] = "no-store"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    return response


@app.get("/health")
def health():
    return jsonify(status="ok", service=SERVICE)


if IS_PORTAL:

    def page(error=None, status=200, connector=None, doc_files=None, doc_error=None):
        return (
            render_template(
                "index.html",
                title=TITLES[SERVICE],
                kind=SERVICE,
                user=session.get("user"),
                other_url=OTHER_URL,
                csrf=session.get("form_csrf", ""),
                error=error,
                connector=connector,
                doc_files=doc_files,
                doc_error=doc_error,
            ),
            status,
        )

    def token_endpoint_request(data):
        """Gửi yêu cầu đến Token Endpoint."""
        return http.post(
            ISSUER + "/protocol/openid-connect/token",
            auth=(CLIENT_ID, CLIENT_SECRET),
            data=data,
            timeout=10,
        )

    def exchange_authorization_code(code, redirect_uri, code_verifier=None):
        """Đổi Authorization Code lấy token."""
        data = {
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": redirect_uri,
        }
        if code_verifier:
            data["code_verifier"] = code_verifier

        response = token_endpoint_request(data)
        response.raise_for_status()
        tokens = response.json()
        if not isinstance(tokens, dict):
            raise ValueError("Invalid token response")
        return tokens

    def validate_token_response(tokens, expected_nonce=None, require_nonce=True):
        """Xác minh token do Keycloak trả về."""
        if str(tokens.get("token_type", "")).lower() != "bearer":
            raise ValueError("Invalid token type")

        access_token = tokens["access_token"]
        id_token = tokens["id_token"]

        claims = verify_token(id_token, CLIENT_ID)

        if require_nonce:
            returned_nonce = claims.get("nonce")
            if (
                not isinstance(expected_nonce, str)
                or not expected_nonce
                or not isinstance(returned_nonce, str)
                or not secrets.compare_digest(returned_nonce, expected_nonce)
            ):
                raise ValueError("Invalid nonce")

        authorized_party = claims.get("azp")
        if authorized_party is not None and authorized_party != CLIENT_ID:
            raise ValueError("Invalid azp")

        if "at_hash" in claims:
            digest = hashlib.sha256(access_token.encode("ascii")).digest()
            expected_at_hash = b64url(digest[: len(digest) // 2])
            returned_at_hash = claims["at_hash"]
            if (
                not isinstance(returned_at_hash, str)
                or not secrets.compare_digest(expected_at_hash, returned_at_hash)
            ):
                raise ValueError("Invalid at_hash")

        return claims

    def store_login_session(claims, tokens):
        """Tạo phiên ứng dụng sau khi đăng nhập."""
        user = {
            "sub": claims["sub"],
            "username": claims.get("preferred_username", claims["sub"]),
            "name": claims.get(
                "name",
                claims.get("preferred_username", "Người dùng"),
            ),
        }

        tokens["expires_at"] = time.time() + int(tokens.get("expires_in", 0))

        session.clear()
        session.permanent = True
        session["user"] = user
        session["tokens"] = tokens
        session["form_csrf"] = secrets.token_urlsafe(32)

        app.session_interface.regenerate(session)

        event(
            "login_success",
            username=user["username"],
            subject=user["sub"],
            sso_sid=claims.get("sid"),
            auth_time=claims.get("auth_time"),
            client_id=CLIENT_ID,
            security_mode=OIDC_SECURITY_MODE,
        )

    @app.get("/")
    def index():
        if not session.get("user"):
            return page()

        username = session["user"]["username"]

        if not session.get("form_csrf"):
            session["form_csrf"] = secrets.token_urlsafe(32)

        connector_data = None
        doc_files = []
        doc_error = None

        if SERVICE == "documents":
            access_token = session.get("tokens", {}).get("access_token", "")
            if access_token:
                try:
                    api_response = http.get(
                        API_URL,
                        headers={
                            "Authorization": "Bearer " + access_token,
                            "User-Agent": "SSO-Portal/" + SERVICE,
                        },
                        timeout=10,
                    )
                    if api_response.status_code == 200:
                        doc_files = api_response.json().get("files", [])
                    else:
                        doc_error = f"Lỗi truy xuất tài liệu (Mã: {api_response.status_code})"
                except requests.RequestException:
                    doc_error = "Không thể kết nối Resource API"

        elif SERVICE == "employee":
            vault = load_json_file(VAULT_FILE)
            connector_info = vault.get(username)

            if connector_info:
                # Đã có liên kết Connector trong Vault, gọi Resource API bằng token này
                access_token = connector_info.get("access_token", "")
                try:
                    api_response = http.get(
                        API_URL,
                        headers={
                            "Authorization": "Bearer " + access_token,
                            "User-Agent": "SSO-Portal/" + SERVICE,
                            "X-Connector-Context": "document-vault",
                        },
                        timeout=10,
                    )

                    outcome_api = "success" if api_response.status_code == 200 else "failure"

                    event(
                        "connector_api_call",
                        app_user=username,
                        connector_user=connector_info.get("connector_user", ""),
                        binding_status=connector_info.get("binding_status", ""),
                        owner_relation=connector_info.get("owner_relation", ""),
                        oauth_state_id=connector_info.get("oauth_state_id", ""),
                        connection_id=connector_info.get("connection_id", ""),
                        api_status=str(api_response.status_code),
                        outcome=outcome_api,
                    )

                    if api_response.status_code == 200:
                        api_data = api_response.json()
                        connector_data = {
                            "linked": True,
                            "connector_user": connector_info["connector_user"],
                            "connector_email": connector_info.get("connector_email", ""),
                            "files": api_data.get("files", []),
                        }
                    else:
                        connector_data = {
                            "linked": True,
                            "connector_user": connector_info["connector_user"],
                            "connector_email": connector_info.get("connector_email", ""),
                            "files": [],
                            "error": f"Lỗi truy xuất kho tài liệu (Mã: {api_response.status_code})",
                        }
                except requests.RequestException:
                    event(
                        "connector_api_call",
                        app_user=username,
                        connector_user=connector_info.get("connector_user", ""),
                        binding_status=connector_info.get("binding_status", ""),
                        owner_relation=connector_info.get("owner_relation", ""),
                        oauth_state_id=connector_info.get("oauth_state_id", ""),
                        connection_id=connector_info.get("connection_id", ""),
                        api_status="503",
                        outcome="failure",
                    )
                    connector_data = {
                        "linked": True,
                        "connector_user": connector_info["connector_user"],
                        "connector_email": connector_info.get("connector_email", ""),
                        "files": [],
                        "error": "Không thể kết nối Resource API",
                    }
            else:
                connector_data = {
                    "linked": False,
                }

        return page(connector=connector_data, doc_files=doc_files, doc_error=doc_error)

    @app.get("/login")
    def login():
        """Luồng đăng nhập OIDC tiêu chuẩn kết hợp PKCE và state/nonce."""
        state = secrets.token_urlsafe(32)
        nonce = secrets.token_urlsafe(32)
        verifier = secrets.token_urlsafe(48)

        session["login_tx"] = {
            "state": state,
            "nonce": nonce,
            "verifier": verifier,
            "started": time.time(),
        }

        challenge = b64url(hashlib.sha256(verifier.encode("ascii")).digest())

        parameters = {
            "client_id": CLIENT_ID,
            "redirect_uri": BASE_URL + "/callback",
            "response_type": "code",
            "scope": "openid profile email",
            "state": state,
            "nonce": nonce,
            "code_challenge": challenge,
            "code_challenge_method": "S256",
        }

        authorization_url = (
            requests.Request(
                "GET",
                ISSUER + "/protocol/openid-connect/auth",
                params=parameters,
            )
            .prepare()
            .url
        )

        event(
            "login_started",
            client_id=CLIENT_ID,
            security_mode=OIDC_SECURITY_MODE,
        )

        return redirect(authorization_url)

    @app.get("/callback")
    def callback():
        """Xử lý callback đăng nhập OIDC."""
        states = request.args.getlist("state")
        codes = request.args.getlist("code")

        login_tx = session.pop("login_tx", None)

        if not login_tx or not states or not codes or "error" in request.args:
            event("login_rejected", reason="invalid_callback", client_id=CLIENT_ID)
            return page(error="Yêu cầu đăng nhập không hợp lệ hoặc đã hết hạn.", status=400)

        expected_state = login_tx.get("state", "")
        if not secrets.compare_digest(states[0], expected_state):
            event("login_rejected", reason="state_mismatch", client_id=CLIENT_ID)
            return page(error="Sai lệch tham số state.", status=400)

        try:
            tokens = exchange_authorization_code(
                code=codes[0],
                redirect_uri=BASE_URL + "/callback",
                code_verifier=login_tx.get("verifier"),
            )
            claims = validate_token_response(
                tokens,
                expected_nonce=login_tx.get("nonce"),
                require_nonce=True,
            )
        except Exception as error:
            event("login_rejected", reason=type(error).__name__, client_id=CLIENT_ID)
            session.clear()
            return page(error="Không hoàn tất được đăng nhập.", status=400)

        store_login_session(claims=claims, tokens=tokens)
        return redirect("/")

    @app.get("/connect")
    def connect():
        """
        Khởi tạo luồng liên kết Connector (OAuth-based Account Linking).
        Sinh state, nonce, PKCE (S256), lưu phiên ủy quyền vào pending_oauth.json
        theo mô hình 'Session in state' gắn với app_user = session['user']['username'].
        """
        if not session.get("user"):
            return redirect(url_for("login"))

        current_user = session["user"]["username"]
        current_sub = session["user"].get("sub", "")
        state = secrets.token_urlsafe(32)
        nonce = secrets.token_urlsafe(32)
        verifier = secrets.token_urlsafe(48)
        oauth_state_id = "tx-" + secrets.token_hex(4)

        pending = load_json_file(PENDING_FILE)
        pending[state] = {
            "oauth_state_id": oauth_state_id,
            "app_user": current_user,
            "state_user": current_user,
            "state_user_sub": current_sub,
            "verifier": verifier,
            "nonce": nonce,
            "init_ip": request.remote_addr,
            "started": time.time(),
        }
        save_json_file(PENDING_FILE, pending)

        # Ghi log sự kiện connect_started
        event(
            "connect_started",
            state_user=current_user,
            session_user=current_user,
            oauth_state_id=oauth_state_id,
            outcome="redirected",
        )

        challenge = b64url(hashlib.sha256(verifier.encode("ascii")).digest())

        parameters = {
            "client_id": CLIENT_ID,
            "redirect_uri": BASE_URL + "/connect/callback",
            "response_type": "code",
            "scope": "openid profile email",
            "state": state,
            "nonce": nonce,
            "code_challenge": challenge,
            "code_challenge_method": "S256",
        }

        auth_url = (
            requests.Request(
                "GET",
                ISSUER + "/protocol/openid-connect/auth",
                params=parameters,
            )
            .prepare()
            .url
        )

        return redirect(auth_url)

    @app.get("/connect/callback")
    def connect_callback():
        """
        Redirection Endpoint nhận mã ủy quyền cho luồng Connector.
        Khôi phục phiên ủy quyền từ pending_oauth.json bằng tham số state.
        Trong chế độ cosf-vulnerable, ứng dụng cố ý KHÔNG đối chiếu
        state_user với session_user trên trình duyệt hoàn tất callback.
        """
        states = request.args.getlist("state")
        codes = request.args.getlist("code")

        if not states or not codes or "error" in request.args:
            return page(error="Liên kết Connector thất bại: callback không hợp lệ.", status=400)

        state = states[0]
        code = codes[0]

        pending = load_json_file(PENDING_FILE)
        tx = pending.pop(state, None)
        save_json_file(PENDING_FILE, pending)

        if not tx:
            return page(error="Phiên liên kết không tồn tại hoặc đã hết hạn.", status=400)

        oauth_state_id = tx.get("oauth_state_id", "tx-" + state[:8])
        state_user = tx.get("state_user", tx.get("app_user", ""))
        state_user_sub = tx.get("state_user_sub", "")

        current_user = session.get("user")
        if not current_user or not current_user.get("sub"):
            session_user = "unavailable"
            binding_status = "unavailable"
        elif current_user["sub"] == state_user_sub:
            session_user = current_user.get("username", "")
            binding_status = "matched"
        else:
            session_user = current_user.get("username", "")
            binding_status = "mismatched"

        callback_outcome = "continued" if (COSF_VULNERABLE or binding_status == "matched") else "rejected"

        # Ghi log sự kiện connect_callback_received
        event(
            "connect_callback_received",
            oauth_state_id=oauth_state_id,
            state_user=state_user,
            session_user=session_user,
            binding_status=binding_status,
            outcome=callback_outcome,
        )

        # Kiểm tra bảo mật nếu không ở chế độ có lỗ hổng COSF
        if not COSF_VULNERABLE and binding_status != "matched":
            event(
                "connect_rejected",
                reason="user_session_mismatch",
                oauth_state_id=oauth_state_id,
                state_user=state_user,
                session_user=session_user,
                binding_status=binding_status,
            )
            return page(
                error="Cảnh báo an toàn: Người hoàn tất ủy quyền không khớp với tài khoản khởi tạo.",
                status=403,
            )

        try:
            tokens = exchange_authorization_code(
                code=code,
                redirect_uri=BASE_URL + "/connect/callback",
                code_verifier=tx.get("verifier"),
            )
            claims = validate_token_response(
                tokens,
                expected_nonce=tx.get("nonce"),
                require_nonce=True,
            )
        except Exception as error:
            event("connect_failed", reason=type(error).__name__, client_id=CLIENT_ID)
            return page(error="Không thể đổi mã ủy quyền lấy token.", status=400)

        connector_user = claims.get("preferred_username", claims.get("sub", ""))
        connector_email = claims.get("email", f"{connector_user}@example.lab")
        token_jti = claims.get("jti", secrets.token_hex(8))

        connection_id = "conn-" + secrets.token_hex(4)

        # Lưu vào Token Vault dưới danh tính của người khởi tạo state (app_user = tx["state_user"])
        target_app_user = state_user
        vault = load_json_file(VAULT_FILE)
        vault[target_app_user] = {
            "connection_id": connection_id,
            "oauth_state_id": oauth_state_id,
            "app_user": target_app_user,
            "session_user_at_callback": session_user,
            "connector_user": connector_user,
            "connector_email": connector_email,
            "binding_status": binding_status,
            "owner_relation": "initiator",
            "access_token": tokens.get("access_token"),
            "refresh_token": tokens.get("refresh_token"),
            "expires_at": time.time() + int(tokens.get("expires_in", 300)),
            "token_jti": token_jti,
            "linked_at": time.time(),
            "tokens": tokens,
        }
        save_json_file(VAULT_FILE, vault)

        # Ghi log sự kiện connector_linked với outcome="committed"
        event(
            "connector_linked",
            app_user=target_app_user,
            connector_user=connector_user,
            session_user=session_user,
            binding_status=binding_status,
            owner_relation="initiator",
            oauth_state_id=oauth_state_id,
            connection_id=connection_id,
            outcome="committed",
        )

        return redirect("/")

    @app.post("/disconnect")
    def disconnect():
        """Ngắt kết nối kho tài liệu cá nhân."""
        if not valid_logout_csrf():
            abort(400)
        if not session.get("user"):
            return redirect(url_for("login"))

        username = session["user"]["username"]
        vault = load_json_file(VAULT_FILE)
        if username in vault:
            vault.pop(username, None)
            save_json_file(VAULT_FILE, vault)
        return redirect("/")

    @app.get("/disconnect")
    def disconnect_get():
        if session.get("user"):
            username = session["user"]["username"]
            vault = load_json_file(VAULT_FILE)
            if username in vault:
                vault.pop(username, None)
                save_json_file(VAULT_FILE, vault)
        return redirect("/")

    def valid_logout_csrf():
        expected = session.get("form_csrf", "")
        supplied = request.form.get("csrf_token", "")
        return (
            bool(expected)
            and bool(supplied)
            and secrets.compare_digest(expected, supplied)
        )

    @app.post("/logout")
    def logout():
        """Xóa phiên website và thực hiện RP-Initiated Logout."""
        if not valid_logout_csrf():
            abort(400)

        tokens = session.get("tokens", {})
        id_token = tokens.get("id_token")

        event(
            "logout_started",
            subject=session.get("user", {}).get("sub"),
            client_id=CLIENT_ID,
        )

        session.clear()

        logout_parameters = {
            "client_id": CLIENT_ID,
            "post_logout_redirect_uri": BASE_URL + "/",
        }
        if id_token:
            logout_parameters["id_token_hint"] = id_token

        logout_url = (
            requests.Request(
                "GET",
                ISSUER + "/protocol/openid-connect/logout",
                params=logout_parameters,
            )
            .prepare()
            .url
        )

        return redirect(logout_url)

else:

    def unauthorized(event_name, **details):
        event(event_name, status=401, **details)
        response = jsonify(detail="Yêu cầu xác thực.")
        response.status_code = 401
        response.headers["WWW-Authenticate"] = 'Bearer error="invalid_token"'
        return response

    @app.get("/api/protected")
    def protected():
        authorization = request.headers.get("Authorization", "")
        parts = authorization.split()

        if len(parts) != 2 or parts[0].lower() != "bearer":
            return unauthorized("missing_token")

        try:
            claims = verify_token(parts[1], "resource-api")
        except jwt.PyJWKClientConnectionError:
            event("key_service_unavailable", status=503)
            return jsonify(detail="Dịch vụ xác thực chưa sẵn sàng."), 503
        except jwt.PyJWTError as error:
            return unauthorized(
                "invalid_token",
                reason=type(error).__name__,
                missing_claim=getattr(error, "claim", None),
            )

        resource_access = claims.get("resource_access", {})
        api_roles = resource_access.get("resource-api", {}).get("roles", [])

        if "read" not in api_roles:
            event(
                "insufficient_permission",
                status=403,
                subject=claims.get("sub"),
                client_id=claims.get("azp"),
            )
            return jsonify(detail="Không đủ quyền truy cập."), 403

        # Kiểm tra thẩm quyền đọc tài liệu:
        # - Token từ Document Portal (documents-portal): có quyền xem trực tiếp tài liệu cá nhân.
        # - Token từ Employee Portal (employee-portal): phải thông qua luồng liên kết kho tài liệu (có X-Connector-Context).
        client_id = claims.get("azp")
        if client_id == "employee-portal":
            if request.headers.get("X-Connector-Context") != "document-vault":
                event(
                    "insufficient_permission",
                    status=403,
                    subject=claims.get("sub"),
                    client_id=client_id,
                    reason="missing_connector_context",
                )
                return jsonify(detail="Token đăng nhập Employee Portal chưa có quyền đọc kho tài liệu cá nhân. Cần liên kết kho tài liệu."), 403

        username = claims.get("preferred_username", "")

        event(
            "protected_resource_access",
            status=200,
            username=username,
            subject=claims["sub"],
            client_id=claims.get("azp"),
            token_jti=claims.get("jti"),
        )

        # Trả về danh sách tài liệu cá nhân theo chủ thể của token đã xác minh
        files_db = {
            "student": [
                "Ho_so_student.pdf",
                "Chung_nhan_student.pdf",
            ],
            "attacker": [
                "Ho_so_attacker.pdf",
                "Chung_nhan_attacker.pdf",
            ],
            "manager": [
                "Ho_so_manager.pdf",
                "Chung_nhan_manager.pdf",
            ],
        }

        user_files = files_db.get(username, [f"Ho_so_{username}.pdf", f"Chung_nhan_{username}.pdf"])

        return jsonify(
            status="ok",
            owner=username,
            email=claims.get("email", f"{username}@example.lab"),
            files=user_files,
        )


if __name__ == "__main__":
    app.run(
        host="0.0.0.0",
        port=PORT,
        debug=False,
        use_reloader=False,
    )
