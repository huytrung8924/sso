import sys
from getpass import getpass

try:
    t1 = getpass("Token 1: ").strip()
    t2 = getpass("Token 2: ").strip()
    if any(t.lower() in ("", "null", "none") for t in (t1, t2)):
        raise SystemExit("Token rỗng/null: chưa đủ để đối chiếu.")
    print("Cùng chuỗi token:", t1 == t2)
except KeyboardInterrupt:
    print()
    sys.exit(0)
