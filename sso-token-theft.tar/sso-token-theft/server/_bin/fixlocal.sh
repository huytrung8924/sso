#!/bin/bash
set -e

sudo systemctl daemon-reload

sudo systemctl enable --now \
  keycloak.service \
  api.service \
  employee.service \
  documents.service

echo $1 | sudo -S sed -i 's/hosts:          files dns/hosts:          files/' /etc/nsswitch.conf
sudo bash -c 'journalctl -u keycloak.service -f > /var/log/keycloak.log 2>&1 &'
