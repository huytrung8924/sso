echo $1 | sudo -S sed -i 's/hosts:          files dns/hosts:          files/' /etc/nsswitch.conf
