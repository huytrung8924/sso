#!/bin/bash
set -e
for img in client server attacker; do
    echo "Pushing $img..."
    docker push trung8924/sso-code-injection.$img.student:latest
    docker push trung8924/sso-code-injection.$img.student:base_image739eee77f8d3
done
echo "All images pushed successfully to Docker Hub."
