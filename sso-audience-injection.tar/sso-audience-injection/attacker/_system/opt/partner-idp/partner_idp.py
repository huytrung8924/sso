#!/usr/bin/env python3
"""
Partner IdP Service for Audience Injection Lab.
Provides OIDC Discovery and PAR Endpoint.
"""
import http.server
import json
import os
import sys
import urllib.parse
import uuid

CONFIG_PATH = "/etc/partner-idp/openid-configuration.json"
LOG_PATH = "/tmp/par.log"

class PartnerIdpHandler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/.well-known/openid-configuration":
            if os.path.exists(CONFIG_PATH):
                with open(CONFIG_PATH, "rb") as f:
                    content = f.read()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(content)))
                self.end_headers()
                self.wfile.write(content)
            else:
                self.send_error(404, "Config not found")
        elif self.path.startswith("/auth"):
            body = b"<html><body><h1>Partner IdP Auth Endpoint (Mock)</h1></body></html>"
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        elif self.path == "/certs":
            body = b'{"keys":[]}'
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        else:
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(b'{"status":"ok"}')

    def do_POST(self):
        if self.path == "/par":
            content_length = int(self.headers.get("Content-Length", 0))
            post_data = self.rfile.read(content_length).decode("utf-8")
            parsed = urllib.parse.parse_qs(post_data)

            client_assertion = parsed.get("client_assertion", [""])[0]
            client_id = parsed.get("client_id", [""])[0]

            # Append raw assertion to /tmp/par.log for student inspection
            log_line = f"client_assertion={client_assertion}\n"
            with open(LOG_PATH, "a") as f:
                f.write(log_line)

            # JSON log to stdout (captured by journalctl)
            log_record = {
                "component": "partner-idp",
                "event": "par_request_received",
                "source_ip": self.client_address[0],
                "client_id": client_id,
                "client_assertion": client_assertion
            }
            print(json.dumps(log_record), flush=True)

            # Return standard RFC 9126 PAR response
            response_data = json.dumps({
                "request_uri": "urn:ietf:params:oauth:request_uri:attacker-" + uuid.uuid4().hex,
                "expires_in": 300
            }).encode("utf-8")

            self.send_response(201)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(response_data)))
            self.end_headers()
            self.wfile.write(response_data)
        else:
            self.send_error(404, "Endpoint not found")

    def log_message(self, format, *args):
        pass

if __name__ == "__main__":
    server_address = ("0.0.0.0", 8080)
    httpd = http.server.ThreadingHTTPServer(server_address, PartnerIdpHandler)
    print("Partner IdP listening on port 8080...", flush=True)
    httpd.serve_forever()
