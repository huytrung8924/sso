#!/bin/bash
echo $1 | sudo -S sed -i 's/hosts:          files dns/hosts:          files/' /etc/nsswitch.conf

sudo systemctl daemon-reload
sudo systemctl enable --now partner-idp.service
