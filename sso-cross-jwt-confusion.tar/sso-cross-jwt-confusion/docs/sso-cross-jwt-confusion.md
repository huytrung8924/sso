PHẦN 1: CHI TIẾT XÂY DỰNG HỆ THỐNG LAB TỪ MẪU sso-login-csrfĐể chuyển đổi từ hệ thống mẫu của bài sso-login-csrf sang bài thực hành sso-cross-jwt-confusion mà vẫn giữ nguyên kiến trúc 3 container (client, attacker, server) và 4 dịch vụ (keycloak, employee, documents, api), hệ thống cần được điều chỉnh về mặt điều kiện khai thác, cấu hình Keycloak, mã nguồn ứng dụng và bộ tiêu chí chấm điểm tự động như sau.   1. Các điều kiện, chức năng và điểm yếu cần thiết lập để kỹ thuật xảy raKhác với bài sso-login-csrf (nơi lỗ hổng nằm ở bước nhận Authorization Code tại Employee Portal và nhắm vào trình duyệt của nạn nhân), kỹ thuật Cross-JWT Confusion nhắm trực tiếp vào cơ chế xác minh JWT Bearer Token tại Resource API. Để kịch bản diễn ra tự nhiên, sát thực tế và đúng bản chất tiêu chuẩn RFC 8725 (§2.8, §3.11–3.12) cùng RFC 9068 (§4, §5), hệ thống cần thỏa mãn 5 điều kiện sau:   STTĐiều kiện cần thiết lậpHiện trạng trong sso-login-csrf.tarThay đổi cần thực hiện cho sso-cross-jwt-confusion1Đóng lỗ hổng Login CSRF trên các Portalemployee.service đang đặt OIDC\_SECURITY\_MODE=login-csrf-vulnerable (bỏ qua state, nonce, PKCE).   Chuyển employee.service sang OIDC\_SECURITY\_MODE=secure và bật PKCE S256 cho employee-portal trong Keycloak để luồng đăng nhập OIDC an toàn tuyệt đối.   2Phân tách quyền truy cập giữa student và attackerTrong sso-lab-realm.json, cả student, manager và attacker đều được gán quyền "resource-api": \["read"].   Giữ quyền "read" trên resource-api cho student, nhưng xóa quyền "read" của attacker. Ngoài ra, tại Employee Portal, trang chủ chỉ xác thực danh tính nhân viên (không yêu cầu quyền trên resource-api), còn Document Portal bắt buộc gọi Resource API để kiểm tra quyền. Nhờ đó, attacker đăng nhập được vào Employee Portal nhưng bị chặn (403 Forbidden) khi vào Document Portal.   3Chức năng xuất hiện hợp lệ của ID Token (id\_token\_hint)app.py lưu tokens trong Flask-Session phía server, nhưng hàm POST /logout có đọc id\_token và gắn vào tham số id\_token\_hint trên URL chuyển hướng về Keycloak.   Giữ nguyên cơ chế RP-Initiated Logout này. Khi attacker bấm nút Đăng xuất trên Employee Portal và dùng mitmweb chặn yêu cầu /protocol/openid-connect/logout, attacker sẽ thu được ID Token nguyên vẹn, có chữ ký RSA hợp lệ từ Keycloak.   4Điểm yếu xác minh chồng lấn \& phân quyền sai trên /api/recordsapi.service hiện chỉ có một điểm cuối /api/protected kiểm tra cứng audience="resource-api" và role "read".   Giữ nguyên /api/protected làm điểm cuối chuẩn (bổ sung kiểm tra tường minh typ == "Bearer") và thêm điểm cuối /api/records chứa lỗ hổng Cross-JWT Confusion:• Lỗi 1 (Xác minh chồng lấn): Chỉ kiểm tra chữ ký RS256 từ JWKS của Keycloak, iss và exp, nhưng không kiểm tra aud riêng của API (verify\_aud=False) và không kiểm tra trường typ (không loại trừ typ: "ID").• Lỗi 2 (Xử lý phân quyền sai): Chỉ kiểm tra mảng role trong resource\_access nếu trường "resource\_access" xuất hiện trong token (tức là khi nhận Access Token), còn khi nhận ID Token (vốn chỉ chứa các claim định danh như sub, preferred\_username và không có resource\_access) thì lại cho qua và trả về dữ liệu dựa trên sub (200 OK).5Ghi nhật ký ngữ cảnh Token (Telemetry Log) phục vụ phát hiệnHàm event() trong /opt/sso/app.py trên api.service mới chỉ ghi username, subject, client\_id, token\_jti khi thành công, và chỉ ghi reason khi lỗi.   Bổ sung ghi trường token\_typ (claims.get("typ")) và token\_aud (claims.get("aud")) vào bản ghi log của cả /api/records và /api/protected (kể cả khi bị từ chối 401) để sinh viên có đầy đủ bằng chứng điều tra ở Nhiệm vụ 6.2. Chi tiết các tệp cấu hình và mã nguồn cần sửa đổi từ sso-login-csrf.tar2.1. Tệp cấu hình Keycloak Realm: server/\_system/opt/keycloak/data/import/sso-lab-realm.jsonMở tệp sso-lab-realm.json và thực hiện 2 thay đổi:   Tại cấu hình của client "employee-portal": Bổ sung "pkce.code.challenge.method": "S256" vào mục "attributes" giống như documents-portal:   JSON"attributes": {

&#x20; "pkce.code.challenge.method": "S256",

&#x20; "post.logout.redirect.uris": "http://employee.lab:5001/"

}

Tại cấu hình của người dùng "attacker" trong mảng "users": Xóa quyền "read" trong "clientRoles" (để attacker không có quyền truy cập resource-api):   JSON{

&#x20; "username": "attacker",

&#x20; "enabled": true,

&#x20; "emailVerified": true,

&#x20; "firstName": "Attacker",

&#x20; "lastName": "SSO",

&#x20; "email": "attacker@example.lab",

&#x20; "credentials": \[

&#x20;   {

&#x20;     "type": "password",

&#x20;     "value": "Attacker-2026!",

&#x20;     "temporary": false

&#x20;   }

&#x20; ],

&#x20; "clientRoles": {}

}

2.2. Tệp cấu hình Systemd: server/\_system/etc/systemd/system/employee.serviceTrong tệp employee.service, chuyển chế độ bảo mật từ login-csrf-vulnerable sang secure:   Ini, TOMLEnvironment=OIDC\_SECURITY\_MODE=secure

(Các tệp documents.service, api.service và keycloak.service giữ nguyên như trong sso-login-csrf.tar).   2.3. Mã nguồn ứng dụng: server/\_system/opt/sso/app.pyTrong tệp /opt/sso/app.py, thực hiện 3 cập nhật sau:   Thay đổi 1: Tại hàm index() của Portal (if IS\_PORTAL:):Để Employee Portal đóng vai trò là cổng xác thực nhân viên chung (mọi tài khoản đăng nhập hợp lệ qua Keycloak đều vào được trang chủ và thấy nút Đăng xuất), còn Document Portal đóng vai trò cổng tài liệu có kiểm soát quyền qua Resource API:Python        # Nếu là Employee Portal, chỉ cần phiên OIDC hợp lệ là hiển thị trang chủ

&#x20;       if SERVICE == "employee":

&#x20;           return page()

(Đặt đoạn kiểm tra này ngay sau khối try: access\_token = current\_access\_token() ... except ... trong hàm index(), trước khi gọi http.get(API\_URL, ...)).   Thay đổi 2: Bổ sung hàm xác minh lỏng lẻo verify\_token\_lax() bên cạnh hàm verify\_token() chuẩn:   Pythondef verify\_token(token, audience):

&#x20;   """Xác minh JWT chuẩn: kiểm tra chữ ký, issuer, audience và các claim bắt buộc."""

&#x20;   signing\_key = jwks.get\_signing\_key\_from\_jwt(token).key

&#x20;   return jwt.decode(

&#x20;       token,

&#x20;       signing\_key,

&#x20;       algorithms=\["RS256"],

&#x20;       issuer=ISSUER,

&#x20;       audience=audience,

&#x20;       leeway=5,

&#x20;       options={

&#x20;           "require": \["exp", "iat", "iss", "aud", "sub"]

&#x20;       },

&#x20;   )





def verify\_token\_lax(token):

&#x20;   """

&#x20;   Hàm xác minh chứa lỗ hổng Cross-JWT Confusion:

&#x20;   Chỉ kiểm tra chữ ký RS256, issuer và thời hạn (exp, iat, sub),

&#x20;   nhưng bỏ qua kiểm tra audience riêng của API và không kiểm tra loại token (typ).

&#x20;   """

&#x20;   signing\_key = jwks.get\_signing\_key\_from\_jwt(token).key

&#x20;   return jwt.decode(

&#x20;       token,

&#x20;       signing\_key,

&#x20;       algorithms=\["RS256"],

&#x20;       issuer=ISSUER,

&#x20;       leeway=5,

&#x20;       options={

&#x20;           "verify\_aud": False,

&#x20;           "require": \["exp", "iat", "iss", "sub"],

&#x20;       },

&#x20;   )

Thay đổi 3: Cập nhật khối else: (phần mã của api.service) để có 2 điểm cuối /api/records (lỗi) và /api/protected (chuẩn) kèm ghi log Telemetry:   Python    @app.get("/api/records")

&#x20;   def records():

&#x20;       """Điểm cuối chứa lỗ hổng Cross-JWT Confusion."""

&#x20;       authorization = request.headers.get("Authorization", "")

&#x20;       parts = authorization.split()



&#x20;       if len(parts) != 2 or parts\[0].lower() != "bearer":

&#x20;           return unauthorized("missing\_token")



&#x20;       try:

&#x20;           claims = verify\_token\_lax(parts\[1])

&#x20;       except jwt.PyJWKClientConnectionError:

&#x20;           event("key\_service\_unavailable", status=503)

&#x20;           return jsonify(detail="Dịch vụ xác thực chưa sẵn sàng."), 503

&#x20;       except jwt.PyJWTError as error:

&#x20;           return unauthorized(

&#x20;               "invalid\_token",

&#x20;               reason=type(error).\_\_name\_\_,

&#x20;           )



&#x20;       # Lỗi logic phân quyền kết hợp với Cross-JWT Confusion:

&#x20;       # Chỉ kiểm tra role khi token có chứa trường 'resource\_access' (Access Token),

&#x20;       # nhưng khi nhận ID Token (không có 'resource\_access', chỉ có 'sub') thì lại bỏ qua

&#x20;       # và mặc nhiên cấp quyền truy cập dựa trên danh tính 'sub'.

&#x20;       if "resource\_access" in claims:

&#x20;           api\_roles = (

&#x20;               claims.get("resource\_access", {})

&#x20;               .get("resource-api", {})

&#x20;               .get("roles", \[])

&#x20;           )

&#x20;           if "read" not in api\_roles:

&#x20;               event(

&#x20;                   "insufficient\_permission",

&#x20;                   status=403,

&#x20;                   username=claims.get("preferred\_username", ""),

&#x20;                   subject=claims.get("sub"),

&#x20;                   client\_id=claims.get("azp"),

&#x20;                   token\_typ=claims.get("typ"),

&#x20;                   token\_aud=claims.get("aud"),

&#x20;                   token\_jti=claims.get("jti"),

&#x20;               )

&#x20;               return jsonify(detail="Không đủ quyền truy cập."), 403



&#x20;       event(

&#x20;           "records\_resource\_access",

&#x20;           status=200,

&#x20;           username=claims.get("preferred\_username", ""),

&#x20;           subject=claims\["sub"],

&#x20;           client\_id=claims.get("azp"),

&#x20;           token\_typ=claims.get("typ"),

&#x20;           token\_aud=claims.get("aud"),

&#x20;           token\_jti=claims.get("jti"),

&#x20;       )



&#x20;       return jsonify(

&#x20;           status="ok",

&#x20;           endpoint="records",

&#x20;           subject=claims\["sub"],

&#x20;           username=claims.get("preferred\_username", ""),

&#x20;           records=\[

&#x20;               {"id": "REC-01", "title": "Hồ sơ nhân sự nội bộ"},

&#x20;               {"id": "REC-02", "title": "Báo cáo phân quyền hệ thống SSO"},

&#x20;           ],

&#x20;       )





&#x20;   @app.get("/api/protected")

&#x20;   def protected():

&#x20;       """Điểm cuối đã bảo vệ chuẩn theo RFC 8725 §3.12 \& RFC 9068 §4."""

&#x20;       authorization = request.headers.get("Authorization", "")

&#x20;       parts = authorization.split()



&#x20;       if len(parts) != 2 or parts\[0].lower() != "bearer":

&#x20;           return unauthorized("missing\_token")



&#x20;       raw\_token = parts\[1]

&#x20;       unverified\_claims = {}

&#x20;       try:

&#x20;           unverified\_claims = jwt.decode(

&#x20;               raw\_token,

&#x20;               options={"verify\_signature": False},

&#x20;           )

&#x20;       except jwt.PyJWTError:

&#x20;           pass



&#x20;       try:

&#x20;           claims = verify\_token(raw\_token, "resource-api")

&#x20;           # Kiểm tra tường minh loại token (Explicit Typing): từ chối ID Token

&#x20;           if claims.get("typ") != "Bearer":

&#x20;               raise jwt.InvalidTokenError("Invalid token type: expected Bearer")

&#x20;       except jwt.PyJWKClientConnectionError:

&#x20;           event("key\_service\_unavailable", status=503)

&#x20;           return jsonify(detail="Dịch vụ xác thực chưa sẵn sàng."), 503

&#x20;       except jwt.PyJWTError as error:

&#x20;           return unauthorized(

&#x20;               "invalid\_token",

&#x20;               reason=type(error).\_\_name\_\_,

&#x20;               username=unverified\_claims.get("preferred\_username", ""),

&#x20;               subject=unverified\_claims.get("sub"),

&#x20;               client\_id=unverified\_claims.get("azp"),

&#x20;               token\_typ=unverified\_claims.get("typ"),

&#x20;               token\_aud=unverified\_claims.get("aud"),

&#x20;               token\_jti=unverified\_claims.get("jti"),

&#x20;           )



&#x20;       resource\_access = claims.get("resource\_access", {})

&#x20;       api\_roles = resource\_access.get("resource-api", {}).get("roles", \[])



&#x20;       if "read" not in api\_roles:

&#x20;           event(

&#x20;               "insufficient\_permission",

&#x20;               status=403,

&#x20;               username=claims.get("preferred\_username", ""),

&#x20;               subject=claims.get("sub"),

&#x20;               client\_id=claims.get("azp"),

&#x20;               token\_typ=claims.get("typ"),

&#x20;               token\_aud=claims.get("aud"),

&#x20;               token\_jti=claims.get("jti"),

&#x20;           )

&#x20;           return jsonify(detail="Không đủ quyền truy cập."), 403



&#x20;       event(

&#x20;           "protected\_resource\_access",

&#x20;           status=200,

&#x20;           username=claims.get("preferred\_username", ""),

&#x20;           subject=claims\["sub"],

&#x20;           client\_id=claims.get("azp"),

&#x20;           token\_typ=claims.get("typ"),

&#x20;           token\_aud=claims.get("aud"),

&#x20;           token\_jti=claims.get("jti"),

&#x20;       )



&#x20;       return jsonify(status="ok")

2.4. Dọn dẹp các tệp cũ và cấu hình chấm điểm Labtainer (instr\_config/)Xóa các tệp riêng của bài Login CSRF: Xóa compare\_codes.py và timeline.txt trong thư mục server/ và client/.   Cập nhật instr\_config/results.config:   Ini, TOML# Task 1: sso\_verified (Student truy cập thành công và Attacker bị từ chối 403 tại Document Portal)

\_task1\_student\_ok = server:/var/log/syslog : CONTAINS : "event": "protected\_resource\_access"

\_task1\_attacker\_403 = server:/var/log/syslog : CONTAINS : "event": "insufficient\_permission"



\# Task 2: proxy\_ready (Attacker khởi chạy mitmweb)

\_proxy\_started = attacker:.bash\_history : CONTAINS : mitmweb



\# Task 3: capture\_id\_token (Attacker kích hoạt đăng xuất để lấy id\_token\_hint)

\_task3\_logout\_started = server:/var/log/syslog : CONTAINS : "event": "logout\_started"



\# Task 4: cross\_jwt\_confusion\_success (Attacker dùng ID Token truy cập thành công /api/records)

\_task4\_confusion\_ok = server:/var/log/syslog : CONTAINS : "event": "records\_resource\_access"



\# Task 5: secure\_api\_rejected (/api/protected từ chối ID Token với lỗi invalid\_token)

\_task5\_protected\_401 = server:/var/log/syslog : CONTAINS : "event": "invalid\_token"



\# Task 6: forensics\_done (Sinh viên sử dụng journalctl để truy vết trên server)

\_task6\_journalctl = server:.bash\_history : CONTAINS : journalctl

Cập nhật instr\_config/goals.config:   Ini, TOMLsso\_verified = boolean : (\_task1\_student\_ok and \_task1\_attacker\_403)

proxy\_ready = boolean : \_proxy\_started

capture\_id\_token = boolean : \_task3\_logout\_started

cross\_jwt\_confusion\_success = boolean : \_task4\_confusion\_ok

secure\_api\_rejected = boolean : \_task5\_protected\_401

forensics\_done = boolean : \_task6\_journalctl

PHẦN 2: KỊCH BẢN HƯỚNG DẪN THỰC HÀNH HOÀN CHỈNH (sso-cross-jwt-confusion.md)Dưới đây là toàn bộ nội dung tài liệu hướng dẫn thực hành cuối cùng (đã tích hợp đầy đủ phần mô phỏng và phần phát hiện/điều tra số ở Nhiệm vụ 6, loại bỏ bước chạy script Python theo đúng yêu cầu của bạn):Học viện Công nghệ Bưu chính Viễn thông - SecLab PTITHướng dẫn thực hànhOAuth 2.0 / OpenID Connect – Cross-JWT ConfusionMức độ: Trung bình – KhóWeb Security / Identity Security / Single Sign-On1. Giới thiệu labThông tinChi tiếtTên Labsso-cross-jwt-confusionMức độTrung bình – KhóCông cụ sử dụngfirefox, mitmweb, curl, journalctl, getentGiao thứcOAuth 2.0, OpenID Connect, JSON Web Token (JWT)Cơ chế bảo vệAudience Validation (aud), Explicit Typing (typ), Mutually Exclusive Validation Rules, Log CorrelationMục tiêu học tậpHiểu rõ sự khác biệt về mục đích sử dụng và ngữ cảnh xác minh giữa ID Token và Access Token trong hệ thống OAuth 2.0 / OpenID Connect.Nắm vững bản chất và điều kiện hình thành lỗ hổng Cross-JWT Confusion theo tiêu chuẩn IETF RFC 8725 (§2.8) và RFC 9068 (§5).Thực hành quy trình thu thập ID Token hợp lệ từ luồng đăng xuất OIDC (id\_token\_hint) và kiểm chứng cơ chế đánh tráo ID Token làm Access Token trên điểm cuối API chứa lỗ hổng (/api/records).So sánh được sự khác biệt giữa điểm cuối API xác minh token chồng lấn (/api/records) và điểm cuối API áp dụng quy tắc xác minh loại trừ lẫn nhau đúng chuẩn (/api/protected).Rèn luyện kỹ năng điều tra số và phân tích nhật ký sự kiện (Telemetry Log Correlation) để phát hiện hành vi sử dụng sai loại token trên Resource API.Kỹ năng đạt đượcCấu hình HTTP Proxy trên Firefox và sử dụng mitmweb để quan sát tham số id\_token\_hint trong luồng RP-Initiated Logout.   Sử dụng curl để kiểm thử cơ chế xác thực Bearer Token trực tiếp trên các điểm cuối REST API.Sử dụng journalctl để truy vấn, đối chiếu các trường siêu dữ liệu của JWT (token\_typ, token\_aud, token\_jti, source\_ip, user\_agent) và tái dựng chuỗi sự kiện giữa Portal, Keycloak và Resource API.   2. Kịch bảnTình huống:Công ty sử dụng Keycloak làm hệ thống xác thực tập trung SSO (Single Sign-On) cho hai cổng ứng dụng nội bộ: Employee Portal (cổng thông tin nhân viên chung) và Document Portal (cổng tài liệu kết nối tới Resource API, chỉ dành cho những tài khoản được cấp quyền đọc tài liệu).   Trong đợt nâng cấp vừa qua, đội ngũ phát triển triển khai thêm điểm cuối /api/records trên Resource API để phục vụ tra cứu hồ sơ. Do cho rằng bất kỳ JWT nào có chữ ký số RSA hợp lệ từ Keycloak đều đại diện cho quyền truy cập hợp lệ, lập trình viên chỉ kiểm tra chữ ký và thời hạn của token mà bỏ sót việc kiểm tra đối tượng nhận (aud) cũng như loại token (typ). Kẻ tấn công chỉ sở hữu một tài khoản bị giới hạn quyền (attacker — được phép đăng nhập vào Employee Portal nhưng không có quyền truy cập Document Portal / Resource API), song đã trích xuất chính ID Token của mình từ luồng đăng xuất trên Employee Portal để gửi trực tiếp tới /api/records như một Access Token, từ đó truy cập trái phép dữ liệu hồ sơ nội bộ.Vai trò của sinh viên:Kiểm tra hoạt động của hệ thống SSO và sự phân tách quyền truy cập giữa tài khoản nhân viên (student) và tài khoản bị giới hạn quyền (attacker).   Đóng vai attacker, sử dụng proxy (mitmweb) chặn yêu cầu đăng xuất OIDC từ Employee Portal để lấy ID Token nguyên vẹn từ tham số id\_token\_hint.   Sử dụng curl gửi ID Token của attacker làm Bearer Token tới điểm cuối /api/records để tái hiện lỗ hổng Cross-JWT Confusion, đồng thời kiểm chứng cơ chế phòng vệ chuẩn trên điểm cuối /api/protected.   Đóng vai chuyên gia Blue Team / điều tra số, sử dụng journalctl để phân tích nhật ký của Resource API, Employee Portal và Keycloak nhằm chứng minh đây là cuộc tấn công Cross-JWT Confusion sử dụng ID Token rò rỉ từ luồng đăng xuất.   Sơ đồ luồng tấn côngPlaintext+----------+                   +-------------------+                 +--------------------+

| Attacker |                   | Employee Portal / |                 |    Resource API    |

|          |                   |   Keycloak (IdP)  |                 |  (/api/records)    |

+----+-----+                   +---------+---------+                 +---------+----------+

&#x20;    |                                   |                                     |

&#x20;    | 1. Đăng nhập hợp lệ vào Portal    |                                     |

&#x20;    +---------------------------------->|                                     |

&#x20;    |                                   |                                     |

&#x20;    | 2. Bấm Đăng xuất -> Chặn Redirect |                                     |

&#x20;    |    lấy ID Token từ id\_token\_hint  |                                     |

&#x20;    |<----------------------------------+                                     |

&#x20;    |                                   |                                     |

&#x20;    | 3. Gửi Authorization: Bearer <ID\_TOKEN>                                 |

&#x20;    +------------------------------------------------------------------------>|

&#x20;    |                                   |                                     |

&#x20;    |                                   |         4. Kiểm tra chữ ký \& exp    |

&#x20;    |                                   |            Bỏ sót aud và loại token |

&#x20;    |                                   |            Đọc sub -> Cho phép      |

&#x20;    |                                   |                                     |

&#x20;    | 5. Trả về 200 OK kèm dữ liệu hồ sơ                                      |

&#x20;    |<------------------------------------------------------------------------+

Mô tả luồng tấn côngAttacker đăng nhập bình thường vào Employee Portal bằng tài khoản hạn chế của mình (attacker).   Khi thực hiện thao tác Đăng xuất (RP-Initiated Logout), Employee Portal chuyển hướng trình duyệt về Keycloak kèm theo tham số id\_token\_hint chứa ID Token của phiên hiện tại.   Attacker dùng mitmweb chặn yêu cầu chuyển hướng đăng xuất này trước khi nó tới Keycloak để thu thập chuỗi ID Token nguyên vẹn, có chữ ký hợp lệ.   Attacker dùng curl gửi trực tiếp ID Token đó trong header Authorization: Bearer <ID\_TOKEN> tới điểm cuối /api/records của Resource API.Vì /api/records chỉ kiểm tra chữ ký RSA và thời hạn exp mà không kiểm tra đối tượng nhận (aud) hay loại token (typ), đồng thời bỏ qua kiểm tra quyền khi không thấy trường resource\_access, nó chấp nhận ID Token và trả về dữ liệu (200 OK).3. Kiến thức bổ trợKiến trúc hệ thống SSO trong LabLab gồm ba container:   Thành phầnContainerĐịa chỉ IPVai tròFirefoxclient172.28.50.10Máy người dùng hợp lệ (Nhân viên student)   Firefox + mitmproxy + curlattacker172.28.50.30Máy tấn công (Tài khoản hạn chế attacker)   Keycloak + Portals + APIserver172.28.50.20Identity Provider, các Portal và Resource API   Các dịch vụ chạy trên container server:   Dịch vụĐịa chỉ truy cậpMô tảKeycloak (IdP)\[http://idp.lab:8080](http://idp.lab:8080)Máy chủ định danh tập trung, phát hành và ký số mọi JWT   Employee Portal\[http://employee.lab:5001](http://employee.lab:5001)Cổng nhân viên (Xác thực OIDC cho mọi tài khoản nội bộ)   Document Portal\[http://documents.lab:5002](http://documents.lab:5002)Cổng tài liệu (Yêu cầu tài khoản có quyền read trên /api/protected)   Resource API (Lỗi)\[http://api.lab:8000/api/records](http://api.lab:8000/api/records)Điểm cuối API chứa lỗ hổng Cross-JWT Confusion (không kiểm tra aud/typ)Resource API (Chuẩn)\[http://api.lab:8000/api/protected](http://api.lab:8000/api/protected)Điểm cuối API bảo vệ đúng chuẩn (kiểm tra chặt aud, typ và quyền read)   JWT là định dạng, không phải loại quyền truy cậpTheo RFC 7519 (§4.1, §5.1), JSON Web Token (JWT) chỉ là định dạng truyền tải các thông tin xác nhận (claims) có chữ ký số. Trong hệ thống OAuth 2.0 / OpenID Connect dùng chung một Identity Provider (Keycloak), cả ID Token và Access Token đều có dạng JWT và được ký bằng cùng một khóa bí mật RSA của realm sso-lab:   Thành phần / ClaimGiá trị trong ID Token (Cấp cho Employee Portal)Giá trị trong Access Token (Cấp để gọi Resource API)Ý nghĩaiss (Issuer)\[http://idp.lab:8080/realms/sso-lab](http://idp.lab:8080/realms/sso-lab)   \[http://idp.lab:8080/realms/sso-lab](http://idp.lab:8080/realms/sso-lab)   Bên phát hành token (Giống nhau)   sub (Subject)Định danh UUID của người dùng   Định danh UUID của người dùng   Chủ thể mà token nói tới (Giống nhau)   aud (Audience)employee-portal   resource-api   Bên nhận dự kiến mà token hướng tới   typ (Token Type)IDBearer (hoặc header at+jwt theo RFC 9068)Phân biệt bằng chứng đăng nhập và token truy cập APIresource\_accessKhông có   {"resource-api": {"roles": \["read"]}}   Quyền truy cập tài nguyên cụ thể trên API   Cross-JWT Confusion (RFC 8725 §2.8 \& RFC 9068 §5)Cross-JWT Confusion là một dạng tấn công đánh tráo (substitution attack), khiến một JWT được cấp cho mục đích này bị chấp nhận trong ngữ cảnh dành cho mục đích khác.Trong OIDC (OIDC Core §2 \& §3.1.3.3), ID Token cung cấp thông tin về việc xác thực người dùng cho Client, còn Access Token được dùng để truy cập tài nguyên được bảo vệ. Nếu một API chỉ kiểm tra chữ ký mật mã từ IdP tin cậy và thời hạn exp mà bỏ qua câu hỏi "IdP phát hành token này để làm gì (typ), và dành cho ai (aud)?", kẻ tấn công có thể dùng nguyên vẹn một ID Token hợp lệ để gửi vào điểm nhận Bearer Token của API.Các cơ chế bảo vệ và phát hiện quan trọngQuy tắc xác minh loại trừ lẫn nhau (RFC 8725 §3.12): Quy tắc xác minh của các loại JWT khác nhau phải loại trừ nhau để token sai loại luôn bị từ chối.Kiểm tra tường minh loại token (typ - RFC 8725 §3.11 \& RFC 9068 §4): Resource API phải kiểm tra nhãn loại token, chỉ chấp nhận token truy cập (typ: "Bearer" hoặc at+jwt) và từ chối mọi ID Token (typ: "ID").Kiểm tra đối tượng nhận (aud - RFC 8725 §3.9 \& RFC 9068 §4): Resource API phải bắt buộc trường aud chứa định danh của chính mình (resource-api), từ chối token dành cho cổng đăng nhập (employee-portal).   Tương quan nhật ký ngữ cảnh (Log Correlation): Kết hợp nhật ký từ Resource API (api.service), Portal (employee.service) và IdP (keycloak.service) để phát hiện sự bất thường khi một token mang token\_typ: "ID", token\_aud: "employee-portal" được gửi trực tiếp từ công cụ bên ngoài (curl) ngay sau một sự kiện logout\_started bị ngắt quãng.   Thành phần cần quan sát trong bài labThành phầnVai tròmitmwebProxy trên máy attacker dùng để chặn yêu cầu đăng xuất và lấy ID Token từ tham số id\_token\_hint   Tham số id\_token\_hintTham số chuẩn trong OIDC RP-Initiated Logout chứa ID Token nguyên vẹn của phiên đăng nhập   /api/recordsĐiểm cuối API chứa lỗ hổng Cross-JWT Confusion (không kiểm tra aud và typ)/api/protectedĐiểm cuối API đã được bảo vệ đúng chuẩn (kiểm tra chặt aud, typ và quyền read)   Log systemd (journalctl)Nguồn bằng chứng để phát hiện token\_typ: "ID", token\_aud: "employee-portal" và truy vết nguồn gốc rò rỉ token   Bảng tùy chọn và cú pháp công cụ sử dụng trong bàiCông cụTùy chọn / Cú phápMô tả tác dụngmitmwebmitmweb -p 8080 >/dev/null 2>\&1 \&Khởi chạy Proxy MITM ở cổng 8080 để quản lý và chặn gói tin   firefoxfirefox >/dev/null 2>\&1 \&Trình duyệt dùng để thực hiện đăng nhập và đăng xuất trên các Portal   curlcurl -i -H "Authorization: Bearer <TOKEN>" <URL>Gửi yêu cầu HTTP kèm Bearer Token tới các điểm cuối Resource APIjournalctlsudo journalctl -u <service> --since "<time>"Xem và lọc log của các dịch vụ (api, employee, keycloak)   getentgetent hosts <hostname>Kiểm tra phân giải tên miền hệ thống   4. Các nhiệm vụ của bài thực hànhĐể tải bài thực hành, sinh viên thực hiện câu lệnh:Bashimodule https://github.com/huytrung8924/sso/raw/refs/heads/main/sso-cross-jwt-confusion.tar

Để khởi động bài thực hành, sinh viên dùng câu lệnh:Bashlabtainer sso-cross-jwt-confusion

(Chú ý: sinh viên sử dụng mã sinh viên của mình để nhập thông tin email người thực hiện bài lab khi có yêu cầu, để sử dụng khi chấm điểm)   Sau khi khởi động xong, ba terminal ảo sẽ xuất hiện tương ứng với 3 máy: client, attacker và server.   Tài khoản thực hànhTài khoản Nhân viên hợp lệ (được cấp quyền truy cập API tài liệu): student / Student-2026!   Tài khoản Kẻ tấn công (tài khoản hạn chế, không có quyền truy cập API tài liệu): attacker / Attacker-2026!   Nhiệm vụ 1 – sso\_verified: Kiểm tra môi trường, tính năng SSO và giới hạn phân quyềnTrước khi bắt đầu, cần đảm bảo hệ thống đã sẵn sàng, xác nhận tính năng Single Sign-On hoạt động bình thường với tài khoản nhân viên student và kiểm chứng rằng tài khoản attacker bị từ chối quyền khi truy cập Document Portal.   Bước 1: Tại cửa sổ terminal client và attacker, kiểm tra phân giải tên miền:   Bashgetent hosts idp.lab employee.lab documents.lab api.lab

Kết quả đúng: tất cả các tên miền đều trỏ về IP 172.28.50.20.   Bước 2: Tại cửa sổ terminal server, kiểm tra trạng thái các dịch vụ:   Bashsudo systemctl --no-pager --full status keycloak api employee documents

Tất cả phải ở trạng thái Active (running).   Bước 3: Tại terminal client, mở trình duyệt Firefox:   Bashfirefox >/dev/null 2>\&1 \&

Trên Firefox của client, truy cập \[http://employee.lab:5001](http://employee.lab:5001), đăng nhập với tài khoản student / Student-2026!. Xác nhận màn hình hiển thị Xin chào, Sinh viên SSO.   Tiếp tục truy cập \[http://documents.lab:5002](http://documents.lab:5002) ngay trên Firefox đó và bấm Đăng nhập. Trình duyệt tự động nhận diện phiên SSO tại Keycloak và vào thẳng trang Cổng tài liệu mà không báo lỗi quyền truy cập.   Bước 4: Tại terminal attacker, mở trình duyệt Firefox:   Bashfirefox >/dev/null 2>\&1 \&

Truy cập \[http://employee.lab:5001](http://employee.lab:5001), đăng nhập với tài khoản attacker / Attacker-2026!. Xác nhận attacker đăng nhập thành công vào Cổng nhân viên (Xin chào, Attacker SSO).   Nhấp vào nút Mở cổng tài liệu (\[http://documents.lab:5002](http://documents.lab:5002)) và bấm Đăng nhập.   Quan sát kết quả: Dù phiên SSO của attacker hợp lệ tại Keycloak, Cổng tài liệu lập tức hiển thị thông báo lỗi: “Chưa thể hoàn tất yêu cầu: Tài khoản chưa được cấp quyền truy cập dịch vụ” (do Resource API từ chối Access Token của attacker với mã 403 Forbidden).   Sau khi kiểm tra xong, giữ nguyên cửa sổ Firefox trên máy attacker để thực hiện nhiệm vụ tiếp theo.Điều kiện hoàn thành nhiệm vụ: Các tên miền phân giải đúng, tất cả dịch vụ Active, student vào được cả hai cổng và attacker bị từ chối quyền tại Document Portal.   Câu hỏi 1:Vì sao tài khoản attacker đã xác thực thành công trên Keycloak và vào được Employee Portal, nhưng lại bị báo lỗi không đủ quyền khi truy cập Document Portal? Sự khác biệt giữa vai trò của ID Token và Access Token thể hiện ở đây như thế nào?Trả lời: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_Nhiệm vụ 2 – proxy\_ready: Chuẩn bị hệ thống Proxy cho AttackerDo các cổng ứng dụng được xây dựng theo mô hình Confidential Client (lưu trữ token trong session phía server), người dùng không thể lấy trực tiếp Access Token từ trình duyệt. Tuy nhiên, khi thực hiện đăng xuất theo chuẩn OIDC RP-Initiated Logout, ứng dụng sẽ đính kèm ID Token vào tham số id\_token\_hint trên URL chuyển hướng về Keycloak. Sinh viên cần thiết lập proxy mitmweb để chặn và trích xuất ID Token này.   Bước 1: Tại cửa sổ terminal attacker, khởi chạy mitmweb ở cổng 8080:   Bashmitmweb -p 8080 >/dev/null 2>\&1 \&

Lệnh này khởi động proxy và tự động mở một cửa sổ Firefox truy cập vào giao diện quản lý mitmweb tại địa chỉ \[http://127.0.0.1:8081](http://127.0.0.1:8081).   Bước 2: Cấu hình Proxy cho Firefox của Attacker:   Vào Settings → Network Settings → Settings.   Chọn Manual proxy configuration.   Ở ô HTTP Proxy, điền 127.0.0.1 và ô Port điền 8080, sau đó nhấn OK.   Bước 3: Thiết lập Intercept Filter:   Quay lại tab giao diện mitmweb tại \[http://127.0.0.1:8081](http://127.0.0.1:8081), tìm thanh tìm kiếm Intercept.   Gõ vào thanh Intercept biểu thức: \~u /protocol/openid-connect/logoutBiểu thức này ra lệnh cho mitmweb tự động chặn và giữ lại yêu cầu chuyển hướng đăng xuất gửi tới Keycloak trước khi phiên SSO bị hủy.   Điều kiện hoàn thành nhiệm vụ: Firefox của attacker đã cấu hình proxy nội bộ thành công, giao diện mitmweb hiển thị và luật Intercept đã được áp dụng.   Câu hỏi 2:Trong mô hình ứng dụng lưu trữ token ở session phía máy chủ, vì sao việc chặn gói tin tại bước chuyển hướng đăng xuất (/protocol/openid-connect/logout) lại giúp thu thập được ID Token còn nguyên hiệu lực?Trả lời: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_Nhiệm vụ 3 – capture\_id\_token: Thu thập ID Token từ luồng Đăng xuất của Employee PortalAttacker thực hiện thao tác Đăng xuất trên Employee Portal. Nhờ luật Intercept đã thiết lập, yêu cầu chuyển hướng chứa tham số id\_token\_hint sẽ bị giữ lại trên mitmweb.   Bước 1: Trên Firefox của attacker, chuyển sang tab đang mở \[http://employee.lab:5001/](http://employee.lab:5001/) (màn hình Xin chào, Attacker SSO).   Bước 2: Nhấp vào nút Đăng xuất ở góc trên bên phải màn hình. Trình duyệt sẽ dừng ở trạng thái đang tải (loading) vì yêu cầu chuyển hướng tới Keycloak đã bị mitmweb giữ lại.   Bước 3: Chuyển sang tab mitmweb (\[http://127.0.0.1:8081](http://127.0.0.1:8081)). Bạn sẽ thấy một request đang tạm dừng với URL dạng:   Plaintexthttp://idp.lab:8080/realms/sso-lab/protocol/openid-connect/logout?client\_id=employee-portal\&post\_logout\_redirect\_uri=...\&id\_token\_hint=eyJ...

Bước 4: Nhấp vào request đó trên mitmweb, chuyển sang thẻ Query ở khung bên phải và sao chép toàn bộ giá trị chuỗi JWT của tham số id\_token\_hint.   Bước 5: Tại cửa sổ terminal attacker, lưu chuỗi JWT vừa sao chép vào biến môi trường ID\_TOKEN:Bashexport ID\_TOKEN="<dán\_chuỗi\_id\_token\_vào\_đây>"

Điều kiện hoàn thành nhiệm vụ: Đã trích xuất được chuỗi ID Token hợp lệ của attacker từ tham số id\_token\_hint và lưu vào biến ID\_TOKEN.Câu hỏi 3:Chuỗi ID Token thu được từ tham số id\_token\_hint có trường đối tượng nhận (aud) và trường loại token (typ) mang giá trị là gì? Theo chuẩn OpenID Connect Core 1.0, token này có được phép dùng để truy cập Resource API hay không?Trả lời: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_Nhiệm vụ 4 – cross\_jwt\_confusion\_success: Khai thác Cross-JWT Confusion trên /api/recordsAttacker hiện đã có trong tay một ID Token nguyên vẹn, có chữ ký RSA hợp lệ từ Keycloak. Ở nhiệm vụ này, sinh viên gửi trực tiếp ID Token đó vào vị trí của Access Token (trong header Authorization: Bearer) tới điểm cuối /api/records của Resource API.Bước 1: Tại cửa sổ terminal attacker, sử dụng curl gửi yêu cầu HTTP GET kèm theo $ID\_TOKEN tới điểm cuối /api/records:Bashcurl -i -H "Authorization: Bearer $ID\_TOKEN" http://api.lab:8000/api/records

Bước 2: Quan sát kết quả phản hồi trên màn hình terminal:Mặc dù tài khoản attacker không hề có quyền truy cập Resource API và token gửi lên chỉ là một ID Token cấp cho employee-portal, điểm cuối /api/records vẫn chấp nhận token và trả về mã trạng thái HTTP/1.1 200 OK kèm theo danh sách dữ liệu hồ sơ nội bộ!Điều kiện hoàn thành nhiệm vụ: Gửi $ID\_TOKEN tới \[http://api.lab:8000/api/records](http://api.lab:8000/api/records) và nhận được phản hồi 200 OK kèm dữ liệu từ Resource API.Câu hỏi 4:Trong quá trình thực hiện Nhiệm vụ 4, kẻ tấn công có cần chỉnh sửa nội dung (claims) hay giả mạo chữ ký của ID Token không? Hãy giải thích nguyên nhân cốt lõi khiến điểm cuối /api/records chấp nhận ID Token này và trả về dữ liệu cho attacker.Trả lời: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_Nhiệm vụ 5 – secure\_api\_rejected: Kiểm chứng điểm cuối API đã bảo vệ chuẩn (/api/protected)Mục đích của nhiệm vụ này là kiểm chứng xem cùng một ID Token hợp lệ đó có thể sử dụng trên điểm cuối /api/protected — nơi đã áp dụng quy tắc xác minh loại trừ lẫn nhau theo tiêu chuẩn RFC 8725 (§3.11–3.12) và RFC 9068 (§4) — hay không.   Bước 1: Tại cửa sổ terminal attacker, tiếp tục sử dụng curl gửi chính $ID\_TOKEN trên tới điểm cuối /api/protected:Bashcurl -i -H "Authorization: Bearer $ID\_TOKEN" http://api.lab:8000/api/protected

Bước 2: Quan sát kết quả phản hồi:Điểm cuối /api/protected lập tức từ chối yêu cầu với mã trạng thái HTTP/1.1 401 Unauthorized, kèm header WWW-Authenticate: Bearer error="invalid\_token" và thông báo {"detail": "Yêu cầu xác thực."}.   Điều kiện hoàn thành nhiệm vụ: Điểm cuối /api/protected từ chối thành công yêu cầu mang $ID\_TOKEN của attacker với mã lỗi 401 Unauthorized.   Câu hỏi 5:Cùng sử dụng khóa công khai của Keycloak để xác minh chữ ký số, vì sao /api/protected lại từ chối ngay $ID\_TOKEN với mã lỗi 401 Unauthorized trong khi /api/records lại chấp nhận? Hãy nêu rõ các điều kiện kiểm tra tạo nên quy tắc xác minh loại trừ lẫn nhau tại /api/protected.Trả lời: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_Nhiệm vụ 6 – forensics\_done: Truy vết và phát hiện tấn công Cross-JWT Confusion qua phân tích LogĐóng vai chuyên gia Blue Team / điều tra số. Hệ thống giám sát ghi nhận tài khoản hạn chế attacker vừa truy cập thành công dữ liệu tại /api/records (status: 200). Nhiệm vụ của bạn là sử dụng kỹ thuật Log Correlation trên api.service, employee.service và keycloak.service để chứng minh đây là cuộc tấn công Cross-JWT Confusion sử dụng ID Token rò rỉ từ luồng đăng xuất, chứ không phải lỗi cấp nhầm quyền trên Keycloak hay lộ khóa ký mật mã.   Bước 1: Tại cửa sổ terminal server, kiểm tra các bản ghi sự kiện liên quan đến tài khoản attacker trên api.service:Bashsudo journalctl -u api.service --since "15 minutes ago" --no-pager -o cat | grep "attacker"

Quan sát và đối chiếu 3 bản ghi sự kiện xuất hiện theo trình tự thời gian:Bản ghi insufficient\_permission (status: 403) tại /api/protected ở Nhiệm vụ 1: Khi Document Portal gửi đúng Access Token ("token\_typ": "Bearer", "token\_aud": "resource-api"), API đã chặn đứng attacker vì thiếu quyền read.   Bản ghi records\_resource\_access (status: 200) tại /api/records ở Nhiệm vụ 4: Trường "token\_typ" lại mang giá trị "ID" và "token\_aud" mang giá trị "employee-portal"!Bản ghi invalid\_token (status: 401) tại /api/protected ở Nhiệm vụ 5: Cùng mã định danh "token\_jti" của chiếc ID Token đó đã bị /api/protected bác bỏ.Bước 2: Đối chiếu dấu hiệu bất thường về nguồn gọi (source\_ip và user\_agent) giữa truy cập hợp lệ và truy cập tấn công trên api.service:Bashsudo journalctl -u api.service --since "15 minutes ago" --no-pager -o cat | grep -E "protected\_resource\_access|records\_resource\_access"

Bạn sẽ nhận thấy sự khác biệt rõ rệt:Lượt gọi hợp lệ của student có "source\_ip": "172.28.50.20" và "user\_agent": "SSO-Portal/documents" (do backend của Portal gọi hộ ở kênh back-channel).   Lượt gọi khai thác vào /api/records của attacker xuất phát trực tiếp từ "source\_ip": "172.28.50.30" (máy Attacker) với "user\_agent": "curl/...".   Bước 3: Truy vết nguồn gốc lộ lọt ID Token bằng cách đối chiếu nhật ký đăng xuất giữa employee.service và keycloak.service:   Bashsudo journalctl -u employee.service --since "15 minutes ago" --no-pager -o cat | grep "logout\_started"

sudo journalctl -u keycloak.service --since "15 minutes ago" --no-pager -o cat | grep 'type="LOGOUT"'

Kết quả đối chiếu cho thấy:Trên employee.service có bản ghi "event": "logout\_started" xuất phát từ "source\_ip": "172.28.50.30" (thời điểm Employee Portal xuất ID Token ra tham số id\_token\_hint).   Tuy nhiên, trên keycloak.service hoàn toàn không có sự kiện type="LOGOUT" tương ứng — chứng tỏ yêu cầu chuyển hướng đăng xuất đã bị chặn giữ giữa chừng trên trình duyệt 172.28.50.30 để lấy ID Token đem đi gọi vào /api/records.Điều kiện hoàn thành nhiệm vụ: Đã truy vấn và đối chiếu đầy đủ các bằng chứng log trên api.service, employee.service và keycloak.service.   Câu hỏi 6:Dựa vào 3 bước phân tích log ở trên, hãy chỉ rõ các trường thông tin chứng minh việc attacker truy cập được /api/records là kết quả của tấn công Cross-JWT Confusion bằng công cụ bên ngoài chứ không phải do quản trị viên Keycloak cấp nhầm quyền cho attacker?Trả lời: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_Câu hỏi 7:Vì sao sự xuất hiện của sự kiện logout\_started trên employee.service nhưng không có sự kiện LOGOUT trên keycloak.service lại giúp điều tra viên xác định được chính xác vị trí rò rỉ ID Token? Để khắc phục triệt để lỗ hổng tại /api/records, lập trình viên cần bổ sung những kiểm tra nào theo chuẩn RFC 8725 và RFC 9068?Trả lời: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_Học viện Công nghệ Bưu chính Viễn thông - SecLab PTIT

