# Hướng dẫn thực hành

**OAuth 2.0 / OpenID Connect – Device Code Phishing**

**Mức độ: Trung bình – Khó**

**Web Security / Identity Security / Single Sign-On**

> **Trạng thái tài liệu:** Bản hướng dẫn đề xuất, dựa trên `sso(3).md` và bố cục của `sso-login-csrf(4).md`. Chưa triển khai hoặc chạy thực nghiệm. Các kết quả dưới đây là kết quả mong đợi, cần kiểm chứng; người xây dựng lab phải chuẩn bị các thành phần bổ sung ở phần 3 trước khi giao bài.

### 1. Giới thiệu lab

| Thông tin | Chi tiết |
| --- | --- |
| Tên lab đề xuất | `sso-device-code-phishing` |
| Mức độ | Trung bình – Khó |
| Công cụ sử dụng | Firefox, curl |
| Nền tảng | Keycloak 26.0.8, Employee Portal, Documents Portal và Resource API của hệ thống cơ sở |
| Giao thức nghiên cứu | OAuth 2.0 Device Authorization Grant |
| Phạm vi | Mạng Labtainer cô lập; tài khoản và dữ liệu thử nghiệm |

**Mục tiêu học tập**

- Hiểu mục đích của Device Authorization Grant và phân biệt `user_code`, `device_code`, access token.
- Tái hiện tình huống nạn nhân phê duyệt giao dịch do bên tấn công khởi tạo tại chính Keycloak thật.
- Xác định nơi nhận token và kiểm chứng quyền truy cập bằng Resource API.

**Kỹ năng đạt được**

Gửi yêu cầu device flow bằng curl; phê duyệt trên Keycloak; phân biệt giao dịch đang chờ với giao dịch đã cấp token; kiểm tra danh tính và quyền truy cập của token được cấp.

### 2. Kịch bản

**Tình huống**

Doanh nghiệp sử dụng Keycloak để đăng nhập Employee Portal và Documents Portal. Ngoài hai cổng web, doanh nghiệp bổ sung ứng dụng dòng lệnh **Trình đọc tài liệu thiết bị**, có client ID `document-device`. Người dùng chạy ứng dụng trên thiết bị của mình, lấy mã ngắn rồi dùng trình duyệt đăng nhập Keycloak để cho phép ứng dụng đọc Resource API.

Bên tấn công chạy ứng dụng trên máy của mình, xin mã rồi thuyết phục nạn nhân mở `verification_uri`, nhập `user_code` và phê duyệt. Điểm bị lợi dụng là nạn nhân chấp thuận giao dịch do attacker khởi tạo, khiến client trên máy attacker nhận token mang danh tính của nạn nhân. Đây là cơ chế **Remote Phishing** được mô tả tại RFC 8628 mục 5.4 và xuất hiện trong chiến dịch Storm-2372. [1][2]

Trong lab, sinh viên tự lấy `verification_uri` và `user_code` từ phản hồi trên máy attacker, rồi sử dụng chúng khi đóng vai victim ở nhiệm vụ tiếp theo. Thao tác này thay cho bước chuyển mã qua phishing; giả định nạn nhân đã bị thuyết phục và chọn phê duyệt. Không cần soạn lời nhắn hoặc dựng trang giả. Các yêu cầu OAuth sẽ thực hiện trực tiếp với Keycloak; bài không kiểm chứng mức độ thuyết phục người dùng thực.

**Vai trò của sinh viên**

- **Attacker:** Khởi tạo device flow ở container `attacker`, giữ `device_code`, chuyển `user_code` sang người đóng vai nạn nhân rồi nhận token khi được phê duyệt.
- **Victim:** Dùng Firefox trên `client`, đăng nhập bằng tài khoản `student` và phê duyệt mã được chuyển sang.

**Sơ đồ luồng tấn công**

```mermaid
sequenceDiagram
    participant A as Client thiết bị trên attacker
    participant V as Firefox trên client
    participant K as Keycloak thật
    participant R as Resource API
    A->>K: 1. Khởi tạo Device Authorization Grant
    K-->>A: 2. Trả device_code, user_code và địa chỉ xác minh
    A->>V: 3. Cung cấp verification_uri và user_code
    V->>K: 4. Nhập mã, xác thực và phê duyệt
    A->>K: 5. Hỏi kết quả bằng device_code
    K-->>A: 6. Trả access token của người phê duyệt
    A->>R: 7. Gọi API bằng access token
    R-->>A: 8. Trả kết quả nếu token hợp lệ và đủ quyền
```

Client có thể hỏi kết quả định kỳ trong thời gian chờ; bước 5 thể hiện lần hỏi sau khi phê duyệt. Trong bài, sinh viên gửi từng yêu cầu bằng curl để quan sát rõ các trạng thái.

**Giới hạn kết luận**

Kịch bản chứng minh một ứng dụng trên máy khác được cấp quyền của `student` do phê duyệt nhầm. Không đồng nghĩa bên tấn công biết mật khẩu, có cookie SSO của Firefox hoặc đã đăng nhập vào hai Portal. API cơ sở chỉ trả kết quả thử nghiệm; bài không tuyên bố đã tải tài liệu hoặc lấy dữ liệu mà API hiện chưa cung cấp.

### 3. Kiến thức bổ trợ

**OAuth 2.0 Device Authorization Grant sinh ra để làm gì?**

Luồng này phục vụ ứng dụng trên thiết bị khó nhập liệu hoặc thiếu trình duyệt, chẳng hạn TV, thiết bị kết nối hoặc công cụ dòng lệnh. Ứng dụng xin mã; người dùng mở trình duyệt thuận tiện hơn để xác thực và cho phép truy cập; ứng dụng ban đầu hỏi kết quả và nhận token. Mật khẩu không cần nhập vào ứng dụng thiết bị. [1]

**Bổ sung Device Grant vào hệ thống hiện có như thế nào?**

Hai Portal đang dùng Authorization Code Flow. Bài bổ sung một cách truy cập Resource API thông qua `document-device`:

| Cách truy cập | Ứng dụng nhận token | Vai trò của trình duyệt |
| --- | --- | --- |
| Hai Portal hiện có | Backend của Portal | Đăng nhập Keycloak và quay về Redirect URI của Portal |
| Ứng dụng thiết bị bổ sung | Client dòng lệnh đang giữ `device_code` | Mở trang xác minh của Keycloak, nhập mã và phê duyệt |

Cần phân biệt **đăng ký client** `document-device` trong Keycloak với **chạy ứng dụng client** trên thiết bị. Việc đăng ký cho phép ứng dụng dùng Device Grant; các lệnh curl ở phần 4 đóng vai chương trình client, thực hiện xin mã, hỏi kết quả và gọi API. Không cần xây dựng ứng dụng hoàn chỉnh hoặc bổ sung phần cứng TV.

Đây là tính năng được thêm để tạo tình huống nghiên cứu; không giả định hệ thống cơ sở đã có luồng thiết bị. Giữ nguyên đăng nhập của hai Portal và dùng lại realm, tài khoản, quyền cùng Resource API hiện có.

**Điểm bị lợi dụng**

Với luồng hợp lệ, người dùng phê duyệt mã do ứng dụng trên thiết bị của mình tạo ra. Với Device Code Phishing, họ phê duyệt mã do ứng dụng trên máy attacker tạo ra. Keycloak vẫn xác thực đúng người dùng và cấp token cho client giữ `device_code` của giao dịch đó. RFC 8628 mục 5.4 gọi nguy cơ này là **Remote Phishing**; kịch bản không cần một CVE hoặc lỗi kiểm tra chữ ký. [1]

Địa chỉ Keycloak đúng không chứng minh giao dịch thuộc thiết bị của người dùng. Các bảo vệ `state`, PKCE S256 và `nonce` của Portal vẫn giữ nguyên. Bài chưa cấu hình MFA nên không kết luận đã kiểm chứng vượt MFA. Storm-2372 là ví dụ thực tế về việc lừa người dùng phê duyệt device flow. [2]

**Các giá trị cần quan sát**

| Giá trị | Ý nghĩa trong bài |
| --- | --- |
| `client_id` | `document-device`, ứng dụng thiết bị đăng ký trong realm |
| `user_code` | Mã ngắn người dùng nhập tại trang xác minh |
| `device_code` | Giá trị bí mật của giao dịch, giữ ở máy khởi tạo để hỏi kết quả |
| `verification_uri` | Địa chỉ Keycloak trả về để người dùng xác thực và phê duyệt |
| `expires_in` | Thời hạn giao dịch do máy chủ trả về |
| `interval` | Khoảng chờ tối thiểu giữa các lần hỏi kết quả; nếu thiếu dùng 5 giây |

**Kiến trúc hệ thống trong bài lab**

| Thành phần | Container | IP | Trạng thái so với hệ thống cơ sở |
| --- | --- | --- | --- |
| Firefox của victim | `client` | `172.28.50.10` | Có sẵn |
| Client thiết bị do bên tấn công điều khiển | `attacker` | `172.28.50.30` | Cần bổ sung container có curl |
| Keycloak, hai Portal, Resource API | `server` | `172.28.50.20` | Có sẵn |

| Dịch vụ | Địa chỉ |
| --- | --- |
| Keycloak | `http://idp.lab:8080` |
| Employee Portal | `http://employee.lab:5001` |
| Documents Portal | `http://documents.lab:5002` |
| Resource API | `http://api.lab:8000/api/protected` |
| Discovery của realm | `http://idp.lab:8080/realms/sso-lab/.well-known/openid-configuration` |

Các host tiếp tục trỏ về `172.28.50.20`. Tài liệu cơ sở dùng HTTP và `start-dev`; bài giữ điều kiện lab này, là ngoại lệ so với yêu cầu HTTPS của chuẩn. Kịch bản không dựa vào nghe lén HTTP. [1]

**Chuẩn bị dành cho người xây dựng lab**

Các bước sau là cấu hình **cần bổ sung, chưa được triển khai**:

1. Thêm container `attacker` vào `SSO_NET` với IP `172.28.50.30`; bổ sung ánh xạ host như `client` và cài curl trên `attacker`.
2. Trong Keycloak Admin Console, chọn realm `sso-lab` → **Clients → Create client**. Tạo client OpenID Connect có ID `document-device`, tên hiển thị **Trình đọc tài liệu thiết bị**.
3. Tắt **Client authentication** để dùng public client; bật **OAuth 2.0 Device Authorization Grant**. Tắt Standard Flow, Implicit Flow và Direct Access Grants; không dùng Service Accounts cho client này. Luồng thiết bị không cần Redirect URI của Portal. [4]
4. Bật **Consent required**. Gắn các client scope cần thiết cho `openid profile` và ánh xạ role; giữ scope `roles` hoặc mapper tương đương. Trong client scope dành riêng của `document-device`, thêm mapper **Audience**, chọn `resource-api` ở **Included Client Audience** và bật thêm vào access token. Tắt **Full Scope Allowed**, giới hạn role scope mapping vào client role `read` của `resource-api`; tài khoản `student` đã có role này theo cấu hình cơ sở.
5. Kiểm tra dịch vụ sẵn sàng và endpoint khớp discovery của realm trước khi giao bài. Kiểm tra token đáp ứng chữ ký, issuer, hạn, audience và role của API; giữ nguyên bảo vệ của API và hai Portal. Chuẩn bị trạng thái consent sạch nếu grant đã lưu làm thay đổi màn hình phê duyệt khi làm lại.

Public client không có client secret để chứng minh riêng một bản cài đặt. Attacker dùng lại `client_id` của ứng dụng đã được đăng ký hợp lệ; không cần tài khoản quản trị hoặc tạo client mới. Bài không yêu cầu `offline_access` và không sử dụng refresh token nếu phản hồi có trường này. [1][4]

**Cú pháp công cụ**

| Công cụ | Mục đích trong bài |
| --- | --- |
| `getent hosts` | Kiểm tra tên miền nội bộ |
| `curl -d`, `--data-urlencode` | Gửi tham số dạng form; curl tự dùng phương thức POST |
| `curl -H` | Thêm Bearer header để gọi endpoint bảo vệ |
| `curl -i` | Hiển thị HTTP status và header của phản hồi |

### 4. Các nhiệm vụ của bài thực hành

**Khởi tạo môi trường lab**

Sau khi người xây dựng đóng gói và cài đặt lab mới, sinh viên khởi động bằng:

```bash
labtainer sso-device-code-phishing
```

Tài liệu chưa kèm gói cài đặt. Các nhiệm vụ dùng Firefox trên `client` và terminal `attacker`. Trong lệnh, thay phần `<...>` bằng giá trị thực từ phản hồi trước đó, không giữ dấu `<` và `>`.

Tài khoản victim: `student / Student-2026!`. Chỉ nhập mật khẩu trên Firefox tại Keycloak; vai attacker không cần biết mật khẩu hoặc có tài khoản Keycloak riêng.

**Nhiệm vụ 1 – sso_verified: Kiểm tra SSO**

**Bước 1:** Trên `client` và `attacker`, kiểm tra các tên miền trỏ về `172.28.50.20`:

```bash
getent hosts idp.lab employee.lab documents.lab api.lab
```

**Bước 2:** Trên Firefox của `client`, mở `http://employee.lab:5001` và đăng nhập bằng `student`. Mở tiếp `http://documents.lab:5002`, chọn đăng nhập và xác nhận không phải nhập lại mật khẩu. Giữ phiên Firefox này cho Nhiệm vụ 3.

**Điều kiện hoàn thành nhiệm vụ:** Tên miền đúng và SSO giữa hai Portal hoạt động.

**Câu hỏi 1:** Vì sao không cần bỏ `state`, PKCE hay `nonce` của hai Portal để thực hiện bài này?

**Trả lời:** ____________________________________________________________

**Nhiệm vụ 2 – attacker_device_request: Khởi tạo giao dịch của attacker**

**Bước 1:** Trên `attacker`, gửi yêu cầu POST xin mã cho `document-device`:

```bash
curl -sS http://idp.lab:8080/realms/sso-lab/protocol/openid-connect/auth/device \
  -d 'client_id=document-device' --data-urlencode 'scope=openid profile'
```

**Bước 2:** Đọc phản hồi JSON và lấy ba giá trị:

- `verification_uri` và `user_code`: dùng trên Firefox của victim ở Nhiệm vụ 3.
- `device_code`: giữ tại attacker để nhận token ở Nhiệm vụ 4.

Chỉ tiếp tục khi có đủ giá trị, không có lỗi; hoàn tất trong thời hạn `expires_in`. Việc dùng URL và mã của attacker ở nhiệm vụ tiếp theo thay cho bước dẫn dụ victim qua phishing; không cần tạo lời nhắn riêng.

**Điều kiện hoàn thành nhiệm vụ:** Có giao dịch do attacker khởi tạo và các giá trị cần thiết để tiếp tục.

**Câu hỏi 2:** `user_code` và `device_code` được dùng ở hai phía nào của giao dịch?

**Trả lời:** ____________________________________________________________

**Nhiệm vụ 3 – victim_authorization: Phê duyệt nhầm giao dịch**

**Bước 1:** Trên Firefox của `client`, mở `verification_uri` và nhập `user_code` lấy ở Nhiệm vụ 2. Dùng tài khoản `student`; nếu phiên SSO còn hiệu lực, Keycloak có thể không hỏi lại mật khẩu.

**Bước 2:** Tại màn hình xác nhận/ủy quyền của Keycloak, chọn phê duyệt **Trình đọc tài liệu thiết bị**. Thao tác này mô phỏng nạn nhân bị thuyết phục cấp quyền cho giao dịch do attacker khởi tạo.

**Điều kiện hoàn thành nhiệm vụ:** Victim đã phê duyệt giao dịch của attacker. Màn hình hoàn tất chưa đủ để kết luận attacker đã nhận token hoặc truy cập API.

**Câu hỏi 3:** Vì sao đúng tên miền Keycloak và đúng tài khoản `student` vẫn không bảo đảm giao dịch thuộc thiết bị của victim?

**Trả lời:** ____________________________________________________________

**Nhiệm vụ 4 – attacker_token_use: Nhận token và truy cập API**

**Bước 1:** Trên `attacker`, thay `<DEVICE_CODE>` bằng `device_code` ở Nhiệm vụ 2 rồi chạy:

```bash
curl -sS http://idp.lab:8080/realms/sso-lab/protocol/openid-connect/token \
  -d 'client_id=document-device' \
  -d 'grant_type=urn:ietf:params:oauth:grant-type:device_code' \
  --data-urlencode 'device_code=<DEVICE_CODE>'
```

Kết quả mong đợi: phản hồi JSON chứa `access_token`. Dừng hỏi kết quả khi đã nhận token.

Lần hỏi này thực hiện sau khi victim phê duyệt; ứng dụng thực thường polling trong lúc chờ. Nếu nhận `authorization_pending`, chờ ít nhất `interval` giây giữa các lần hỏi (mặc định 5 giây nếu thiếu); với `slow_down`, tăng khoảng chờ thêm ít nhất 5 giây cho các lần tiếp theo. Dừng nếu bị từ chối hoặc hết hạn; kiểm tra lỗi khác trước khi tiếp tục. [1][3]

**Bước 2:** Thay `<ACCESS_TOKEN>` bằng giá trị `access_token` vừa nhận, không dùng `id_token`, rồi kiểm tra danh tính:

```bash
curl -sS http://idp.lab:8080/realms/sso-lab/protocol/openid-connect/userinfo \
  -H 'Authorization: Bearer <ACCESS_TOKEN>'
```

Kết quả mong đợi: `preferred_username` là `student` và `sub` là ID tương ứng trong realm. [5]

**Bước 3:** Dùng **cùng access token** để gọi Resource API:

```bash
curl -sS -i http://api.lab:8000/api/protected \
  -H 'Authorization: Bearer <ACCESS_TOKEN>'
```

Kết quả mong đợi: HTTP `200` và `{"status":"ok"}`. Nếu thiếu claim ở UserInfo, kiểm tra scope/mapper; nếu API trả `401/403`, kiểm tra token và quyền, chưa ghi nhận truy cập thành công.

**Điều kiện hoàn thành nhiệm vụ:** Client trên `attacker` nhận token sau phê duyệt của victim; UserInfo xác nhận danh tính `student` và API chấp nhận cùng token. Đây là tiêu chí kiểm chứng mô phỏng, không chỉ dựa vào khác IP hoặc màn hình phê duyệt.

**Câu hỏi 4:** Access token được cấp cho bên nào, mang danh tính của ai, và kết quả nào chứng minh quyền truy cập đã được sử dụng?

**Trả lời:** ____________________________________________________________

**Kết quả cần nộp**

- Chuỗi bằng chứng ngắn: giao dịch khởi tạo trên `attacker` → phê duyệt tại Keycloak trên `client` → phản hồi cấp token trên `attacker` → UserInfo và HTTP `200` của API.
- Câu trả lời cho 4 câu hỏi. Ghi kết quả thực tế; che mã và token trong ảnh, không nộp nguyên token, `device_code`, cookie hoặc mật khẩu.

Khi làm lại, tạo giao dịch mới; không dùng lại mã hoặc token cũ.

**Ghi chú nghiệm thu dành cho người xây dựng lab**

Trước khi giao bài, cần kiểm chứng trên Keycloak 26.0.8: cấu hình client, trình tự trang xác minh/consent, scope và claim UserInfo, quyền API, cùng toàn bộ luồng mô phỏng. Các kiểm tra này chưa được thực hiện trong bản tài liệu; không bỏ kiểm tra bảo mật của API để làm cho lượt thử thành công.

**Đối chiếu cơ sở kỹ thuật và tài liệu tham khảo**

Cấu hình và câu lệnh là đề xuất cho hệ thống lab đã cung cấp. Các nguồn sau dùng để đối chiếu cơ chế, không thay thế việc chạy kiểm chứng trên môi trường này.

| Nguồn | Nội dung dùng để đối chiếu |
| --- | --- |
| [1] RFC 8628, tháng 8/2019 | Mục 1: mục đích; mục 3: luồng và tham số; mục 3.5: polling/lỗi; mục 5.4: Remote Phishing |
| [2] Microsoft, Storm-2372, 13/2/2025 | Tấn công thực tế lừa phê duyệt device flow và sử dụng token |
| [3] Microsoft Learn | Giải thích device flow; không áp dụng máy móc thời hạn và endpoint riêng của Microsoft cho Keycloak |
| [4] Keycloak Server Administration Guide 26.0.8 | Cấu hình client, Device Grant, consent và mapper |
| [5] Keycloak, OpenID Connect endpoints | Discovery, device authorization, token và UserInfo endpoint |

1. [RFC 8628 — OAuth 2.0 Device Authorization Grant](https://www.rfc-editor.org/rfc/rfc8628.html).
2. [Microsoft — Storm-2372 conducts device code phishing campaign](https://www.microsoft.com/en-us/security/blog/2025/02/13/storm-2372-conducts-device-code-phishing-campaign/).
3. [Microsoft Learn — OAuth 2.0 device authorization grant](https://learn.microsoft.com/en-us/entra/identity-platform/v2-oauth2-device-code).
4. [Keycloak — Server Administration Guide 26.0.8](https://www.keycloak.org/docs/26.0.8/server_admin/index.html).
5. [Keycloak — OpenID Connect endpoints](https://www.keycloak.org/securing-apps/oidc-layers).

Tài liệu cấu hình và bố cục do người dùng cung cấp: `sso(3).md`; `sso-login-csrf(4).md`. Chỉ kế thừa mẫu trình bày của bài Login CSRF; giữ cấu hình bảo vệ của hai Portal theo hệ thống cơ sở.
