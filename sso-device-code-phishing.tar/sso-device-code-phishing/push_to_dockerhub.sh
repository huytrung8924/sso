#!/bin/bash
set -e
for img in client server attacker; do
    echo "Processing $img..."
    docker tag sso-device-code-phishing.$img.student:latest trung8924/sso-device-code-phishing.$img.student:latest
    docker tag sso-device-code-phishing.$img.student:latest trung8924/sso-device-code-phishing.$img.student:base_image739eee77f8d3
    # docker push trung8924/sso-device-code-phishing.$img.student:latest
    # docker push trung8924/sso-device-code-phishing.$img.student:base_image739eee77f8d3
done
